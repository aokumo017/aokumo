function HttpioRq()
{

	//TODO:edit here
	//  해야할거 실시간 셋 관련해서 만들어야함 , 또 내용을 받아서 처리하는 온리시브 함수 만들어서 해야함  TR 일경우에만

}

// ajax url 다른주소 요청함수
HttpioRq.prototype.extAjaxSend = function(url, data, callback)
{
	$.ajax(
	{
		type:'POST',
		dataType: "text",
	  	url: url,
		data: { 'data': data },
		success: function(data) 
		{
			if(callback) callback({ result: "success", message: data });
		},
		error: function (error)
		{
			if(callback) callback({ result: false, message: error.statusText });
		}
	});
};

// websocket url 연결요청
HttpioRq.prototype.extWebsocketConnection = function(url, data)
{
	if(this.isStart()) return;
	
	var thisObj = this;
	//var urlsss = url.substring(0, 2) + 's' + url.substring(2);
	var socket = new WebSocket(url);
	
	socket.onopen = function(event) 
	{
		thisObj.socket = socket;
		if(TESTLOG == 1) console.log('소켓 연결 성공');
		if(data !== null) theApp.reconSet();
		else theApp.userSetA();
	};	
	
	socket.onmessage = function(event) 
	{
		theApp.onReceived(event.data);
	};

	socket.onclose = function(event) 
	{
		if(TESTLOG == 1) console.log('소켓 close 타냐 : ', event);
		if(event.wasClean)
		{
			console.log('Connection closed cleanly');
		}
		else
		{
			console.log('Connection died unexpectedly');
		}
		setTimeout(function()
		{
			if(theApp.g_errorcheckon) theApp.reconnectServer();
			else {
				// close
			}
		}, 1000);
	};
	
	socket.onerror = function(event) 
	{
		console.log('onError', event);
		thisObj.Stopsocket();
	};
};

// websocket 스탑
HttpioRq.prototype.extWebsocketStop = function(isClose)
{
	if(!this.isStart()) return;
	this.socket.close();
	this.socket = null;
};

// websocket 보내기
HttpioRq.prototype.extWebsocketSend = function(data)
{
	if(!this.isStart())
	{
		if(data.type != 'D') 
		{
			//theApp.reconnectServer(data);
		}
		return;
	}
	var json = JSON.stringify(data);
	this.socket.send(json);
	
	//if(data.type == 'D') this.Stopsocket();
};

// websocket 스탑
HttpioRq.prototype.isStart = function()
{
	return (this.socket!=null);
};

// websocket 스탑
HttpioRq.prototype.Stopsocket = function()
{
	if(!this.isStart()) return;
	this.socket.close();
	this.socket = null;
};

