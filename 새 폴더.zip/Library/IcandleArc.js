function IcandleArc()
{
	// 변경값
	this.ROW_CNT = ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.dotDegree = [0, 1, 2, 3]; //상단 그래프 금액 구분선 Y좌표 배열
	
	this.TEXT_SIZE = '16px';			//폰트 사이즈
	this.FONT_FAMILY = 'Regular';		// 폰트체
	
	this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
	this.AM_R_WIDTH = AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BAR_CNT = BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.m_downheight = DOWNHEIGHT; //상단 그래프 끝 Y좌표
	
	this.m_lineWidthM = 1;		// 마우스 너비 값
	
	this.img_Arcwidth = 100;		// 원 이미지 너비
	this.img_Archeight = 100;	// 원 이미지 높이
	
	// 기본값 
	this.m_imgArr = [];		// 이미지 저장변수
	
	//색상값
	this.colorObj = {
		ARCTRC : 'rgba(0, 255, 0, 0.5)', 	// 깜박깜박 투명색
		LINEARC : '#5f7191', 					// 라인끝에 원 중앙 색상
		LINEARCGR : 'transparent',			// 라인끝에 원색상 그라데이션
		MOVELINE : '#5f7191'				// 라인선 색   rgba(0, 255, 0, 0.5)
	};
	
	// 위치값
	this.pos =
	{
        cavasW : 0,		//전체 캔버스 너비   필요
        cavasH : 0,		//전체 캔버스 높이   필요
        grpW : 0,		//상단,하단 그래프영역 너비
        grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
        dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
        amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
        amPad : 0,		//금액 오른쪽 정렬시 마진
        txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

        upGrpSY : 0,	//상단 그래프 시작 Y좌표
        upDtY : 0,		//상단 그래프 Date 영역 Y
        upGrpEY : 0,	//상단 그래프 끝 Y좌표
        upGrpH : 0,		//상단 그래프 그리는 영역 높이
        kbnY : 0,		//상단,하단 그래프 구분Y
        dwGrpSY : 0,	//하단 그래프 시작 Y좌표
        dwDtY : 0,		//하단 그래프 Date 영역 Y
        dwGrpEY : 0,	//하단 그래프 끝 Y좌표
        dwGrpH : 0,		//하단 그래프 그리는 영역 높이

        dw80Y : 0,		//하단 80퍼센트 높이
        dw20Y : 0,		//하단 20퍼센트 높이

        upRateH : 0,	//상단 높이 비율
        dwRateH : 0,	//하단 높이 비율

        barW : this.DEF_BAR_W, //봉차트 너비

        barTot : 0,		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    };
	
	this.m_height = 4;     // 높이 위치 조정 값 
	this.m_amYsvalue = 0; // 높이 간격 계산값
}


/*******************************************************
========================================================
	차트 데이터 그래프 초기화 함수
========================================================
*******************************************************/

// 그래프 초기화
IcandleArc.prototype.canvasClear = function()
{
	 this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
};


/*******************************************************
========================================================
	차트 기본값입력
========================================================
*******************************************************/

// 다시 설정해야함
IcandleArc.prototype.reCalcWidth = function(cnt) {
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;			//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);		//봉차트 너비
};


//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
IcandleArc.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;									//캔버스 너비   필요
    this.pos.cavasH = elHeight;									//캔버스 높이   필요
	
	this.offscreenCanvas.width = elWidth;
	this.offscreenCanvas.height = elHeight;

    this.pos.grpEX = elWidth - this.AM_R_WIDTH;   				//상단,하단 오른쪽 금액영역 너비   100
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;			//상단,하단 왼쪽 금액영역 너비     0

    this.pos.amPad = elWidth - 5;								//금액 오른쪽 정렬시 마진

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];   //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]

    this.pos.upGrpSY = elHeight / this.ROW_CNT;			//상단 그래프 시작 Y좌표
    this.pos.txtY = (this.pos.upGrpSY / 2);				//텍스트 세로 중간 정렬을 위한 Y위치
	
	this.pos.upGrpEY = elHeight - this.m_downheight;		//상단 그래프 끝 Y좌표
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;			//상단 그래프 그리는 영역 높이
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;				//상단 그래프 Date 영역 Y
	
	this.m_amYsvalue = (this.pos.upGrpEY - this.pos.upGrpSY ) / this.m_height;
	this.pos.amYs = [this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[0]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[1]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[2]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[3]), this.pos.upGrpEY];
	
    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수    //상단,하단 그래프 구분Y
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;		//하단 그래프 시작 Y좌표
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;		//하단 그래프 끝 Y좌표
    this.pos.dwDtY = this.pos.dwGrpEY  + this.pos.txtY;			//하단 그래프 Date 영역 Y
    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;		//하단 그래프 그리는 영역 높이
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;		//하단 80퍼센트 높이
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;		//하단 20퍼센트 높이

    this.reCalcWidth();
    this.startLineX = this.pos.grpEX + this.pos.barW / 2;
};

// 이미지 가져오기
IcandleArc.prototype.setImageUrl = function(arrimg) 
{
	// 새 이미지 객체 생성
	var myImage = new Image();
	var myImage2 = new Image();
	var myImage3 = new Image();
	var myImage4 = new Image();
	var myImage5 = new Image();

	// 이미지 속성 설정
	myImage.src = 'Assets/img/Ellipse.png'; // 여기에 원하는 이미지 URL을 지정하세요.
	myImage.alt = '설명 텍스트';
	myImage.width = 5; // 원하는 너비(픽셀 단위)
	myImage.height = 5; // 원하는 
	arrimg.push(myImage);
	
	// 이미지 속성 설정
	myImage2.src = 'Assets/img/Ellipse.png'; // 여기에 원하는 이미지 URL을 지정하세요.
	myImage2.alt = '설명 텍스트';
	myImage2.width = 5; // 원하는 너비(픽셀 단위)
	myImage2.height = 5; // 원하는 
	arrimg.push(myImage);
	
	// 이미지 속성 설정
	myImage3.src = 'Assets/img/Ellipse.png'; // 여기에 원하는 이미지 URL을 지정하세요.
	myImage3.alt = '설명 텍스트';
	myImage3.width = 5; // 원하는 너비(픽셀 단위)
	myImage3.height = 5; // 원하는 
	arrimg.push(myImage3);
	
	// 이미지 속성 설정
	myImage4.src = 'Assets/img/Ellipse.png'; // 여기에 원하는 이미지 URL을 지정하세요.
	myImage4.alt = '설명 텍스트';
	myImage4.width = 5; // 원하는 너비(픽셀 단위)
	myImage4.height = 5; // 원하는 
	arrimg.push(myImage4);
	
	// 이미지 속성 설정
	myImage5.src = 'Assets/img/Ellipse.png'; // 여기에 원하는 이미지 URL을 지정하세요.
	myImage5.alt = '설명 텍스트';
	myImage5.width = 5; // 원하는 너비(픽셀 단위)
	myImage5.height = 5; // 원하는 
	arrimg.push(myImage5);
};


/*******************************************************
========================================================
	차트 외부 기본값입력 
========================================================
*******************************************************/

// ctx 캔버스 값 넘기기
IcandleArc.prototype.setCTX = function(ctx, canvas)
{
	this.canvas = canvas;
	this.ctx = ctx;
	this.setImageUrl(this.m_imgArr);
	// 백 버퍼 생성 더블 버퍼링 (Double Buffering) 사용
	this.offscreenCanvas = document.createElement('canvas');
	this.offscreenCtx = this.offscreenCanvas.getContext('2d');
};

// 차트 변경값 변경
IcandleArc.prototype.setChangewidhtvalue = function(Obj)
{
	this.AM_R_WIDTH = Obj.AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	//this.BOXWIDTH = Obj.BOXWIDTH;	//네모 박스 너비
	this.BAR_CNT = Obj.BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.ROW_CNT = Obj.ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.m_downheight = Obj.DOWNHEIGHT; //상단 그래프 끝 Y좌표
	//this.m_xcount = Obj.MXCOUNT;  // 틱기준 자르는기준
};


/*******************************************************
========================================================
	차트 외부 데이터 입력값 함수
========================================================
*******************************************************/

//그래프의 너비 및 높이를 업데이트
IcandleArc.prototype.updatePosition = function(pWidth, pHeight) {
    this.calcPosition(pWidth, pHeight);
};


/*******************************************************
========================================================
	캔버스 그리는 다양한 종료를 그리기 함수
========================================================
*******************************************************/

//끝에 원그리기
IcandleArc.prototype.drawFirstPoint = function(x, y, count) 
{
	var halfWidth = 0, halfHeight = 0;
	this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	this.drawPriceMove(x, y);
	
	halfWidth = this.img_Arcwidth  / 2;  // 이미지 너비의 절반
	halfHeight = this.img_Archeight / 2; // 이미지 높이의 절반
	
	this.ctx.beginPath();
	
	if (count < 8) 
	{
		this.ctx.drawImage(this.m_imgArr[0], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 16) 
	{
		this.ctx.drawImage(this.m_imgArr[1], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 24) 
	{
		this.ctx.drawImage(this.m_imgArr[2], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 32) 
	{
		this.ctx.drawImage(this.m_imgArr[3], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else 
	{
		this.ctx.drawImage(this.m_imgArr[4], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	}
	
	this.ctx.closePath(); // Close the current path
};

// 현재가 선 그리기
IcandleArc.prototype.drawPriceMove = function(offsetX1, offsetY1) 
{
	if (!offsetX1 || !offsetY1)
        return;

	// x 축그리기
	/*this.ctx.beginPath();
	this.ctx.moveTo(offsetX1, 0);
	this.ctx.lineTo(offsetX1, this.pos.cavasH);
	this.ctx.stroke();
	this.ctx.closePath();*/
	
	// Y 축그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = this.m_lineWidthM;
	this.ctx.strokeStyle = this.colorObj.MOVELINE;
	//this.ctx.setLineDash([5, 5]);
	const boxX = this.canvas.width - 70 - 5; // 텍스트 박스의 시작점 X 위치 계산 (70은 텍스트 박스 너비)
	this.ctx.moveTo(0, offsetY1);
	this.ctx.lineTo(boxX, offsetY1);  // Y축 선의 끝을 텍스트 박스 왼쪽까지 그리도록 설정
	this.ctx.stroke();
	this.ctx.closePath();
};

// 현재가 선 그리기
IcandleArc.prototype.drawPriceMovetwo = function(offsetY1) 
{
	if (!offsetY1)
        return;
	// Y 축그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = this.m_lineWidthM;
	this.ctx.strokeStyle = this.colorObj.MOVELINE;
	//this.ctx.setLineDash([5, 5]);
	this.ctx.moveTo(0, offsetY1);
	this.ctx.lineTo(this.pos.cavasW - this.AM_R_WIDTH, offsetY1);
	this.ctx.stroke();
	this.ctx.closePath();
};

// 버퍼 로 그리기

//끝에 원그리기
IcandleArc.prototype.drawFirstPointaaaa = function(x, y, count) 
{
	var halfWidth = 0, halfHeight = 0;
	this.offscreenCtx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	this.drawPriceMoveaaaa(x, y);
	
	halfWidth = this.img_Arcwidth  / 2;  // 이미지 너비의 절반
	halfHeight = this.img_Archeight / 2; // 이미지 높이의 절반
	
	this.offscreenCtx.beginPath();
	
	if (count < 8) 
	{
		this.offscreenCtx.drawImage(this.m_imgArr[0], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 16) 
	{
		this.offscreenCtx.drawImage(this.m_imgArr[1], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 24) 
	{
		this.offscreenCtx.drawImage(this.m_imgArr[2], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else if (count < 32) 
	{
		this.offscreenCtx.drawImage(this.m_imgArr[3], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	} 
	else 
	{
		this.offscreenCtx.drawImage(this.m_imgArr[4], x - halfWidth, y - halfHeight, this.img_Arcwidth, this.img_Archeight);
	}
	
	this.offscreenCtx.closePath(); // Close the current path
	
	// 메인 캔버스에 백 버퍼 복사
	this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	this.ctx.drawImage(this.offscreenCanvas, 0, 0);
};

// 현재가 선 그리기
IcandleArc.prototype.drawPriceMoveaaaa = function(offsetX1, offsetY1) 
{
	if (!offsetX1 || !offsetY1)
        return;
	
	// Y 축그리기
	this.offscreenCtx.beginPath();
	this.offscreenCtx.lineWidth = this.m_lineWidthM;
	this.offscreenCtx.strokeStyle = this.colorObj.MOVELINE;
	//this.offscreenCtx.setLineDash([5, 5]);
	this.offscreenCtx.moveTo(0, offsetY1);
	this.offscreenCtx.lineTo(this.pos.cavasW - this.AM_R_WIDTH, offsetY1);
	this.offscreenCtx.stroke();
	this.offscreenCtx.closePath();
};

