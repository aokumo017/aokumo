// 도트선 라이브러리
var CP = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
if (CP && CP.lineTo){
  CP.dashedLine = function(x,y,x2,y2,dashArray){
    if (!dashArray) dashArray=[10,5];
    if (dashLength==0) dashLength = 0.001; // Hack for Safari
    var dashCount = dashArray.length;
    this.moveTo(x, y);
    var dx = (x2-x), dy = (y2-y);
    var slope = dy/dx;
    var distRemaining = Math.sqrt( dx*dx + dy*dy );
    var dashIndex=0, draw=true;
	// 선의 색상을 반투명 흰색으로 설정
    this.strokeStyle = 'rgba(255, 255, 255, 0.5)'; // 흰색, 50% 투명도
    while (distRemaining>=0.1){
      var dashLength = dashArray[dashIndex++%dashCount];
      if (dashLength > distRemaining) dashLength = distRemaining;
      var xStep = Math.sqrt( dashLength*dashLength / (1 + slope*slope) );
      if (dx<0) xStep = -xStep;
      x += xStep;
      y += slope*xStep;
      this[draw ? 'lineTo' : 'moveTo'](x,y);
      distRemaining -= dashLength;
      draw = !draw;
    }
  };
}

// 백그라운드선 실선
var CPPC = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
if (CPPC && CPPC.lineTo) {
  CPPC.solidLine = function(x, y, x2, y2) {
  	this.strokeStyle = 'rgba(255, 255, 255)'; // 선의 색상 설정 (예: 빨간색)
	//this.lineWidth = 5; // 선의 너비 설정
    this.beginPath(); // 경로 시작
    this.moveTo(x, y); // 선 시작 좌표
    this.lineTo(x2, y2); // 선 종료 좌표
    this.globalAlpha = 0.1; // 선의 투명도를 30%로 설정
    this.stroke(); // 선 그리기
	this.closePath();
    this.globalAlpha = 1.0; // 다른 그리기 요소에 영향을 주지 않도록 투명도를 기본값으로 복원
  };
}


function Icandleback()
{
	/* ======== 변경값  =========*/
	
	this.DEF_BAR_W = 8;		//기본 봉 너비
	
	// 위치 간격 변수
	this.AM_R_WIDTH = AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
    this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
	this.m_downheight = DOWNHEIGHT; //상단 그래프 끝 Y좌표
	this.dotDegree = [0, 1, 2, 3]; //상단 그래프 금액 구분선 Y좌표 배열
	this.ROW_CNT = ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	
	// 너비 간격 변수
	this.BAR_CNT = BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	theApp.upGrpMaxAm = 0;	//그래프 텍스트 최대값
    this.upGrpMinAm = 0;	//그래프 텍스트 최소값
	
	// 간격
	this.BAR_TERM = 1;		//봉차트간 간격
	
	// 점선 간격사이즈
	this.dashType = [3.5, 4];
	this.TEXT_SIZE = '10px';
	this.FONT_FAMILY = 'SpoqaHanSansNeo-Regular';
	//네모 박스 너비
	this.BOXWIDTH = BOXWIDTH;
	
	// 높이 위치 조정 값
	this.m_height = 4;     
	this.m_amYsvalue = 0; // 높이 간격 계산값
	
	// x 측 움직이는 가격 기준값
	this.m_xcount = MXCOUNT;  // 틱기준 자르는기준
	this.m_startline = 0;
	this.m_startlinevalue = 0;
	
	this.mstartminu = 100;  // 값 너비와 그리기 사이에 간격
	
	/* ======== 기본값  =========*/
	
	// 중요 y 계산값 배열
	this.m_YamYs  = [];
	
	// 백 라인 움직일건지 안움직일건지 저장변수 false 안움직임 true 움직임
	this.m_backlinedrawYN = false;
	
	/* ======== 색상값  =========*/
	
	this.colorObj = {
		LINEARC : 'green', 				// 라인끝에 원 중앙 색상
		LINEARCGR : 'transparent', 		// 라인끝에 원색상 그라데이션
		DOT : '#d9dbe5', 				//차트 전체 도트 색
		MOVELINE : '#0055d8',      		//마우스 선 and 텍스트박스
    	PRCTEXT : '#00d810'        		//현재가 텍스
    };
	
	/* ======== 위치값  =========*/
	
	this.pos =
	{
		cavasW : 0,		//전체 캔버스 너비   필요
		cavasH : 0,		//전체 캔버스 높이   필요
		grpW : 0,		//상단,하단 그래프영역 너비
		grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
		dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
		amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
		amPad : 0,		//금액 오른쪽 정렬시 마진
		txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

		upGrpSY : 0,	//상단 그래프 시작 Y좌표
		upDtY : 0,		//상단 그래프 Date 영역 Y
		upGrpEY : 0,	//상단 그래프 끝 Y좌표
		upGrpH : 0,		//상단 그래프 그리는 영역 높이
		kbnY : 0,		//상단,하단 그래프 구분Y
		dwGrpSY : 0,	//하단 그래프 시작 Y좌표
		dwDtY : 0,		//하단 그래프 Date 영역 Y
		dwGrpEY : 0,	//하단 그래프 끝 Y좌표
		dwGrpH : 0,		//하단 그래프 그리는 영역 높이

		dw80Y : 0,		//하단 80퍼센트 높이
		dw20Y : 0,		//하단 20퍼센트 높이

		upRateH : 0,	//상단 높이 비율
		dwRateH : 0,	//하단 높이 비율

		barW : this.DEF_BAR_W, //봉차트 너비

		barTot : 0,		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
	};
	
	theApp.m_baryot = 0;	// 가격 높이 간격
}


/*******************************************************
========================================================
	차트 데이터 그래프 초기화 함수
========================================================
*******************************************************/

// 그래프 초기화
Icandleback.prototype.canvasClear = function()
{
	 this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
};


/*******************************************************
========================================================
	차트 기본값입력
========================================================
*******************************************************/

// 다시 설정해야함
Icandleback.prototype.reCalcWidth = function(cnt) 
{
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;			//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);		//봉차트 너비
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
Icandleback.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;									//캔버스 너비   필요
    this.pos.cavasH = elHeight;									//캔버스 높이   필요
	
    this.pos.grpEX = elWidth - this.AM_R_WIDTH;   				//상단,하단 오른쪽 금액영역 너비   100
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;			//상단,하단 왼쪽 금액영역 너비     0

    this.pos.amPad = elWidth - 5;								//금액 오른쪽 정렬시 마진

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];   //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]

    this.pos.upGrpSY = elHeight / this.ROW_CNT;			//상단 그래프 시작 Y좌표
    this.pos.txtY = (this.pos.upGrpSY / 2);				//텍스트 세로 중간 정렬을 위한 Y위치
	
	this.pos.upGrpEY = elHeight - this.m_downheight;		//상단 그래프 끝 Y좌표
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;			//상단 그래프 그리는 영역 높이
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;				//상단 그래프 Date 영역 Y
	
	this.m_amYsvalue = (this.pos.upGrpEY - this.pos.upGrpSY ) / this.m_height;
	this.pos.amYs = [this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[0]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[1]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[2]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[3]), this.pos.upGrpEY];  //상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
	
    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수    //상단,하단 그래프 구분Y
	
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;		//하단 그래프 시작 Y좌표
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;		//하단 그래프 끝 Y좌표
    this.pos.dwDtY = this.pos.dwGrpEY  + this.pos.txtY;			//하단 그래프 Date 영역 Y
    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;		//하단 그래프 그리는 영역 높이
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;		//하단 80퍼센트 높이
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;		//하단 20퍼센트 높이

    //텍스트 사이즈 셋팅
    /*if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW * 0.03) + 'px';
    else this.TEXT_SIZE = (this.pos.cavasH * 0.03) + 'px';*/

    this.reCalcWidth();
	
	// 시작 위치
	//this.startLineX = this.pos.grpEX + this.pos.barW / 2; // 데이터 배열이 앞일경우에 이게 해당
	this.startLineX = 0; // 데이터 배열이 뒤일경우에 이게 해당
	this.verticallineX = this.pos.grpEX + this.pos.barW / 2;   //  백그라운드 세로선 
	
	// 백 라인 움직이는 변수값 구하기
	this.m_startline = this.pos.barTot * this.m_xcount;
	this.m_startlinevalue  = this.startLineX - this.m_startline;
	this.m_startLineX = this.pos.grpEX + this.pos.barW / 2;
};


/*******************************************************
========================================================
	차트 외부 기본값입력 
========================================================
*******************************************************/

// ctx 캔버스 값 넘기기
Icandleback.prototype.setCTX = function(ctx, canvas)
{
	this.canvas = canvas;
	this.ctx = ctx;
};

// 초인지 분인지
Icandleback.prototype.setTimeTypeback = function(type)
{
	this.m_bongcharttype = type;
};

// 차트 변경값 변경
Icandleback.prototype.setChangewidhtvalue = function(Obj)
{
	this.AM_R_WIDTH = 0;	//상단,하단 오른쪽 금액영역 너비
	this.BOXWIDTH = Obj.BOXWIDTH;	//네모 박스 너비
	this.BAR_CNT = Obj.BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.ROW_CNT = Obj.ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.m_downheight = Obj.DOWNHEIGHT; //상단 그래프 끝 Y좌표
	this.m_xcount = Obj.MXCOUNT;  // 틱기준 자르는기준
};


/*******************************************************
========================================================
	차트 외부 데이터 입력값 함수
========================================================
*******************************************************/

//그래프의 너비 및 높이를 업데이트
Icandleback.prototype.updatePosition = function(pWidth, pHeight) {
    this.calcPosition(pWidth, pHeight);
};


/*******************************************************
========================================================
	차트 캔버스 기본 입력 셋
========================================================
*******************************************************/

//상 하단 그래프 최대최소 구하기
Icandleback.prototype.setMaxMin = function() 
{
    theApp.upGrpMaxAm = 0;
	theApp.upRateH = 0;
    this.upGrpMinAm = Number.MAX_VALUE;
	var maxmin = null, i = 0;
	
	if(this.m_bongcharttype === 'sec')
  	{
		for (i = theApp.g_startIdx; i < theApp.g_endIdx; i++) 
		{
			if(theApp.baseData[i].price) maxmin = theApp.baseData[i].price;
			else
			{
				if(TESTLOG == 1) console.log('원인파악을 시작인덱스 : ', theApp.g_startIdx);
				if(TESTLOG == 1) console.log('원익파악을 끝나는인데스 : ', theApp.g_endIdx);
			}

			theApp.upGrpMaxAm = Math.max(theApp.upGrpMaxAm, maxmin);
			this.upGrpMinAm = Math.min(this.upGrpMinAm, maxmin);

		}
		let b = theApp.upGrpMaxAm * 0.00009;
		let a = this.upGrpMinAm * 0.00009;  //0.0001
		this.upGrpMinAm -= a;
		theApp.upGrpMaxAm += b;
	}
	else
	{
		for (i = theApp.g_startIdx; i < theApp.g_endIdx; i++) 
		{
			if(theApp.baseData[i]) maxmin = theApp.baseData[i];
			else
			{
				if(TESTLOG == 1) console.log('원인파악을 시작인덱스 : ', theApp.g_startIdx);
				if(TESTLOG == 1) console.log('원익파악을 끝나는인데스 : ', theApp.g_endIdx);
			}
			theApp.upGrpMaxAm = Math.max(theApp.upGrpMaxAm, maxmin.gogaprice);
			this.upGrpMinAm = Math.min(this.upGrpMinAm, maxmin.jongprice);

		}
	}
	
	//theApp.upGrpMaxAm = Math.max(...theApp.baseData.map(item => item.v));
	//this.upGrpMinAm = Math.min(...theApp.baseData.map(item => item.v));
	
    // 윗부분 최대값과 최소값이 같은 경우 중간에 표현되도록 최소값을 0으로 변경한다.
    if(theApp.upGrpMaxAm == this.upGrpMinAm) this.upGrpMinAm = 0;
	
    //this.pos.upRateH = (this.pos.upGrpEY - this.pos.upGrpSY) / (theApp.upGrpMaxAm - this.upGrpMinAm);
	theApp.upRateH = (this.pos.upGrpEY - this.pos.upGrpSY) / (theApp.upGrpMaxAm - this.upGrpMinAm);
	// 높이 간격
	if(theApp.baseData[0])
	{
		theApp.m_baryot = this.pos.upGrpSY + (theApp.upGrpMaxAm - theApp.baseData[0].price) * theApp.upRateH;
	}
};


/*******************************************************
========================================================
	차트 캔버스 그리는 함수
========================================================
*******************************************************/

//차트 진짜 그리기 함수 모음
Icandleback.prototype.backdraw = function(m_scrollYN) 
{
	// 움직일건지 안움직일건지 나중에 로직 정리후 정리 
	/*if(this.m_backlinedrawYN)
	{
		this.m_startLineX -= this.pos.barTot;
		if(Math.round(this.m_startlinevalue * 100) / 100 ==  Math.round(this.m_startLineX * 100) / 100 )  this.m_startLineX = this.pos.grpEX + this.pos.barW / 2;
	}*/
	
    //백그라운드 클리어
	this.canvasClear();
	
    //텍스트 기본 셋팅
    this.ctx.font = this.TEXT_SIZE + " '" + this.FONT_FAMILY + "'";
    this.ctx.textBaseline = 'middle';
	
	this.count = 0;
    this.drawBackLine(m_scrollYN);
	
	/*if(!theApp.m_lineMovecheck)
	{
		if (this.animationRequestId) {
			cancelAnimationFrame(this.animationRequestId);
		}
	}
	
	this.lastFrameTime = Date.now();
	this.animateBackLine();
	this.m_ischeckking = true;*/
	
};


/*******************************************************
========================================================
	차트 캔버스 그리는 보조 함수
========================================================
*******************************************************/

// 애니메이션 시도
Icandleback.prototype.animateBackLine = function() 
{
    var currentTime = Date.now();
    var deltaTime = currentTime - this.lastFrameTime;
    this.lastFrameTime = currentTime;

    if (!theApp.baseData || theApp.baseData.length == 0)
        return;
		
	var lineX = this.verticallineX;
	if (theApp.m_lineMovecheck) {
        this.lineXPosition = (this.lineXPosition || lineX) - (deltaTime * 0.01); // 속도 조절

        var xxxx = this.pos.barTot;
        var ekwkkw = lineX - xxxx;

        if (this.lineXPosition <= ekwkkw) {
            this.lineXPosition = ekwkkw; // 위치 고정
        }
    } else {
        var speed = 0.5; // 가속도 기반 이동 속도
        this.lineXPosition += (lineX - this.lineXPosition) * speed * deltaTime * 0.001; // 부드럽게 원래 위치로 이동
    }
	this.canvasClear();
	
    // 가로선 그리기 3과 5만 만듬
    this.drawBackHori(1.5, this.colorObj.DOT, 5, '#ffffff');
    // 세로선 그리기 고민좀 해야겠다
    this.drawBackVert(theApp.baseData, this.lineXPosition, '#ffffff');
	this.count += 1;
	
	this.animationRequestId = requestAnimationFrame(this.animateBackLine.bind(this));
};

//백그라운드 기본 라인 그리기
Icandleback.prototype.drawBackLine = function(mscrollYN) 
{
	if (!theApp.baseData || theApp.baseData.length == 0)
        return;
	
	var lineX  = null, roundeValue = 0;
	this.m_YamYs = [];
	
	if(mscrollYN) lineX = this.verticallineX - this.mstartminu;
	else lineX = this.verticallineX;
	
	// 가로선 그리기 3과 5만 만듬
	this.drawBackHori(1.5, this.colorObj.DOT, 5, '#ffffff');
	
   	// 세로선 그리기 고민좀 해야겠다
	if(mscrollYN)
	{
		let secondRound = Math.round(((this.verticallineX -  lineX) / this.pos.barTot) * 100) / 100;
		let firstRound  = Math.round(secondRound * 10) / 10;
		roundeValue = Math.round(firstRound);
		this.drawBackVertNull(roundeValue, this.verticallineX, theApp.baseData, '#ffffff');
	}
	else this.drawBackVert(theApp.baseData, lineX, '#ffffff');
};


/*******************************************************
========================================================
	캔버스 그리는 다양한 종료를 그리기 함수
========================================================
*******************************************************/

//백그라운드 가로선 그리기
Icandleback.prototype.drawBackHori = function(w, color, linevalue, fcolor) 
{
	 //도트 그리기
    this.ctx.lineWidth = w;
    this.ctx.strokeStyle = color;
	this.ctx.fillStyle = fcolor;
	this.ctx.textAlign = 'right';
	
    //가로선
    for ( var i = 0; i < 5; i++)
	{
		if(linevalue == 5) 
		{
			//this.ctx.dashedLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i], this.dashType); //도트그리기
			this.ctx.solidLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i]); // 선 그리기
		}
		else if(linevalue == 3)
		{
			if(i%2 ==0)
			{
				//this.ctx.dashedLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i], this.dashType); //도트그리기
				this.ctx.solidLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i]); //선그리기
			}
		}
	}
	if(linevalue == 5)
	{
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm), this.pos.amPad, this.pos.amYs[0]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.25)), this.pos.amPad, this.pos.amYs[1]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.5)), this.pos.amPad, this.pos.amYs[2]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.75)), this.pos.amPad, this.pos.amYs[3]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(this.upGrpMinAm), this.pos.amPad, this.pos.amYs[4]);
		this.m_YamYs.push(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm), theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.25)), theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.5)), theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.75)), theApp.Icandlechart._getDecimalValue(this.upGrpMinAm));
	}
	else if(linevalue == 3)
	{
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm), this.pos.amPad, this.pos.amYs[0]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.5)), this.pos.amPad, this.pos.amYs[2]);
		this.ctx.fillText(theApp.Icandlechart._getDecimalValue(this.upGrpMinAm), this.pos.amPad, this.pos.amYs[4]);
		this.m_YamYs.push(theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm), theApp.Icandlechart._getDecimalValue(theApp.upGrpMaxAm - ((theApp.upGrpMaxAm - this.upGrpMinAm) * 0.5)), theApp.Icandlechart._getDecimalValue(this.upGrpMinAm));
	}
	
};

//백그라운드 세로선 그리기
Icandleback.prototype.drawBackVert = function(data, lineX, fcolor) 
{
	// 오브젝트 중요
	var timeObj = null;
	var dataOne = null;
	
	//세로선 틱
	for ( i = theApp.g_endIdx -1; i > theApp.g_startIdx; i--) 
	{
		timeObj = {};
		lineX -= this.pos.barTot;
		dataOne = data[i];
		if(this.m_bongcharttype == 'sec')
		{
			timeObj.d = dataOne.secDate;
			timeObj.t = dataOne.secTime;
			timeObj.x = lineX;
		}
		else
		{
			timeObj.d = dataOne.tickDate;
			timeObj.t = dataOne.tickTime;
			timeObj.x = lineX;
		}
		theApp.m_timeX.push(timeObj);

		if(i % this.m_xcount == 0)
		{
			//this.ctx.dashedLine(lineX - 1, 0, lineX, this.pos.dwGrpEY, this.dashType); //도트그리기
			this.ctx.solidLine(lineX - 1, 0, lineX, this.pos.dwGrpEY);  //선그리기

			this.ctx.fillStyle = fcolor;
			this.ctx.textAlign = 'center';

			this.ctx.fillText(timeObj.t, lineX, this.pos.dwDtY);
		}
	}
};

//백그라운드 세로선 없는값 그리기
Icandleback.prototype.drawBackVertNull = function(lineNum, lineX, data, fcolor) 
{
	// 오브젝트 중요
	var timeObj = null;
	var dataOne = null;
	
	//세로선 틱
	for ( i = theApp.g_endIdx -1 + lineNum; i > theApp.g_startIdx; i--) 
	{
		timeObj = {};
		lineX -= this.pos.barTot;
		if(data[i])
		{
			dataOne = data[i];
			if(this.m_bongcharttype == 'sec')
			{
				timeObj.d = dataOne.secDate;
				timeObj.t = dataOne.secTime;
				timeObj.x = lineX;
			}
			else
			{
				timeObj.d = dataOne.tickDate;
				timeObj.t = dataOne.tickTime;
				timeObj.x = lineX;
			}
			theApp.m_timeX.push(timeObj);
			
			if(i % this.m_xcount == 0)
			{
				//this.ctx.dashedLine(lineX - 1, 0, lineX, this.pos.dwGrpEY, this.dashType); //도트그리기
				this.ctx.solidLine(lineX - 1, 0, lineX, this.pos.dwGrpEY);  //선그리기

				this.ctx.fillStyle = fcolor;
				this.ctx.textAlign = 'center';

				this.ctx.fillText(timeObj.t, lineX, this.pos.dwDtY);
			}
		}
		else
		{
			if(i % this.m_xcount == 0)
			{
				//this.ctx.dashedLine(lineX - 1, 0, lineX, this.pos.dwGrpEY, this.dashType); //도트그리기
				this.ctx.solidLine(lineX - 1, 0, lineX, this.pos.dwGrpEY);  //선그리기
			}
		}
	}
};


