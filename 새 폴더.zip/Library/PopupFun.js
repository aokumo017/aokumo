function PopupFun()
{
}


PopupFun.fullpopup = function(url, data, callback)
{
	var wind = 'binal_win_' + Date.now(),
		wmsg = new AWindow(wind),
		wLay = url;

	wmsg.setResultCallback(callback);
	wmsg.setData(data);
	wmsg.openFull(wLay);
};


PopupFun.whDialogpopup = function(thisObj, url, data, left, top, width, height, callback)
{
	var wind = 'binal_win_' + Date.now(),
		wmsg = new AWindow(wind),
		wLay = url;
	
	thisObj.window099 = wmsg;
	wmsg.setWindowOption({
		isModal : true,
		isCenter : false,
		isFocusLostClose : false,
		modalBgOption : 'light'
	});

	wmsg.setResultCallback(callback);
	wmsg.setData(data);
	wmsg.open(wLay, thisObj.getContainer(), left, top, width, height);
};

PopupFun.whDialogpopupCenter = function(url, data, left, top, width, height, callback)
{
	var wind = 'binal_win_' + Date.now(),
		wmsg = new AWindow(wind),
		wLay = url;
	
	wmsg.setWindowOption({
		isModal : true,
		isCenter : true,
		isFocusLostClose : false,
		modalBgOption : 'light'
	});

	wmsg.setResultCallback(callback);
	wmsg.setData(data);
	wmsg.open(wLay, null, left, top, width, height);
};