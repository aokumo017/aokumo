function Icandlepos()
{
	// 변경값
	this.ROW_CNT = ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.dotDegree = [0, 1, 2, 3]; //상단 그래프 금액 구분선 Y좌표 배열
	
	this.TEXT_SIZE = '16px';			//폰트 사이즈
	this.FONT_FAMILY = 'Regular';		// 폰트체
	
	this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
	this.AM_R_WIDTH = AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BAR_CNT = BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.m_downheight = DOWNHEIGHT; //상단 그래프 끝 Y좌표
	
	this.blance_pointRadius = 5; 	// 잔고 콜 풋 원그리기 너비
	this.DEF_BAR_W = 8;
	
	// 간격
	this.BAR_TERM = 2;		//봉차트간 간격
	
	// 기본값 
	
	// 중요 콜 데이터
	theApp.m_CellDataArr = {};
	
	// 중요 풋 데이터
	theApp.m_PutDataArr = {};
	
	
	//색상값
	this.colorObj = {
		ARCTRC : 'rgba(0, 255, 0, 0.5)', 	// 깜박깜박 투명색
		LINEARC : 'green', 					// 라인끝에 원 중앙 색상
		LINEARCGR : 'transparent',			// 라인끝에 원색상 그라데이션
		MOVELINE : 'rgba(0, 255, 0, 0.5)',	// 라인선 색
		CALLORD : '#04db00',				// 잔고 콜 컬러
		CALLORDSHD : 'rgba(0, 247, 8, 1)', 	// 잔고 콜 쉐도우
		PUTORD : '#ff1717', 				// 잔고 풋 컬러
		PUTORDSHD : 'rgba(247, 0, 0, 1)' 	// 잔고 풋 쉐도우
	};
	
	// 위치값
	this.pos =
	{
        cavasW : 0,		//전체 캔버스 너비   필요
        cavasH : 0,		//전체 캔버스 높이   필요
        grpW : 0,		//상단,하단 그래프영역 너비
        grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
        dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
        amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
        amPad : 0,		//금액 오른쪽 정렬시 마진
        txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

        upGrpSY : 0,	//상단 그래프 시작 Y좌표
        upDtY : 0,		//상단 그래프 Date 영역 Y
        upGrpEY : 0,	//상단 그래프 끝 Y좌표
        upGrpH : 0,		//상단 그래프 그리는 영역 높이
        kbnY : 0,		//상단,하단 그래프 구분Y
        dwGrpSY : 0,	//하단 그래프 시작 Y좌표
        dwDtY : 0,		//하단 그래프 Date 영역 Y
        dwGrpEY : 0,	//하단 그래프 끝 Y좌표
        dwGrpH : 0,		//하단 그래프 그리는 영역 높이

        dw80Y : 0,		//하단 80퍼센트 높이
        dw20Y : 0,		//하단 20퍼센트 높이

        upRateH : 0,	//상단 높이 비율
        dwRateH : 0,	//하단 높이 비율

        barW : this.DEF_BAR_W, //봉차트 너비

        barTot : 0,		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    };
	
	this.m_height = 4;     // 높이 위치 조정 값 
	this.m_amYsvalue = 0; // 높이 간격 계산값
}


/*******************************************************
========================================================
	차트 데이터 그래프 초기화 함수
========================================================
*******************************************************/

// 그래프 초기화
Icandlepos.prototype.canvasClear = function()
{
	 this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
};


/*******************************************************
========================================================
	차트 기본값입력
========================================================
*******************************************************/

// 다시 설정해야함
Icandlepos.prototype.reCalcWidth = function(cnt) 
{
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;			//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);		//봉차트 너비
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
Icandlepos.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;									//캔버스 너비   필요
    this.pos.cavasH = elHeight;									//캔버스 높이   필요
	
    this.pos.grpEX = elWidth - this.AM_R_WIDTH;   				//상단,하단 오른쪽 금액영역 너비   100
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;			//상단,하단 왼쪽 금액영역 너비     0

    this.pos.amPad = elWidth - 5;								//금액 오른쪽 정렬시 마진

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];   //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]

    this.pos.upGrpSY = elHeight / this.ROW_CNT;			//상단 그래프 시작 Y좌표
    this.pos.txtY = (this.pos.upGrpSY / 2);				//텍스트 세로 중간 정렬을 위한 Y위치
	
	this.pos.upGrpEY = elHeight - this.m_downheight;		//상단 그래프 끝 Y좌표
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;			//상단 그래프 그리는 영역 높이
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;				//상단 그래프 Date 영역 Y
	
	this.m_amYsvalue = (this.pos.upGrpEY - this.pos.upGrpSY ) / this.m_height;
	this.pos.amYs = [this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[0]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[1]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[2]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[3]), this.pos.upGrpEY];  //상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
	
    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수    //상단,하단 그래프 구분Y
	
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;		//하단 그래프 시작 Y좌표
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;		//하단 그래프 끝 Y좌표
    this.pos.dwDtY = this.pos.dwGrpEY  + this.pos.txtY;			//하단 그래프 Date 영역 Y
    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;		//하단 그래프 그리는 영역 높이
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;		//하단 80퍼센트 높이
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;		//하단 20퍼센트 높이

    //텍스트 사이즈 셋팅
    /*if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW * 0.03) + 'px';
    else this.TEXT_SIZE = (this.pos.cavasH * 0.03) + 'px';*/

    this.reCalcWidth();
	
	// 시작 위치
	//this.startLineX = this.pos.grpEX + this.pos.barW / 2; // 데이터 배열이 앞일경우에 이게 해당
	this.startLineX = 0; // 데이터 배열이 뒤일경우에 이게 해당
};


/*******************************************************
========================================================
	차트 외부 기본값입력 
========================================================
*******************************************************/

// ctx 캔버스 값 넘기기
Icandlepos.prototype.setCTX = function(ctx, canvas)
{
	this.canvas = canvas;
	this.ctx = ctx;
};

// 초인지 분인지
Icandlepos.prototype.setTimeTypeback = function(type)
{
	this.m_bongcharttype = type;
};

// 차트 변경값 변경
Icandlepos.prototype.setChangewidhtvalue = function(Obj)
{
	this.AM_R_WIDTH = Obj.AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BOXWIDTH = Obj.BOXWIDTH;	//네모 박스 너비
	this.BAR_CNT = Obj.BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.ROW_CNT = Obj.ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.m_downheight = Obj.DOWNHEIGHT; //상단 그래프 끝 Y좌표
	this.m_xcount = Obj.MXCOUNT;  // 틱기준 자르는기준
};


/*******************************************************
========================================================
	차트 외부 데이터 입력값 함수
========================================================
*******************************************************/

// Cell 데이터 들어올때
Icandlepos.prototype.CellData = function(cellData, keyArr) 
{
	let callkey = '', params_sec = '', params_min5, params_min10, params_posvalue = null, callpretick_timecheck, callprecheck_value;
	// 중요 콜 데이터
	if(this.m_bongcharttype == 'sec')
	{
		callkey = `${cellData.buy_date}-${cellData.ord_time}`;
	}
	else if(this.m_bongcharttype == 'min.1')
	{
		params_sec = UtilityF.replaceSecondsWithZero(cellData.ord_time);
		callkey = `${cellData.buy_date}-${params_sec}`;
	}
	else if(this.m_bongcharttype == 'min.5')
	{
		params_posvalue = Number(cellData.ord_time.split(':')[1]);
		params_sec = UtilityF.replaceSecondsWithZero(cellData.ord_time);
		callpretick_timecheck = Math.floor(params_posvalue / 5);
		callprecheck_value = theApp.util_mintick[0][callpretick_timecheck - 1] || 0;
		if(callprecheck_value == 0)
		{
			params_min5 = UtilityF.replaceMinutes(params_sec);
			callkey = `${cellData.buy_date}-${params_min5}`;
		}
		else
		{
			params_min5 = params_sec.replace(/:(\d{2}):/, `:${callprecheck_value}:`);
			callkey = `${cellData.buy_date}-${params_min5}`;
		}
	}
	else if(this.m_bongcharttype == 'min.10')
	{
		params_posvalue = Number(cellData.ord_time.split(':')[1]);
		params_sec = UtilityF.replaceSecondsWithZero(cellData.ord_time);
		callpretick_timecheck = Math.floor(params_posvalue / 10);
		callprecheck_value = theApp.util_mintick[1][callpretick_timecheck - 1] || 0;
		if(callprecheck_value == 0)
		{
			params_min10 = UtilityF.replaceMinutes(params_sec);
			callkey = `${cellData.buy_date}-${params_min10}`;
		}
		else
		{
			params_min10 = params_sec.replace(/:(\d{2}):/, `:${callprecheck_value}:`);
			callkey = `${cellData.buy_date}-${params_min10}`;
		}
	}
	
	theApp.m_CellDataArr[callkey] = cellData;
	if(TESTLOG == 1) console.log('콜들어올때 차트 변수', theApp.m_CellDataArr);
	this.posdraw();
};

// Put 데이터 들어올때
Icandlepos.prototype.PutData = function(putData, keyArr) 
{
	// 중요 풋 데이터
	let putkey = '', params_sec = '', params_min5, params_min10, params_posvalue = null, putpretick_timecheck, putprecheck_value;
	if(this.m_bongcharttype == 'sec')
	{
		putkey = `${putData.buy_date}-${putData.ord_time}`;
	}
	else if(this.m_bongcharttype == 'min.1')
	{
		params_sec = UtilityF.replaceSecondsWithZero(putData.ord_time);
		putkey = `${putData.buy_date}-${params_sec}`;
	}
	else if(this.m_bongcharttype == 'min.5')
	{
		params_posvalue = Number(putData.ord_time.split(':')[1]);
		params_sec = UtilityF.replaceSecondsWithZero(putData.ord_time);
		putpretick_timecheck = Math.floor(params_posvalue / 5);
		putprecheck_value = theApp.util_mintick[0][putpretick_timecheck - 1] || 0;
		if(putprecheck_value == 0)
		{
			params_min5 = UtilityF.replaceMinutes(params_sec);
			putkey = `${putData.buy_date}-${params_min5}`;
		}
		else
		{
			params_min5 = params_sec.replace(/:(\d{2}):/, `:${putprecheck_value}:`);
			putkey = `${putData.buy_date}-${params_min5}`;
		}
	}
	else if(this.m_bongcharttype == 'min.10')
	{
		params_posvalue = Number(putData.ord_time.split(':')[1]);
		params_sec = UtilityF.replaceSecondsWithZero(putData.ord_time);
		putpretick_timecheck = Math.floor(params_posvalue / 10);
		putprecheck_value = theApp.util_mintick[1][putpretick_timecheck - 1] || 0;
		if(putprecheck_value == 0)
		{
			params_min10 = UtilityF.replaceMinutes(params_sec);
			putkey = `${putData.buy_date}-${params_min10}`;
		}
		else
		{
			params_min10 = params_sec.replace(/:(\d{2}):/, `:${putprecheck_value}:`);
			putkey = `${putData.buy_date}-${params_min10}`;
		}
	}
	
	theApp.m_PutDataArr[putkey] = putData;
	this.posdraw();
};

// Cell 데이터 나갈때
Icandlepos.prototype.CellDataBye = function(cleanObj) 
{
	this.deleteByValue(theApp.m_CellDataArr, cleanObj.buy_no);
	if(TESTLOG == 1) console.log('콜나갈때 차트 변수', theApp.m_CellDataArr);
    this.posdraw();
};

// Put 데이터 나갈때
Icandlepos.prototype.PutDataBye = function(cleanObj) 
{
	this.deleteByValue(theApp.m_PutDataArr, cleanObj.buy_no);
    this.posdraw();
};

//그래프의 너비 및 높이를 업데이트
Icandlepos.prototype.updatePosition = function(pWidth, pHeight) {
    this.calcPosition(pWidth, pHeight);
};


/*******************************************************
========================================================
	차트 캔버스 그리는 함수
========================================================
*******************************************************/

//차트 진짜 그리기 함수 모음
Icandlepos.prototype.posdraw = function() 
{	
	if(!theApp.m_lineMovecheck) 
	{
		 //pos 클리어
		this.canvasClear();
		this.setposdrawhashtable();
	}
};

//잔고 그리기
Icandlepos.prototype.setposdrawhashtable = function() 
{
	var cie = null, pie = null ;
	let currentsisay, callSkey, callSvalue, putSkey, putSvalue;
	if (Object.keys(theApp.m_balncejongo).length === 0) 
	{
		if(TESTLOG == 3) console.log("객체가 비어있습니다.");
		return;
	} 
	else 
	{
		// 잔고 로스컷 표시
		let call_length = Object.keys(theApp.m_CellDataArr);
		let put_length = Object.keys(theApp.m_PutDataArr);
		let firstKey = Object.keys(theApp.m_balncejongo)[0];
		const firstValue = theApp.m_balncejongo[firstKey];
		
		if(TESTLOG == 3) console.log('원래  들어간데이터', theApp.m_balncejongo);
		if(TESTLOG == 3) console.log('콜 데이터 : ', theApp.m_CellDataArr);
		
		if(call_length.length != 0)
		{
			for(cie = 0; cie < call_length.length; cie++)
			{
				if(this.m_bongcharttype == 'sec')
				{
					callSkey = call_length[cie];
					currentsisay = theApp.m_balncejongo[callSkey];
					callSvalue = theApp.m_CellDataArr[callSkey];
					// 잔고표시
					if(callSvalue != undefined && currentsisay != undefined)
					{
						if(currentsisay.symbol ===  callSvalue.symbol)
						{
							this.drawblance(this.colorObj.CALLORD, this.colorObj.CALLORDSHD, currentsisay.x, currentsisay.y);
						}
					}
					// 로스컷 표시
					/*if(firstValue.symbol ===  callSvalue.symbol)
					{
						this.drawloss(this.colorObj.CALLORD, 0, this.pos.upGrpSY + (theApp.upGrpMaxAm - callSvalue.loss_prc) * theApp.upRateH, 60, 1);
					}*/
					
				}
				else
				{
					// 분틱 일경우
					callSkey = call_length[cie];
					currentsisay = theApp.m_balncejongo[callSkey];
					callSvalue = theApp.m_CellDataArr[callSkey];
					// 잔고표시
					if(callSvalue != undefined && currentsisay != undefined)
					{
						if(currentsisay.symbol ===  callSvalue.symbol)
						{
							//this.drawblance(this.colorObj.CALLORD, this.colorObj.CALLORDSHD, currentsisay.x, currentsisay.y);
							this.drawblance(this.colorObj.CALLORD, this.colorObj.CALLORDSHD, currentsisay.x, this.pos.upGrpSY + (theApp.upGrpMaxAm - callSvalue.ord_prc) * theApp.upRateH);
						}
					}
					// 로스컷 표시
					/*if(firstValue.symbol ===  callSvalue.symbol)
					{
						this.drawloss(this.colorObj.CALLORD, 0, this.pos.upGrpSY + (theApp.upGrpMaxAm - callSvalue.loss_prc) * theApp.upRateH, 60, 1);
					}*/
				}
			}
		}

		if(put_length.length != 0)
		{
			for(pie = 0; pie < put_length.length; pie++)
			{
				if(this.m_bongcharttype == 'sec')
				{
					putSkey = put_length[pie];
					currentsisay = theApp.m_balncejongo[putSkey];
					putSvalue = theApp.m_PutDataArr[putSkey];
					// 잔고표시
					if(putSvalue != undefined && currentsisay != undefined)
					{
						if(currentsisay.symbol ===  putSvalue.symbol)
						{
							this.drawblance(this.colorObj.PUTORD, this.colorObj.PUTORDSHD, currentsisay.x, currentsisay.y);
						}
					}
					// 로스컷 표시
					/*if(firstValue.symbol ===  putSvalue.symbol)
					{
						this.drawloss(this.colorObj.PUTORD, 0, this.pos.upGrpSY + (theApp.upGrpMaxAm - putSvalue.loss_prc) * theApp.upRateH, 60, 0);
					}*/
					
				}
				else
				{
					// 분틱 일경우
					putSkey = put_length[pie];
					currentsisay = theApp.m_balncejongo[putSkey];
					putSvalue = theApp.m_PutDataArr[putSkey];
					// 잔고표시
					if(putSvalue != undefined && currentsisay != undefined)
					{
						if(currentsisay.symbol ===  putSvalue.symbol)
						{
							//this.drawblance(this.colorObj.PUTORD, this.colorObj.PUTORDSHD, currentsisay.x, currentsisay.y);
							this.drawblance(this.colorObj.PUTORD, this.colorObj.PUTORDSHD, currentsisay.x, this.pos.upGrpSY + (theApp.upGrpMaxAm - putSvalue.ord_prc) * theApp.upRateH);
						}
					}
					// 로스컷 표시
					/*if(firstValue.symbol ===  putSvalue.symbol)
					{
						this.drawloss(this.colorObj.PUTORD, 0, this.pos.upGrpSY + (theApp.upGrpMaxAm - putSvalue.loss_prc) * theApp.upRateH, 60, 1);
					}*/
				}
			}
		}
		
	}
};


/*******************************************************
========================================================
	차트 캔버스 그리는 보조 함수
========================================================
*******************************************************/

//잔고 표시 그리기
Icandlepos.prototype.drawblance = function(color, rgba, x, pricey) 
{
	const topY = pricey - 50 / 2;
    const bottomY = pricey + 50 / 2;
	
	// 그림자 속성 설정
	this.ctx.shadowColor = rgba;
	this.ctx.shadowBlur = 20;
	this.ctx.shadowOffsetX = 0;
	this.ctx.shadowOffsetY = 0;
	
	// 원 그리기 (큰 원)
	this.ctx.beginPath();
	this.ctx.arc(x, pricey, this.blance_pointRadius, 0, 2 * Math.PI, false);
	this.ctx.fillStyle = color;
	this.ctx.fill();
	this.ctx.closePath();
	
	this.ctx.shadowColor = 'transparent'; // 그림자를 제거
};

//로스컷 표시 그리기
Icandlepos.prototype.drawloss = function(color, x, lossy, value, cpinfo) 
{
	//로스컷 선그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = 1;
	this.ctx.strokeStyle = color;
	// 선그리기
	this.ctx.moveTo(0, lossy);
	this.ctx.lineTo(this.pos.cavasW, lossy);
	this.ctx.stroke();
	this.ctx.closePath();
};




/*******************************************************
========================================================
	기본 함수 모음
========================================================
*******************************************************/

Icandlepos.prototype.deleteByValue = function(obj, value) 
{
	for (let key in obj) {
		if (obj[key].invest_no === value) {
			delete obj[key];
			break; // Stop after deleting the first occurrence
		}
	}
};

//오더 시세 체결 데이터
Icandlepos.prototype.findOneSecondDifference = function(data, dateStr) 
{
   	let foundObject = data.find(element => element.t === dateStr);
	return foundObject;
};

// 시간 차이를 계산하고 가장 가까운 시간을 찾는 함수  1초 1분 5분 10분  분봉에따라 값이 차이가나야함
/*function Icandlepos*findOneSecondDifference(data, dateStr,  timeStr) 
{
	var thisObj = this;
	const targetDate = dateStr;
    const targetTime = timeStr;
	
	//console.log('기존데이터', data);
	//console.log('타켓 시간데이터 : ', targetTime);
	
   const oneSecond = millisecond; // 1000 milliseconds in one second

    for (const item of data) {
        const itemTime = new Date(`2024-01-01T${item.t}Z`);
        const diff = Math.abs(itemTime - targetTime);
		//console.log('타겟 타임 : ',targetTime);
		//console.log('타임 시간  : ',itemTime);
		//console.log('차이는 : ',diff);
        if (diff <= oneSecond) {
            return item;
        }
    }

    return null; // 1초 차이나는 항목이 없으면 null 반환
	
	
	const targetTimeSeconds = this.timeToSeconds(targetTime);

    let filteredData = data.filter(entry => entry.d === targetDate);
    if (filteredData.length === 0) {
        return { min: null, max: null };
    }

    let minEntry = null;
    let maxEntry = null;
    let minTimeDifference = Infinity;
    let maxTimeDifference = -Infinity;

    filteredData.forEach(entry => {
        const entryTimeSeconds = thisObj.timeToSeconds(entry.t);
        const timeDifference = entryTimeSeconds - targetTimeSeconds;
		
		const targetMinutes = targetTime.split(':')[1];
        const entryMinutes = entry.t.split(':')[1];

        // Ensure the minutes match
        if (targetMinutes !== entryMinutes) {
            return;
        }

        if (timeDifference <= 0 && timeDifference >= maxTimeDifference) {
            maxEntry = entry;
            maxTimeDifference = timeDifference;
        }

        if (timeDifference >= 0 && timeDifference <= minTimeDifference) {
            minEntry = entry;
            minTimeDifference = timeDifference;
        }
    });

    return { min: minEntry, max: maxEntry };
	
};*/

Icandlepos.prototype.timeToSeconds = function(time) 
{
	const [hours, minutes, seconds] = time.split(':').map(Number);
	return hours * 3600 + minutes * 60 + seconds;
};

