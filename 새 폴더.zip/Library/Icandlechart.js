// 클래스 기본 변수정의
function Icandlechart()
{
	/* ======== 변경값  =========*/
	
	theApp.m_lineMovecheck = false;	// 추가 업데이트 여부에따라 true 그냥 그리는거는 false
	this.DEF_BAR_W = 8;		//기본 봉 너비
	
	// 위치 간격 변수
	this.AM_R_WIDTH = AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
    this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
	this.m_downheight = DOWNHEIGHT; //상단 그래프 끝 Y좌표
	this.dotDegree = [0, 1, 2, 3]; //상단 그래프 금액 구분선 Y좌표 배열
	this.ROW_CNT = ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	
	// 너비 간격 변수
	this.BAR_CNT = BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	
	// 데이터 시작위치 변수
	theApp.g_startIdx = 0;
	theApp.g_endIdx = 0;
	this.upEndDegree = 13;  // 값 왼족 끝 값 처리
	this.mstartminu = 100;  // 값 너비와 그리기 사이에 간격
	
	// 간격
	this.BAR_TERM = 1.5;		//봉차트간 간격
	
	this.TEXT_SIZE = '10px';
	this.FONT_FAMILY = 'SpoqaHanSansNeo-Regular';
	//네모 박스 너비
	this.BOXWIDTH = BOXWIDTH;
	
	// 높이 위치 조정 값
	this.m_height = 4;     
	this.m_amYsvalue = 0; // 높이 간격 계산값
	
	// x 측 움직이는 가격 기준값
	this.m_xcount = MXCOUNT;  // 틱기준 자르는기준
	
	/* ======== 기본값  =========*/
	
	theApp.baseData = [];
	theApp.m_timeX = [];
	theApp.m_priceY = [];
	
	// 중요 잔고 참조시세
	theApp.m_balncejongo = {};
	
	//봉차트일때 업데이트인지 아닌지구분값
	theApp.g_syposgoY = true;
	
	// 그리기 타입 저장 변수
	this.m_chartdrowType = 1;
	
	// 스크롤시 실시간 움직이지 않게
	this.m_scrollYN = true;
	
	/* ======== 색상값  =========*/
	
	this.colorObj = {
		LINEARC : 'green', 				// 라인끝에 원 중앙 색상
		LINEARCGR : 'transparent', 		// 라인끝에 원색상 그라데이션
		DOT : '#d9dbe5', 				//차트 전체 도트 색
		MOVELINE : '#0055d8',      		//마우스 선 and 텍스트박스
    	PRCTEXT : '#000',        	//현재가 텍스
		LINESUNTE : '#5777a0'			// 라인선색깔
    };
	
	/* ======== 위치값  =========*/
	
	this.pos =
	{
		cavasW : 0,		//전체 캔버스 너비   필요
		cavasH : 0,		//전체 캔버스 높이   필요
		grpW : 0,		//상단,하단 그래프영역 너비
		grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
		dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
		amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
		amPad : 0,		//금액 오른쪽 정렬시 마진
		txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

		upGrpSY : 0,	//상단 그래프 시작 Y좌표
		upDtY : 0,		//상단 그래프 Date 영역 Y
		upGrpEY : 0,	//상단 그래프 끝 Y좌표
		upGrpH : 0,		//상단 그래프 그리는 영역 높이
		kbnY : 0,		//상단,하단 그래프 구분Y
		dwGrpSY : 0,	//하단 그래프 시작 Y좌표
		dwDtY : 0,		//하단 그래프 Date 영역 Y
		dwGrpEY : 0,	//하단 그래프 끝 Y좌표
		dwGrpH : 0,		//하단 그래프 그리는 영역 높이

		dw80Y : 0,		//하단 80퍼센트 높이
		dw20Y : 0,		//하단 20퍼센트 높이

		upRateH : 0,	//상단 높이 비율
		dwRateH : 0,	//하단 높이 비율

		barW : this.DEF_BAR_W, //봉차트 너비

		barTot : 0,		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
	};
}


/*******************************************************
========================================================
	차트 데이터 그래프 초기화 함수
========================================================
*******************************************************/

// 그래프 초기화
Icandlechart.prototype.canvasClear = function()
{
	 this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
};

// 데이터 완전 초기화
Icandlechart.prototype.resetData = function(isFirst)
{
	theApp.baseData = [];
	theApp.g_startIdx = 0;
	theApp.g_endIdx = 0;

	theApp.upGrpMaxAm = 0;
	theApp.g_syposgoY = true;
	this.animationId = null; // To store the requestAnimationFrame ID
};


/*******************************************************
========================================================
	차트 기본값입력
========================================================
*******************************************************/

// 다시 설정해야함
Icandlechart.prototype.reCalcWidth = function(cnt) 
{
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;			//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);		//봉차트 너비
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
Icandlechart.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;									//캔버스 너비   필요
    this.pos.cavasH = elHeight;									//캔버스 높이   필요
	
    this.pos.grpEX = elWidth - this.AM_R_WIDTH;   				//상단,하단 오른쪽 금액영역 너비   100
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;			//상단,하단 왼쪽 금액영역 너비     0

    this.pos.amPad = elWidth - 5;								//금액 오른쪽 정렬시 마진

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];   //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]

    this.pos.upGrpSY = elHeight / this.ROW_CNT;			//상단 그래프 시작 Y좌표
    this.pos.txtY = (this.pos.upGrpSY / 2);				//텍스트 세로 중간 정렬을 위한 Y위치
	
	this.pos.upGrpEY = elHeight - this.m_downheight;		//상단 그래프 끝 Y좌표
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;			//상단 그래프 그리는 영역 높이
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;				//상단 그래프 Date 영역 Y
	
	this.m_amYsvalue = (this.pos.upGrpEY - this.pos.upGrpSY ) / this.m_height;
	this.pos.amYs = [this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[0]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[1]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[2]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[3]), this.pos.upGrpEY];  //상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
	
    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수    //상단,하단 그래프 구분Y
	
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;		//하단 그래프 시작 Y좌표
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;		//하단 그래프 끝 Y좌표
    this.pos.dwDtY = this.pos.dwGrpEY  + this.pos.txtY;			//하단 그래프 Date 영역 Y
    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;		//하단 그래프 그리는 영역 높이
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;		//하단 80퍼센트 높이
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;		//하단 20퍼센트 높이

    //텍스트 사이즈 셋팅
    /*if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW * 0.03) + 'px';
    else this.TEXT_SIZE = (this.pos.cavasH * 0.03) + 'px';*/

    this.reCalcWidth();
	
	// 시작 위치
	//this.startLineX = this.pos.grpEX + this.pos.barW / 2; // 데이터 배열이 앞일경우에 이게 해당
	this.startLineX = 0; // 데이터 배열이 뒤일경우에 이게 해당

    //서브타입을 기준으로 서브 차트를 그리기위한 함수 셋팅
    //this.settingDrawSubGrp();
};

//차트를 그릴 원시데이터 가공
Icandlechart.prototype.makeChartCanvasData = function(dataArrObj, keyArr) 
{
	//console.log('들어온데이터 : ',dataArrObj);
	
    var len = dataArrObj.length;

    if (len < 1) return;
	
    /*if(this.BAR_CNT>len)
    {
    	this.reCalcWidth(len);
    }*/
	
	theApp.baseData = dataArrObj;
};


/*******************************************************
========================================================
	차트 외부 기본값입력 
========================================================
*******************************************************/

// ctx 캔버스 값 넘기기
Icandlechart.prototype.setCTX = function(ctx, canvas)
{
	this.canvas = canvas;
	this.ctx = ctx;
	this.animationState = { active: false };
};

// ctx 캔버스 값 넘기기
Icandlechart.prototype.setChartType = function(type)
{
	this.m_chartdrowType = type;
};

// 소수점 넘기기
Icandlechart.prototype.setDecimalValue = function(value)
{
	this.m_decimalga = value;
};

// 초인지 분인지
Icandlechart.prototype.setTimeTypeback = function(type)
{
	this.m_bongcharttype = type;
};

// 차트 변경값 변경
Icandlechart.prototype.setChangewidhtvalue = function(Obj)
{
	this.AM_R_WIDTH = Obj.AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BOXWIDTH = Obj.BOXWIDTH;	//네모 박스 너비
	this.BAR_CNT = Obj.BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.ROW_CNT = Obj.ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.m_downheight = Obj.DOWNHEIGHT; //상단 그래프 끝 Y좌표
	this.m_xcount = Obj.MXCOUNT;  // 틱기준 자르는기준
	this.BAR_TERM = Obj.BAR_TERM;	//봉차트간 간격
	
	if(TESTLOG == 1) console.log(' 조회 했을때의 최초 데이터 길이값 : ', this.BAR_CNT );
};


/*******************************************************
========================================================
	차트 외부 데이터 입력값 함수
========================================================
*******************************************************/

//데이터 초기화 한후 입력 하고자 할때 사용하는 함수 테스트용으로 도 사용 
Icandlechart.prototype.setDataClear = function(dataArrObj, keyArr) 
{
    this.resetData();
	theApp.m_lineMovecheck = false;
    this.makeChartCanvasData(dataArrObj, keyArr);
	if(TESTLOG == 1) console.log('실제 데이터', theApp.baseData);
    this.updateGraph();
};

//실시간 데이터 들어올때
Icandlechart.prototype.addRealData = function(realData, keyArr) 
{
	theApp.m_lineMovecheck = true;
	theApp.g_syposgoY = true;
	
	/*if(this.startIdx == 0)
	{
		theApp.baseData.splice(0, 5);
	}*/
	//theApp.baseData.unshift(realData);
	theApp.baseData.push(realData);
	/*if(this.startIdx == 0)
	{
		for(var i = 0; i < 5; i++)
		{
			var Objdata = this.getKoreanDateTime(i+1);
			Objdata.randomValue = 0;
			theApp.baseData.unshift(Objdata);
		}
	}*/
	
    this.updateGraph();
};

//실시간 업데이트 데이터 들어올때
Icandlechart.prototype.updateRealData = function(uprealData, keyArr) 
{
	theApp.g_syposgoY = false;
	if(this.m_bongcharttype == 'sec')
	{
		if(OPERATE_U == 1) theApp.m_lineMovecheck = false;
		else theApp.m_lineMovecheck = false;
		
		theApp.baseData[theApp.baseData.length - 1] = Object.assign(theApp.baseData[theApp.baseData.length - 1], uprealData);

		if(OPERATE_U == 2) if(theApp.baseData[theApp.baseData.length - 1].price == uprealData.price) return;
	}
	else
	{
		if(OPERATE_U == 1) theApp.m_lineMovecheck = true;
		else theApp.m_lineMovecheck = true;
		//console.log('실시간 업데이터 데이터 ', uprealData);
		theApp.baseData[theApp.baseData.length - 1] = uprealData;
	}
	
    this.updateGraph();
};

// 그래프의 너비 및 높이를 업데이트
Icandlechart.prototype.updatePosition = function(Width, Height)
{
	theApp.m_lineMovecheck = false;
	this.calcPosition(Width, Height);
};


/*******************************************************
========================================================
	차트 캔버스 기본 입력 셋
========================================================
*******************************************************/

//현재 그리는 데이터 오프셋 가져오기
Icandlechart.prototype.getOffset = function() {
	theApp.g_startIdx = theApp.baseData.length - this.BAR_CNT;
	theApp.g_endIdx  = theApp.baseData.length;
	if(theApp.g_startIdx < 0) theApp.g_startIdx = 0;
};

//리사이징후 위치인덱스 맞추기
Icandlechart.prototype.setOffsetResizing = function() {
	let pos_value = 0;
	const v_barcnt = this.calculateIndexDifference(theApp.g_startIdx, theApp.g_endIdx );
	if(v_barcnt === this.BAR_CNT) return;
	else
	{
		if(v_barcnt < this.BAR_CNT)
		{
			pos_value = this.BAR_CNT - v_barcnt;
			theApp.g_endIdx += pos_value;
			if(theApp.g_endIdx > theApp.baseData.length)
			{
				theApp.g_startIdx = theApp.baseData.length - this.BAR_CNT;
				theApp.g_endIdx = theApp.baseData.length;
			}
		}
		else if(this.BAR_CNT < v_barcnt)
		{
			pos_value = v_barcnt - this.BAR_CNT;
			theApp.g_endIdx -= pos_value;
		}
	}
};


/*******************************************************
========================================================
	차트 캔버스 그리는 함수
========================================================
*******************************************************/

//그래프 무조건 이걸로 호출 업데이트
Icandlechart.prototype.updateGraph = function() 
{
	if(this.m_scrollYN) this.getOffset();
	else this.setOffsetResizing();
	
	this.maKeyLen = 1;
	theApp.Icandleback.setMaxMin();
	
	this.draw();
};

//차트 진짜 그리기 함수 모음
Icandlechart.prototype.draw = function() 
{
	theApp.Icandlearc.canvasClear();
	theApp.Icandlebong.canvasClear();
	
	if(this.animationState)
	{
		if (this.animationState && this.animationState.active) return;
	}
	
	// 라인차트 그릴때 잔고 , 동그라미 초기화 해줘야함 이두개는 라인차트 위치값에 영향받음
	theApp.Icandlepos.canvasClear();

    //백그라운드 클리어
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	theApp.m_timeX = [];
	theApp.m_priceY = [];
	theApp.m_balncejongo = {};
	
    //텍스트 기본 셋팅  라인에서 필요 없을지도 나중에 지우자
    this.ctx.font = this.TEXT_SIZE + " '" + this.FONT_FAMILY + "'";
    this.ctx.textBaseline = 'middle';

	theApp.Icandleback.backdraw(this.m_scrollYN);
	
	/*if(!theApp.m_lineMovecheck)
	{
		if (this.animationRequestId) {
			cancelAnimationFrame(this.animationRequestId);
		}
	}*/
    this.drawGraph();
};


/*******************************************************
========================================================
	차트 캔버스 그리는 보조 함수		canvasClear
========================================================
*******************************************************/

//그래프 그리기
Icandlechart.prototype.drawGraph = function() 
{
    if (!theApp.baseData || theApp.baseData.length == 0) return;
	//this.lastFrameTime = Date.now();
	
	this.dynamicdrawGraph();
};

// 그래프 동적 정적 그리기만
Icandlechart.prototype.dynamicdrawGraph = function() 
{
	var thisObj = this;
	var currentTime = Date.now();
	var deltaTime = currentTime - this.lastFrameTime;
	this.lastFrameTime = currentTime;
	
	var data = theApp.baseData;
    var dataOne = null;
	
	// 현재 가격 텍스트 라인까지 그려지는 X축 선 그리기

	
	/*var lineXolny = 0;
	if(theApp.m_lineMovecheck)
	{
		lineXolny = this.startLineX - this.mstartminu;
		this.lineXPosition = (this.lineXPosition || lineXolny) - (deltaTime * 0.01); // 속도 조절
		
		var xxxx = this.pos.barTot;
		var ekwkkw = lineXolny - xxxx ;
		if (this.lineXPosition <= ekwkkw) 
		{
			this.canvasClear();
			console.log('x축 원래 ', lineXolny);
			console.log('x축 바뀐거', this.lineXPosition);
			this.lineXPosition = lineXolny;
			return;
		}
		else
		{
			theApp.Icandlearc.canvasClear();
			theApp.Icandlepos.canvasClear();
			this.canvasClear();
		}
	}
	else
	{
		theApp.Icandlearc.canvasClear();
		theApp.Icandlepos.canvasClear();
		this.canvasClear();
		this.lineXPosition = this.startLineX - this.mstartminu;
	}*/
	var lineX = 0;
	if(this.m_scrollYN) lineX = this.startLineX - this.mstartminu;
	else lineX = this.startLineX - 15;
	
    var firstY = 0;
    var lineY = 0;
	var lineYN = 0;
	var lineYSIG = 0;
	var lineYJONG = 0;
    var lineYGOGJEOG = 0;
	var lineYGOGA = 0;
	var lineYPREJONG = 0;
	var color_d = '';

	var i = null;
    var preUpArr = [];
    var preDwArr = [];
	
	// 오브젝트 중요
	var priceObj = {};
	var candleObj = {};
	
	let callputkey = null;
    
	for ( i = 0; i < this.maKeyLen; i++) {
		preUpArr.push({
			x : null,
			y : null
		});
		preDwArr.push({
			x : null,
			y : null
		});
	}
	
	for ( i = theApp.g_startIdx; i < theApp.g_endIdx; i++) 
	{
		priceObj = {};
		dataOne = data[i];
		lineX += this.pos.barTot;
		lineY = this.pos.upGrpSY + (theApp.upGrpMaxAm - dataOne.price) * theApp.upRateH;
		lineYN = this.pos.upGrpSY + Math.abs((theApp.upGrpMaxAm - dataOne.gogaprice)) * theApp.upRateH;
		lineYSIG = this.pos.upGrpSY + (theApp.upGrpMaxAm - dataOne.sigprice) * theApp.upRateH; // 시가를 뺴야함
		lineYJONG = this.pos.upGrpSY + (theApp.upGrpMaxAm - dataOne.price) * theApp.upRateH; // 종가를 뺴야함
		lineYGOGJEOG = lineYN + Math.abs(dataOne.gogaprice - dataOne.jongprice) * theApp.upRateH;  // 고가 에서 저가를 빼야함
		lineYGOGA =  this.pos.upGrpSY + Math.abs((theApp.upGrpMaxAm - dataOne.gogaprice)) * theApp.upRateH; // 고가 를 빼야함
		lineYPREJONG = this.pos.upGrpSY + (theApp.upGrpMaxAm - theApp.g_pricepre) * theApp.upRateH; // 이전 종가를 뺴야함

		if(this.m_chartdrowType == 0)
		{
			if(i != theApp.baseData.length -1)
			{
				this.drawAvgLine(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
			}
			else
			{
				if(theApp.m_lineMovecheck) this.drawAvgLineAnimation(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
				else this.drawAvgLine(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
			}
		}
		else if(this.m_chartdrowType == 1)
		{
			if(i != theApp.baseData.length -1)
			{
				this.drawAvgLinedressing(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
			}
			else
			{
				if(theApp.m_lineMovecheck) this.drawAvgLineAnimation(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
				else this.drawAvgLinedressing(this.colorObj.LINESUNTE, preUpArr[0], lineX, lineY, i);
			}
		}
		else if(this.m_chartdrowType == 2)
		{
			color_d = UtilityF.getcompareNumbersfun(dataOne.price, dataOne.sigprice);
			if(i != theApp.baseData.length -1)
			{
				this.drawAvgCandles(color_d, lineX, lineYSIG, lineYJONG, lineYN, lineYGOGJEOG, lineYGOGA);
			}
			else
			{
				if(theApp.m_lineMovecheck)
				{
					candleObj = {};
					candleObj.color_d = color_d;
					candleObj.lineX = lineX;
					candleObj.lineYSIG = lineYSIG;
					candleObj.lineYJONG = lineYJONG;
					candleObj.lineYN = lineYN;
					candleObj.lineYGOGJEOG = lineYGOGJEOG;
					candleObj.lineYGOGA = lineYGOGA;
					candleObj.lineYPREV = lineYPREJONG;
					
					this.drawAvgLineAnimation(null, null, null, null, null, candleObj);
				}
				else this.drawAvgCandles(color_d, lineX, lineYSIG, lineYJONG, lineYN, lineYGOGJEOG, lineYGOGA);
			}
		}
		else if(this.m_chartdrowType == 3)
		{
			color_d = UtilityF.getcompareNumberstwofun(dataOne.price, dataOne.sigprice);
			if(i != theApp.baseData.length -1)
			{
				this.drawAvgBars(color_d, lineX, lineYSIG, lineYJONG, lineYN, lineYGOGJEOG, lineYGOGA);
			}
			else
			{
				if(theApp.m_lineMovecheck)
				{
					candleObj = {};
					candleObj.color_d = color_d;
					candleObj.lineX = lineX;
					candleObj.lineYSIG = lineYSIG;
					candleObj.lineYJONG = lineYJONG;
					candleObj.lineYN = lineYN;
					candleObj.lineYGOGJEOG = lineYGOGJEOG;
					candleObj.lineYGOGA = lineYGOGA;
					candleObj.lineYPREV = lineYPREJONG;
					
					this.drawAvgLineAnimation(null, null, null, null, null, candleObj);
				}
				else this.drawAvgBars(color_d, lineX, lineYSIG, lineYJONG, lineYN, lineYGOGJEOG, lineYGOGA);
			}
		}

		priceObj.v = dataOne.price;
		priceObj.y = this.pos.upGrpSY + (theApp.upGrpMaxAm - dataOne.price) * theApp.upRateH;
		theApp.m_priceY.push(priceObj);
		
		dataOne.x = lineX;
		dataOne.y = lineY;
		
		// 여기에서 텍스트 박스 그리기 (현재 가격에 따라)
		if (i == theApp.baseData.length - 1) {
			const boxWidth = 70;
			const boxHeight = 25;
			const radius = 10;
			
			const boxX = this.canvas.width - boxWidth - 5; // 캔버스 끝에서 5픽셀 떨어지도록
			const boxY = priceObj.y - boxHeight / 2; // Y축 위치는 현재 가격에 맞추어 설정

			this.ctx.beginPath();
			this.ctx.moveTo(boxX + radius, boxY);
			this.ctx.lineTo(boxX + boxWidth - radius, boxY);
			this.ctx.quadraticCurveTo(boxX + boxWidth, boxY, boxX + boxWidth, boxY + radius);
			this.ctx.lineTo(boxX + boxWidth, boxY + boxHeight - radius);
			this.ctx.quadraticCurveTo(boxX + boxWidth, boxY + boxHeight, boxX + boxWidth - radius, boxY + boxHeight);
			this.ctx.lineTo(boxX + radius, boxY + boxHeight);
			this.ctx.quadraticCurveTo(boxX, boxY + boxHeight, boxX, boxY + boxHeight - radius);
			this.ctx.lineTo(boxX, boxY + radius);
			this.ctx.quadraticCurveTo(boxX, boxY, boxX + radius, boxY);
			this.ctx.closePath();

			// 텍스트 박스 색상 채우기
			this.ctx.fillStyle = '#587cbb';
			this.ctx.fill();

			// 텍스트 출력
			this.ctx.fillStyle = '#000000';  // 텍스트 색상
			this.ctx.font = '10px SpoqaHanSansNeo-Regular';
			this.ctx.textAlign = 'center';
			this.ctx.textBaseline = 'middle';
			this.ctx.fillText(priceObj.v, boxX + boxWidth / 2, boxY + boxHeight / 2);
		}
		
		
		if(this.m_bongcharttype == 'sec')
		{
			callputkey = `${dataOne.secDate}-${dataOne.secTime}`;
			theApp.m_balncejongo[callputkey] = dataOne;
		}
		else
		{
			callputkey = `${dataOne.tickDate}-${dataOne.tickTime}`;
			theApp.m_balncejongo[callputkey] = dataOne;
		}
	}
	
	theApp.Icandlepos.setposdrawhashtable();
	
    firstY = this.pos.upGrpSY + (theApp.upGrpMaxAm - data[theApp.baseData.length -1].price) * theApp.upRateH;
	this.drawTextlineonly(null, firstY, null, data[theApp.baseData.length -1].price, null);
	
	//this.animationRequestId = requestAnimationFrame(this.dynamicdrawGraph.bind(this));
};

//막대사탕 텍스트 그리기
Icandlechart.prototype.drawTextlineonly = function(ycolor, xcolor, y, x, texty, textx) 
{
	if(!this.m_scrollYN) theApp.Icandlearc.drawPriceMovetwo(y);
	this.ctx.strokeStyle = '#00FF0000';
	this.ctx.beginPath();
	this.ctx.lineWidth = this.pos.upGrpSY;
	this.ctx.moveTo(this.pos.grpEX + 1, y);
	this.ctx.lineTo(this.pos.cavasW, y);
	
	/*// 화살표 그리기
		var headlen = 5; // 화살표 머리의 길이
		var angle = Math.atan2(0, this.pos.cavasW - (this.pos.grpEX + 1)); // 현재 라인 방향에 따른 각도 계산
		//var angle = Math.atan2(0, (this.pos.grpEX + 1) - this.pos.cavasW); // 화살표의 방향에 따른 각도 계산

		// 화살표 머리를 그립니다:  오른쪽 라인의 끝에서 시작해서 두 개의 선을 그려서 화살표 모양을 만듭니다.
		this.ctx.lineTo(this.pos.cavasW - headlen * Math.cos(angle - Math.PI / 6), y - headlen * Math.sin(angle - Math.PI / 6));
		this.ctx.moveTo(this.pos.cavasW, y);
		this.ctx.lineTo(this.pos.cavasW - headlen * Math.cos(angle + Math.PI / 6), y - headlen * Math.sin(angle + Math.PI / 6));

		// 왼쪽을 가리키는 화살표 머리를 그립니다.
		this.ctx.moveTo(this.pos.grpEX+1, y); // 선의 시작점으로 돌아갑니다.
		// 왼쪽 방향으로 화살표 머리 그리기
		this.ctx.lineTo(this.pos.grpEX + 1 + headlen * Math.cos(angle + Math.PI / 6), y + headlen * Math.sin(angle + Math.PI / 6));
		this.ctx.moveTo(this.pos.grpEX + 1, y);
		this.ctx.lineTo(this.pos.grpEX + 1 + headlen * Math.cos(angle - Math.PI / 6), y + headlen * Math.sin(angle - Math.PI / 6));*/

	this.ctx.stroke();
	this.ctx.closePath();

	this.ctx.textAlign = 'right';
	this.ctx.fillStyle = ycolor;
	this.ctx.fillText(this._getDecimalValue(texty), this.pos.amPad, y);
};

//이동평균선 라인 그리기
Icandlechart.prototype.drawAvgLine = function(color, preLine, x, y, pos) 
{
	// 라인 그리기
    this.ctx.beginPath();
    this.ctx.strokeStyle = color;
	this.ctx.lineJoin = 'round'; // 선의 연결 부분을 둥글게 처리
	this.ctx.lineCap = 'butt';
	this.ctx.lineWidth = 2;
    if (preLine.x == null) {
        preLine.x = x;
        preLine.y = y;
    }
	if(pos === theApp.baseData.length - 1) 
	{
		//this.ctx.setLineDash([3, 3]);  // 임시
		this.ctx.setLineDash([]);
	}
	else
	{
		this.ctx.setLineDash([]);  // 실선 스타일로 설정 (점선 없음)
	}
    this.ctx.moveTo(preLine.x + 0.5, preLine.y + 0.5);
    this.ctx.lineTo(x + 0.5, y + 0.5);
    preLine.x = x;
    preLine.y = y;
	this.ctx.stroke();
	this.ctx.closePath();
	
	if(pos === theApp.baseData.length-1)
	{
		theApp.Icandlearc.drawFirstPoint(x, y, 1);
	}
};

//이동평균선 라인 그리기 밑에 채우는거
Icandlechart.prototype.drawAvgLinedressing = function(color, preLine, x, y, pos) 
{	
	// 선 그리기 시작
    this.ctx.beginPath();
    this.ctx.strokeStyle = color;
    this.ctx.lineJoin = 'round'; // 선의 연결 부분을 둥글게 처리
	this.ctx.lineCap = 'butt';
	this.ctx.lineWidth = 2;
    if (preLine.x == null) {
        preLine.x = x;
        preLine.y = y;
    }
    
    // 이전 위치에서 현재 위치로 선 그리기
	if(pos === theApp.baseData.length - 1) 
	{
		//this.ctx.setLineDash([5, 5]);  // 임시
		this.ctx.setLineDash([]);
	}
	else
	{
		this.ctx.setLineDash([]);  // 실선 스타일로 설정 (점선 없음)
	}
    this.ctx.moveTo(preLine.x, preLine.y);
    this.ctx.lineTo(x, y);
    this.ctx.stroke();
    
    // 아래 영역 채우기 시작
    this.ctx.beginPath();
    this.ctx.moveTo(preLine.x, preLine.y); // 이전 끝점에서 시작
    this.ctx.lineTo(x, y); // 현재 끝점까지 선 그리기
    this.ctx.lineTo(x, this.pos.cavasH); // 현재 끝점에서 캔버스 하단까지 선 그리기
    this.ctx.lineTo(preLine.x, this.pos.cavasH); // 캔버스 하단을 따라 이전 끝점까지 선 그리기
    this.ctx.closePath(); // 경로 닫기
    
    // 채우기 색상 설정 및 영역 채우기
    this.ctx.fillStyle = 'rgba(100, 150, 235, 0.3)';
    this.ctx.fill();
    
    // 현재 점을 이전 점으로 설정
    preLine.x = x;
    preLine.y = y;
	
	if(pos === theApp.baseData.length-1)
	{
		theApp.Icandlearc.drawFirstPoint(x, y, 1);
	}
};

//캔들 차트 그리기
Icandlechart.prototype.drawAvgCandles = function(color, x, sy, jy, y, gjy) 
{	//  gy : 고가 sy : 시가 jy : 종가 gjy : 고가 저가  값을 뜻함
	// 초기 설정
	this.ctx.lineJoin = 'round';
	this.ctx.lineCap = 'round';
	
	// 그림자 설정 (선택 사항)
	this.ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
	this.ctx.shadowBlur = 4;
	
	// 캔들 바디 그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = this.pos.barW;
	//상승과 하락을 결정하여 색상을 셋팅
	this.ctx.strokeStyle = color;
	// 시작 인덱스 y 값
	this.ctx.moveTo(x, sy);
	// 종가 인덱스 y 값
	this.ctx.lineTo(x, jy);
	this.ctx.stroke();
	this.ctx.closePath();
	
	//고가 저가 선 그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = "1.5";
	this.ctx.moveTo(x, y);
	this.ctx.lineTo(x, gjy);
	this.ctx.stroke();
	this.ctx.closePath();
};

//캔들2 차트 그리기
Icandlechart.prototype.drawAvgBars = function(color, x, sy, jy, y, gjy) 
{
	const isRising = jy > sy; // 예시: 종가가 시작가보다 높으면 상승
	
	// 초기 설정
	this.ctx.lineJoin = 'round';
	this.ctx.lineCap = 'round';
	
	// 그림자 설정 (선택 사항)
	this.ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
	this.ctx.shadowBlur = 4;
	
	// 캔들 바디 그리기
	if (isRising) {
		this.ctx.beginPath();
		this.ctx.lineWidth = this.pos.barW;
		this.ctx.strokeStyle = color;
		// 시작 인덱스 y 값
		this.ctx.moveTo(x, sy);
		// 종가 인덱스 y 값
		this.ctx.lineTo(x, jy);
		this.ctx.stroke();
		this.ctx.closePath();
	} else {
		this.ctx.beginPath();
		this.ctx.lineWidth = this.pos.barW;
		this.ctx.strokeStyle = color;
		// 시작 인덱스 y 값
		this.ctx.moveTo(x, sy);
		// 종가 인덱스 y 값
		this.ctx.lineTo(x, jy);
		this.ctx.stroke();
		this.ctx.closePath();
		
		/*this.ctx.lineWidth = 1; // 경계선 너비
		this.ctx.strokeStyle = color;
		this.ctx.fillStyle = 'transparent';
		// 둥근 캔들 바디 그리기
		const rectX = x - this.pos.barW / 2;
		const rectY = sy;
		const rectWidth = this.pos.barW;
		const rectHeight = jy - sy;
		const cornerRadius = 5; // 원하는 반지름 설정
		UtilityF.setdrawRoundedRectfun(this.ctx, rectX, rectY, rectWidth, rectHeight, cornerRadius);
		this.ctx.stroke();*/
	}

	//고가 저가 선 그리기
	this.ctx.beginPath();
	this.ctx.lineWidth = "1.5";
	this.ctx.moveTo(x, y);
	this.ctx.lineTo(x, gjy);
	this.ctx.stroke();
	this.ctx.closePath();
};


/*******************************************************
========================================================
	차트 애니메이션 함수
========================================================
*******************************************************/

// 보간 함수
function lerp(start, end, t) {
    return start * (1 - t) + end * t;
}

// 캔들차트 보간 함수
function lerpcandle(start, end, amt) {
    return (1 - amt) * start + amt * end;
}

/*function lerp(start, end, t) {
    return start + (end - start) * t;
}
*/
Icandlechart.prototype.startAnimation = function(ctx, color, preLine, targetX, targetY, animationState) {
    if (animationState.active) return; // 이미 애니메이션이 진행 중인 경우 중복 방지
	
	let thisObjan = this;
    animationState.active = true;
    let currentX = preLine.x;
    let currentY = preLine.y;
	let shadowIntensity = 0; // Start with no shadow
    let increasingShadow = true; // Controls whether the shadow is increasing or decreasing
	let count = 0;
	
    function animate() {
		
        // 선형 보간
        currentX = lerp(currentX, targetX, 0.1);
        currentY = lerp(currentY, targetY, 0.1);
		
        // 라인 업데이트
       	ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.lineJoin = 'round';
        ctx.moveTo(preLine.x, preLine.y);
        ctx.lineTo(currentX, currentY);
        ctx.stroke();
        ctx.closePath();
		
        // 현재 위치 업데이트
        preLine.x = currentX;
        preLine.y = currentY;
		
		count += 1;
		theApp.Icandlearc.drawFirstPoint(currentX, currentY, count);
		
        // 애니메이션 종료 조건 확인
        if (Math.abs(currentX - targetX) > 1 || Math.abs(currentY - targetY) > 1) {
             thisObjan.animationId = requestAnimationFrame(animate);
        } else {
			theApp.Icandlearc.drawFirstPoint(targetX, targetY, count);
            animationState.active = false; // 애니메이션 종료
        }
    }
	
    animate();
};

Icandlechart.prototype.startresAnimation = function(ctx, color, preLine, targetX, targetY, animationState) {
    if (animationState.active) return; // 이미 애니메이션이 진행 중인 경우 중복 방지
	
	let thisObjan = this;
    animationState.active = true;
    let currentX = preLine.x;
    let currentY = preLine.y;
	let shadowIntensity = 0; // Start with no shadow
    let increasingShadow = true; // Controls whether the shadow is increasing or decreasing
	let count = 0;

    function animate() {
		
        // 선형 보간
        currentX = lerp(currentX, targetX, 0.1);
        currentY = lerp(currentY, targetY, 0.1);
		
        // 라인 업데이트
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.lineJoin = 'round';
        ctx.moveTo(preLine.x, preLine.y);
        ctx.lineTo(currentX, currentY);
        ctx.stroke();
		
		// 아래 영역 채우기 시작 (새 경로)
		ctx.beginPath(); // 새 경로 시작
		ctx.moveTo(preLine.x, preLine.y);
		ctx.lineTo(currentX, currentY);
		ctx.lineTo(currentX, thisObjan.pos.cavasH);
		ctx.lineTo(preLine.x, thisObjan.pos.cavasH);
		ctx.closePath(); // 경로 닫기

		// 채우기 색상 설정 및 영역 채우기
		ctx.fillStyle = 'rgba(100, 150, 235, 0.3)';
		ctx.fill();

        // 현재 위치 업데이트
        preLine.x = currentX;
        preLine.y = currentY;
		
		count += 1;
		theApp.Icandlearc.drawFirstPoint(currentX, currentY, count);
		
        // 애니메이션 종료 조건 확인
        if (Math.abs(currentX - targetX) > 1 || Math.abs(currentY - targetY) > 1) {
             thisObjan.animationId = requestAnimationFrame(animate);
        } else {
			theApp.Icandlearc.drawFirstPoint(targetX, targetY, count);
            animationState.active = false; // 애니메이션 종료
        }
    }

    animate();
};
// 캔들차트
Icandlechart.prototype.drawCandleAnimation = function(ctx, color, x, sy, jy, y, gjy, prevJy, animationState) {
	if (animationState.active) return; // 이미 애니메이션이 진행 중인 경우 중복 방지

	let thisObcan = this;
	// 애니메이션 상태 활성화
	animationState.active = true;
	
	let count = 0;
	let step = 0;
	const steps = 30; // Number of animation steps
	const increment = (jy - prevJy) / steps;

	const drawStep = () => {
		if (step <= steps) {
			let currentJy = prevJy + increment * step;
			theApp.Icandlebong.drawAvgCandles(color, x, sy, currentJy, y, gjy);
			count += 1;
			// Assuming theApp.Icandlearc.drawFirstPoint is a valid function
			if (theApp && theApp.Icandlearc && typeof theApp.Icandlearc.drawFirstPoint === 'function') {
				theApp.Icandlearc.drawFirstPoint(x, currentJy, count);
			}

			step++;
			thisObcan.animationId = requestAnimationFrame(drawStep);
		} else {
			animationState.active = false; // 애니메이션 종료
			theApp.Icandlebong.drawAvgCandles(color, x, sy, jy, y, gjy);
		}
	};

	requestAnimationFrame(drawStep);
};

// 캔들차트02
Icandlechart.prototype.drawCandle02Animation = function(ctx, color, x, sy, jy, y, gjy, prevJy, animationState) {
	if (animationState.active) return; // 이미 애니메이션이 진행 중인 경우 중복 방지

	let thisObcan = this;
	// 애니메이션 상태 활성화
	animationState.active = true;
	
	let count = 0;
	let step = 0;
	const steps = 30; // Number of animation steps
	const increment = (jy - prevJy) / steps;

	const drawStep = () => {
		if (step <= steps) {
			let currentJy = prevJy + increment * step;
			theApp.Icandlebong.drawAvgBars(color, x, sy, currentJy, y, gjy);
			count += 1;
			// Assuming theApp.Icandlearc.drawFirstPoint is a valid function
			if (theApp && theApp.Icandlearc && typeof theApp.Icandlearc.drawFirstPoint === 'function') {
				theApp.Icandlearc.drawFirstPoint(x, currentJy, count);
			}

			step++;
			thisObcan.animationId = requestAnimationFrame(drawStep);
		} else {
			animationState.active = false; // 애니메이션 종료
			theApp.Icandlebong.drawAvgBars(color, x, sy, jy, y, gjy);
		}
	};

	requestAnimationFrame(drawStep);
};

//이동평균선 라인 그리기 애니메이션
Icandlechart.prototype.drawAvgLineAnimation = function(color, preLine, x, y, pos, Obj) 
{
    // 애니메이션을 위한 상태 초기화
    if (!this.animationState) {
        this.animationState = { active: false };
    }
	
	if (this.animationId) {
		cancelAnimationFrame(this.animationId);
		this.animationId = null;
	}
	
    // 애니메이션 시작
    if(this.m_chartdrowType == 0) this.startAnimation(this.ctx, color, preLine, x, y, this.animationState);
	else if(this.m_chartdrowType == 1) this.startresAnimation(this.ctx, color, preLine, x, y, this.animationState);
	else if(this.m_chartdrowType == 2) this.drawCandleAnimation(this.ctx, Obj.color_d, Obj.lineX, Obj.lineYSIG, Obj.lineYJONG,  Obj.lineYN,  Obj.lineYGOGJEOG, Obj.lineYPREV, this.animationState);
	else if(this.m_chartdrowType == 3) this.drawCandle02Animation(this.ctx, Obj.color_d, Obj.lineX, Obj.lineYSIG, Obj.lineYJONG,  Obj.lineYN,  Obj.lineYGOGJEOG, Obj.lineYPREV, this.animationState);
	
};


/*******************************************************
========================================================
	차트 이벤트 
========================================================
*******************************************************/

//데이터가 더 필요한지를 체크
Icandlechart.prototype.isExistNextData = function() 
{
    if ((theApp.g_startIdx + this.BAR_CNT) > theApp.baseData.length)
        return false;
    else
        return true;
};

//캔들의 너비를 바꿈
Icandlechart.prototype.barWidthChange = function() 
{
    this.pos.barTot = this.pos.barW + this.BAR_TERM;
    this.BAR_CNT = parseInt(this.pos.grpW / this.pos.barTot, 10);
    this.startLineX = this.pos.grpEX + this.pos.barW / 2;
};

//왼쪽에서 오른쪽으로 스크롤 시킴
Icandlechart.prototype.scrollLToR = function(add) 
{
    if (!this.isExistNextData()) {
        this.getOffset();
        return;
    }
	this.m_scrollYN = false;
    theApp.g_startIdx -= add;
	theApp.g_endIdx -= add;
	
	if (theApp.g_startIdx < 0)
	{
		theApp.g_startIdx = 0;
		theApp.g_endIdx  =  this.BAR_CNT;
	}
	
	theApp.m_lineMovecheck = false;
    this.updateGraph();
};

//오른쪽에서 왼쪽으로 스크롤 시킴
Icandlechart.prototype.scrollRToL = function(add) 
{
	theApp.g_startIdx += add;
	theApp.g_endIdx += add;
	
	if(theApp.g_endIdx > theApp.baseData.length)
	{
		this.m_scrollYN = true;
		this.getOffset();
	}
	
	theApp.m_lineMovecheck = false;
    this.updateGraph();
};

//자동스크를
Icandlechart.prototype.autoScroll = function(speed) 
{
    var thisObj = this;

    if (speed > 150 || !this.isExistNextData())
        return;

    this.timer = setTimeout(function() {
        thisObj.timer = null;

        if (thisObj.mScrollLR)
            thisObj.scrollLToR(1);
        else
            thisObj.scrollRToL(1);
        thisObj.autoScroll(speed + speed / 4);
    }, speed);
};


function getDistance(p1, p2) {
	return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
}

// down event
Icandlechart.prototype.setdownTouchEvent = function(e)
{
	var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
        pageX2,
        pageY2;
	
	//console.log('터치 다운이벤트 본섭');
	theApp.isDown = true;
	if (!theApp.baseData || theApp.baseData.length == 0)
		return;

	//e.preventDefault();
	e.stopPropagation();

	touch1 = e.targetTouches[0];
	touch2 = e.targetTouches[1];

	pageX1 = touch1.pageX;
	pageY1 = touch1.pageY;

	//console.log('터치 무빙 이벤트 터치', touch1);

	if (thisObj.timer) {
		clearTimeout(thisObj.timer);
		thisObj.timer = null;
	}

	thisObj.scollSX = pageX1;

	//------------------------
	thisObj.mStartTime = new Date().getTime();
	thisObj.mOldTime = thisObj.mStartTime;
	thisObj.mStartX = pageX1;
	thisObj.mEndX = thisObj.mStartX;

	//-------------------------------------
	//롱탭을 눌렀을시
	//-------------------------------------

	this.longTime = setTimeout(function() {
		if (touch2)
			return;

		thisObj.mode = 1;

		//thisObj.infoDiv.style.display = '';
		//thisObj.longXdiv.style.display = '';
		//thisObj.longYdiv.style.display = '';

		//thisObj.moveX = pageX1;
		//thisObj.drawLongTabLines();

	}, 500);
};

// move event
Icandlechart.prototype.setmoveTouchEvent = function(e)
{
	var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
        pageX2,
        pageY2;
	
	//console.log('터치 무빙 이벤트 본섭');
	clearTimeout(this.longTime);

	if (!theApp.baseData || theApp.baseData.length == 0)
		return;
		
	//e.preventDefault();
	e.stopPropagation();

	touch1 = e.targetTouches[0];
	touch2 = e.targetTouches[1];

	pageX1 = touch1.pageX;
	pageY1 = touch1.pageY;
	
	if (!theApp.isDown)
		return;
	
	//멀티터치
	if (touch2) {
		//console.log('터치 무빙 이벤트2');
		pageX2 = touch2.pageX;
		pageY2 = touch2.pageY;

		if (touch1 && touch2) {

			var dist = getDistance({
				x : pageX1,
				y : pageY1
			}, {
				x : pageX2,
				y : pageY2
			});
			if (!thisObj.lastDist) {
				thisObj.lastDist = dist;
			}
			thisObj.rateVal = (dist / thisObj.lastDist).toFixed(2);
			thisObj.zoomState = 0;
			thisObj.zoomInOut();
			thisObj.lastDist = dist;
		}
	}

	//일반 스크롤
	else {
		//console.log('터치 무빙 이벤트3');
		//--------------------------------------
		//롱탭 후 드래그 했을시
		if (thisObj.mode == 1) {
			//thisObj.moveX = pageX1;
			//thisObj.drawLongTabLines();
		}
		//일반 스크롤시
		else {
			//--------------------------------------
			var newTime = new Date().getTime();
			//멈춰있는 시간이 일정시간 이상이면 초기화
			if ((newTime - thisObj.mOldTime) > 100) {
				thisObj.mStartTime = newTime;
				thisObj.mOldTime = newTime;
				thisObj.mStartX = pageX1;
				thisObj.mEndX = thisObj.mStartX;
			} else {
				thisObj.mOldTime = newTime;
				thisObj.mEndX = pageX1;
			}

			//--------------------------------------
			var chkW = Math.abs(thisObj.scollSX - pageX1);
			if (chkW > thisObj.pos.barW)//+graph.distance
			{
				if (thisObj.scollSX > pageX1) {
					thisObj.mScrollLR = false;
					var count = parseInt((chkW / thisObj.pos.barW), 10);
					thisObj.scrollRToL(count);
				} else {
					thisObj.mScrollLR = true;
					var count = parseInt((chkW / thisObj.pos.barW), 10);
					thisObj.scrollLToR(count);
				}
				thisObj.scollSX = pageX1;
			}
		}
	}
};

// up event
Icandlechart.prototype.setupTouchEvent = function(e)
{
	var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
        pageX2,
        pageY2;
	
	//console.log('터치 업 이벤트 본섭');
	theApp.isDown = false;
	if (!theApp.baseData || theApp.baseData.length == 0)
		return;

	clearTimeout(this.longTime);

	thisObj.mode = 0;
	/*if (thisObj.infoDiv) {
		thisObj.infoDiv.style.display = 'none';
		thisObj.longXdiv.style.display = 'none';
		thisObj.longYdiv.style.display = 'none';
	}*/

	//e.preventDefault();
	e.stopPropagation();

	//------------------
	var interval = new Date().getTime() - thisObj.mStartTime;
	thisObj.speed = Math.abs(thisObj.mEndX - thisObj.mStartX) / interval;
	//속도값이 아주 작은 것은 무시한다.
	if (thisObj.speed > 0.5) {
		thisObj.autoScroll((4 - thisObj.speed) / 2);
	}
	//----------------------------------

	thisObj.lastDist = null;
};


/*******************************************************
========================================================
	기본 함수 모음
========================================================
*******************************************************/

// 기존 시간 추가
Icandlechart.prototype.getKoreanDateTime = function(secondtime)
{
	let now = new Date(); // 현재 UTC 날짜 및 시간
	now.setSeconds(now.getSeconds() + secondtime);

	// 한국 시간으로 조정
	let koreanTime = new Date(now.getTime() + (9*60*60*1000));

	// 날짜 YYYYMMDD 형식으로 포맷
	let date = koreanTime.getFullYear().toString() + 
		(koreanTime.getMonth() + 1).toString().padStart(2, '0') + 
		koreanTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let time = koreanTime.getHours().toString().padStart(2, '0') + 
		koreanTime.getMinutes().toString().padStart(2, '0') + 
		koreanTime.getSeconds().toString().padStart(2, '0');

	return { date, time };
};

// 소수점 함수
Icandlechart.prototype._getDecimalValue = function(value)
{
	if(this.m_decimalga != undefined)
	{
		value = ADataMask.Number.decimalAdjust.func(value, ['floor', this.m_decimalga*-1]).toFixed(this.m_decimalga);
	}
	return ADataMask.Number.money.func(value);
};

//서브타입을 기준으로 서브 차트를 그리기위한 함수 셋팅
Icandlechart.prototype.settingDrawSubGrp = function() 
{
    var subFunc = this.drawSubGrpFuncs[this.subType];
    this.drawBackType = subFunc[0];
    this.drawTextType = subFunc[1];
    this.drawMaxMinType = subFunc[2];
    this.drawChartType = subFunc[3];
    this.calcMaxMinChartType = subFunc[4];
};

Icandlechart.prototype.calculateIndexDifference = function(startIndex, endIndex) 
{
  // 인덱스가 유효한 숫자인지 확인
  if (typeof startIndex !== 'number' || typeof endIndex !== 'number') {
    throw new Error("인덱스는 숫자여야 합니다.");
  }
  
  // 차이 계산
  const difference = endIndex - startIndex;
  
  return difference;
};

