function CanVasWidth()
{
}

// 차트 초기화
CanVasWidth.setCanVasinitfun = function(thisObj)
{
	// 백그라운 차트
	theApp.Icandleback.setCTX(thisObj.cxsback.ctx, thisObj.cxsback.element);
	theApp.Icandleback.calcPosition(thisObj.cxsback.element.clientWidth, thisObj.cxsback.element.clientHeight);
	
	// 차트 소스
	theApp.Icandlechart.setCTX(thisObj.cxs.ctx, thisObj.cxs.element);
	theApp.Icandlechart.calcPosition(thisObj.cxs.element.clientWidth, thisObj.cxs.element.clientHeight);
	
	// 캔들 차트 소스
	theApp.Icandlebong.setCTX(thisObj.cxscandle.ctx, thisObj.cxscandle.element);
	theApp.Icandlebong.calcPosition(thisObj.cxscandle.element.clientWidth, thisObj.cxscandle.element.clientHeight);
	
	// 잔고표시 차트
	theApp.Icandlepos.setCTX(thisObj.cxspos.ctx, thisObj.cxspos.element);
	theApp.Icandlepos.calcPosition(thisObj.cxspos.element.clientWidth, thisObj.cxspos.element.clientHeight);
	
	// 원 그리기 위한 차트
	theApp.Icandlearc.setCTX(thisObj.cxsarc.ctx, thisObj.cxsarc.element);
	theApp.Icandlearc.calcPosition(thisObj.cxsarc.element.clientWidth, thisObj.cxsarc.element.clientHeight);
	
	// 마우스 그리기 위한 차트 
	theApp.Icandlemouse.setCTX(thisObj.cxsmouse.ctx, thisObj.cxsmouse.element);
	theApp.Icandlemouse.calcPosition(thisObj.cxsmouse.element.clientWidth, thisObj.cxsmouse.element.clientHeight);
};

// 차트 화면 초기화
CanVasWidth.onChartClearof = function()
{
	theApp.Icandleback.canvasClear();
	theApp.Icandlechart.canvasClear();
	theApp.Icandlebong.canvasClear();
	theApp.Icandlepos.canvasClear();
	theApp.Icandlearc.canvasClear();
	theApp.Icandlemouse.canvasClear();
};

// 차트 너비 초기화
CanVasWidth.onChartWidthChange = function(thisObj)
{
	theApp.Icandleback.updatePosition(thisObj.cxsback.element.clientWidth, thisObj.cxsback.element.clientHeight);
	theApp.Icandlechart.updatePosition(thisObj.cxs.element.clientWidth, thisObj.cxs.element.clientHeight);
	theApp.Icandlebong.updatePosition(thisObj.cxscandle.element.clientWidth, thisObj.cxscandle.element.clientHeight);
	theApp.Icandlepos.updatePosition(thisObj.cxspos.element.clientWidth, thisObj.cxspos.element.clientHeight);
	theApp.Icandlearc.updatePosition(thisObj.cxsarc.element.clientWidth, thisObj.cxsarc.element.clientHeight);
	theApp.Icandlemouse.updatePosition(thisObj.cxsmouse.element.clientWidth, thisObj.cxsmouse.element.clientHeight);
};

// 가로 세로 일때 보이는 갯수 설정
CanVasWidth.setCanVasValuefun = function(Obj)
{
	theApp.Icandleback.setChangewidhtvalue(Obj);
	theApp.Icandlechart.setChangewidhtvalue(Obj);
	theApp.Icandlebong.setChangewidhtvalue(Obj);
	theApp.Icandlepos.setChangewidhtvalue(Obj);
	theApp.Icandlearc.setChangewidhtvalue(Obj);
	theApp.Icandlemouse.setChangewidhtvalue(Obj);
};

// 백그라운드 그릴때 초인지 분인지
CanVasWidth.setBacklinesecmintype = function(type)
{
	theApp.Icandleback.setTimeTypeback(type);
	theApp.Icandlechart.setTimeTypeback(type);
	theApp.Icandlepos.setTimeTypeback(type);
};

// 가로 세로 리사이징 후 그리기
CanVasWidth.instartdraw = function()
{
	theApp.Icandlechart.updateGraph();
};

// 세로 가로랑 로직이같음 landscape
CanVasWidth.portraitCanWhCssfun = function(thisObj)
{
	let cxsbackio, cxsratio, cxscandle, cxsposio, arcratio, mouseratio, rectcxsback, rectcxs, rectcxscandle, rectcxspos, rectarc, rectmouse;
	
	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	cxsbackio = window.devicePixelRatio || 1;
	rectcxsback = thisObj.cxsback.element.getBoundingClientRect();
	//thisObj.cxsback.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxsback.element.style.height = thisObj.chartview.getHeight() + 'px';//window.innerHeight + 'px';
	thisObj.cxsback.element.width = rectcxsback.width * cxsbackio;//window.innerWidth * cxsratio;
	thisObj.cxsback.element.height = rectcxsback.height * cxsbackio;//window.innerHeight * cxsratio;
	thisObj.cxsback.ctx.scale(cxsbackio, cxsbackio);
	
	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	cxsratio = window.devicePixelRatio || 1;
	rectcxs = thisObj.cxs.element.getBoundingClientRect();
	//thisObj.cxs.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxs.element.style.height = thisObj.chartview.getHeight() + 'px';//window.innerHeight + 'px';
	thisObj.cxs.element.width = rectcxs.width * cxsratio;//window.innerWidth * cxsratio;
	thisObj.cxs.element.height = rectcxs.height * cxsratio;//window.innerHeight * cxsratio;
	thisObj.cxs.ctx.scale(cxsratio, cxsratio);
	
	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	cxscandle = window.devicePixelRatio || 1;
	rectcxscandle = thisObj.cxscandle.element.getBoundingClientRect();
	//thisObj.cxscandle.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxscandle.element.style.height = thisObj.chartview.getHeight() + 'px';//window.innerHeight + 'px';
	thisObj.cxscandle.element.width = rectcxscandle.width * cxscandle;//window.innerWidth * cxsratio;
	thisObj.cxscandle.element.height = rectcxscandle.height * cxscandle;//window.innerHeight * cxsratio;
	thisObj.cxscandle.ctx.scale(cxscandle, cxscandle);
	
	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	cxsposio = window.devicePixelRatio || 1;
	rectcxspos = thisObj.cxs.element.getBoundingClientRect();
	//thisObj.cxspos.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxspos.element.style.height = thisObj.chartview.getHeight() + 'px';//window.innerHeight + 'px';
	thisObj.cxspos.element.width = rectcxspos.width * cxsposio;//window.innerWidth * cxsratio;
	thisObj.cxspos.element.height = rectcxspos.height * cxsposio;//window.innerHeight * cxsratio;
	thisObj.cxspos.ctx.scale(cxsposio, cxsposio);

	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	arcratio = window.devicePixelRatio || 1;
	rectarc = thisObj.cxs.element.getBoundingClientRect();
	//thisObj.cxsarc.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxsarc.element.style.height = thisObj.chartview.getHeight() + 'px'; //window.innerHeight + 'px';
	thisObj.cxsarc.element.width = rectarc.width * arcratio; //window.innerWidth * arcratio;
	thisObj.cxsarc.element.height = rectarc.height * arcratio; //window.innerHeight * arcratio;
	thisObj.cxsarc.ctx.scale(arcratio, arcratio);

	// 디바이스 픽셀 비율을 고려하여 화면 해상도에 맞게 조정
	mouseratio = window.devicePixelRatio || 1;
	rectmouse = thisObj.cxs.element.getBoundingClientRect();
	//thisObj.cxsmouse.element.style.width = thisObj.chartview.getWidth() + 'px'; //window.innerWidth + 'px';
	//thisObj.cxsmouse.element.style.height = thisObj.chartview.getHeight() + 'px'; //window.innerHeight + 'px';
	thisObj.cxsmouse.element.width = rectmouse.width * mouseratio; //window.innerWidth * mouseratio;
	thisObj.cxsmouse.element.height = rectmouse.height  * mouseratio; //window.innerHeight * mouseratio;
	thisObj.cxsmouse.ctx.scale(mouseratio, mouseratio);
};

// 가로
CanVasWidth.landscapeCanWhCssfun = function(thisObj)
{
};