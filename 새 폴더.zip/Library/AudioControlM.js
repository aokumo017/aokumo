function AudioControlM()
{
	// 오디오 컨텍스트 생성
	this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
	this.audioBuffer = null;
	this.sourceNode = null;
	this.startTime = 0; // 재생이 시작된 시간
	this.pauseTime = 0; // 재생이 멈춘 시간
}

// 오디오 파일 로드 및 재생 함수
AudioControlM.prototype.loadAndPlay = function(filePath) 
{
	var thisObj = this;
	
	// 새로운 파일을 로드하기 전에 기존의 오디오 버퍼를 초기화합니다.
	if (this.audioBuffer && this.audioBuffer !== filePath) {
		this.audioBuffer = null;
		this.pauseTime = 0; // 새 파일을 로드할 때는 중지 시간도 리셋합니다.
	}
	
	if (!this.audioBuffer) { // 파일이 아직 로드되지 않았다면 로드
		fetch(filePath)
			.then(response => response.arrayBuffer())
			.then(arrayBuffer => thisObj.audioContext.decodeAudioData(arrayBuffer))
			.then(decodedAudio => {
				thisObj.audioBuffer = decodedAudio;
				thisObj.playAudio();
			})
			.catch(e => console.error(e));
	} 
	else {
		thisObj.playAudio();
	}
};

// 오디오 재생 함수
AudioControlM.prototype.playAudio = function() 
{
	this.sourceNode = this.audioContext.createBufferSource(); // 소스 노드 생성
	this.sourceNode.buffer = this.audioBuffer;
	this.sourceNode.connect(this.audioContext.destination);
	this.startTime = this.audioContext.currentTime - this.pauseTime; // 현재 시간에서 중지 시간을 빼서 재생 시간 계산
	this.sourceNode.start(0, this.pauseTime);
};

// 오디오 중지 함수
AudioControlM.prototype.stopAudio = function() 
{
	if (this.sourceNode) {
		this.sourceNode.stop();
		this.pauseTime = this.audioContext.currentTime - this.startTime; // 재생을 멈춘 시간 계산
	}
};

// 오디오 이어서 재생 함수
AudioControlM.prototype.resumeAudio = function() 
{
	this.playAudio(); // 이전에 저장한 pauseTime에서 재생을 시작
};



