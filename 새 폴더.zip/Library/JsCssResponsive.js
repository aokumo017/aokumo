function JsCssResponsive()
{
}

// 세로
JsCssResponsive.JsWhCssfunportrait = function(thisObj)
{
	//배경색
	thisObj.mainview.getElement().style.background = null;
	//top
	thisObj.top.getElement().style.width = '100%';
	thisObj.top.getElement().style.height = '6.36%';
	thisObj.top.getElement().style.left = '0px';
	thisObj.top.getElement().style.top = '0px';
	thisObj.top.getElement().style.background = 'linear-gradient( to right, #111, #182d4e, #111)';
	thisObj.top.getElement().style.borderRadius = null;
	//center
	thisObj.chartview.getElement().style.width  = '100%';
	thisObj.chartview.getElement().style.height  = 'calc((100% - 6.36%) - 24.57%)';
	thisObj.chartview.getElement().style.left  = '0px';
	thisObj.chartview.getElement().style.top  = '6.36%';
	thisObj.chartview.getElement().style.backgroundImage = "url('Assets/img/bg03.png')";
	//bottom
	thisObj.bottom.getElement().style.top  = null;
	thisObj.bottom.getElement().style.right = null;
	thisObj.bottom.getElement().style.width  = '100%';
	thisObj.bottom.getElement().style.height  = '24.57%';  // '15.94%'
	thisObj.bottom.getElement().style.left  = '0px';
	thisObj.bottom.getElement().style.bottom  = '0px';
	thisObj.bottom.getElement().style.background = 'linear-gradient( to right, #111, #182d4e, #111)';
	thisObj.bottom.getElement().style.borderRadius = null;
	
	//차트 선택 분틱 시간 
	thisObj.CX_chartsel.getElement().style.left = '10px';
	thisObj.CX_mintick.getElement().style.left = '10px';
	thisObj.CX_timesel.getElement().style.left = '10px';
	
	//키보드
	thisObj.keybodview.getElement().style.background = 'linear-gradient(180deg, #000000 0%, #2F4267 100%)';
	thisObj.keybodview.getElement().style.borderRadius = null;
	thisObj.keybodview.getElement().style.boxShadow = '20px 20px 40px 0px rgba(0, 87, 255, 0.25)';
	thisObj.keybodview.getElement().style.borderRadius = null;
};

// 가로
JsCssResponsive.JsWhCssfunlandscape = function(thisObj)
{
	//배경색
	thisObj.mainview.getElement().style.background = 'linear-gradient( to bottom, #101A2F, #182d4e, #03060B)';
	//top
	thisObj.top.getElement().style.width = '16.37%';
	thisObj.top.getElement().style.height = '100%';
	thisObj.top.getElement().style.left = '0px';
	thisObj.top.getElement().style.top = '0px';
	thisObj.top.getElement().style.background = null;
	thisObj.top.getElement().style.background = 'rgba(3,6,11,0.50)';
	thisObj.top.getElement().style.borderRadius = '0px 30px 30px 0px';
	//center
	thisObj.chartview.getElement().style.width  = '82.5%';
	thisObj.chartview.getElement().style.height  = 'calc((100% - 0px) - 0px)';
	thisObj.chartview.getElement().style.left  = '0px';
	thisObj.chartview.getElement().style.top  = '0px';
	thisObj.chartview.getElement().style.backgroundImage = "url('Assets/img/bg04.png')";
	//bottom
	thisObj.bottom.getElement().style.bottom  = null;
	thisObj.bottom.getElement().style.left = null;
	thisObj.bottom.getElement().style.width  = '17.60%';
	thisObj.bottom.getElement().style.height  = '100%';
	thisObj.bottom.getElement().style.right  = '0px';
	thisObj.bottom.getElement().style.top  = '0px';
	thisObj.bottom.getElement().style.background = 'rgba(3,6,11,0.50)';
	thisObj.bottom.getElement().style.borderRadius = '30px 0px 0px 30px';
	
	//차트 선택 분틱 시간 
	thisObj.CX_chartsel.getElement().style.left = '16.37%'; // '222px'
	thisObj.CX_chartsel.getElement().style.zIndex = '4';
	thisObj.CX_mintick.getElement().style.left = '16.37%';  // '222px'
	thisObj.CX_mintick.getElement().style.zIndex = '4';
	thisObj.CX_timesel.getElement().style.left = '16.37%'; // '222px'
	thisObj.CX_timesel.getElement().style.zIndex = '4';
	
	//키보드
	thisObj.keybodview.getElement().style.background = 'linear-gradient(180deg, rgba(0, 0, 0, 0.5) 0%, rgba(0, 47, 140, 0.5) 100%)';
	thisObj.keybodview.getElement().style.border = '1px rgba(86, 130, 203, 1)';
	thisObj.keybodview.getElement().style.boxShadow = '20px 20px 40px 0px rgba(0, 87, 255, 0.25)';
	thisObj.keybodview.getElement().style.borderRadius = '30px';
	
};


// 여기 서 작업 위에는 건들이지 마시오
// 컴포넌트 삭제 
JsCssResponsive.cssRemovecomponent = function(thisObj, classname, named)
{	
	if(thisObj.getClassName() === 'TradeExecution')
	{
		//* TradeExecution.lay 거래화면 상단 *//
		thisObj.top.removeClass(classname['Computerbg01_'+named]);
		thisObj.CX_trhistory.removeClass(classname['Trade_'+named]);
		thisObj.thise.removeClass(classname['won00_'+named]);
		thisObj.thise_money.removeClass(classname['won01_'+named]);
		thisObj.CX_amount.removeClass(classname['won02_'+named]);
		thisObj.Allcoin.removeClass(classname['usercoin_'+named]);
		thisObj.CX_stmketimg.removeClass(classname['usercoinimg_'+named]);
		thisObj.Cointextbox.removeClass(classname['usercointext_'+named]);
		thisObj.CX_tickersymbol.removeClass(classname['usercointext_center_'+named]);
		thisObj.Userinfobox.removeClass(classname['userinfo_'+named]);
		thisObj.CX_usericon.removeClass(classname['userico_'+named]);
		thisObj.CoinBtn_on.removeClass(classname['usercoinbtn_'+named]);

		//* 센터 그래프 *//
		thisObj.chartview.removeClass(classname['Computerbg03_'+named]);
		thisObj.CX_chartsel.removeClass(classname['chatbtn01_'+named]);
		thisObj.CX_mintick.removeClass(classname['chatbtn02_'+named]);
		thisObj.CX_timesel.removeClass(classname['chatbtn03_'+named]);
			
		//* TradeExecution.lay 거래화면 하단 *//
		thisObj.bottom.removeClass(classname['Computerbg02_'+named]);
		thisObj.c_showoption.removeClass(classname['ShowOption_'+named]);
		thisObj.bottombox01.removeClass(classname['maintradebox01_'+named]);
		thisObj.CX_aName.removeClass(classname['mainbox01_'+named]);
		thisObj.bottom_money.removeClass(classname['mainbox02_'+named]);
		thisObj.CX_price.removeClass(classname['mainbox03_'+named]);
		thisObj.CX_plus.removeClass(classname['mainbox04_'+named]);
		thisObj.CX_miance.removeClass(classname['mainbox05_'+named]);
		thisObj.bottombox02.removeClass(classname['maintradebox02_'+named]);
		thisObj.CX_duration.removeClass(classname['mainbox06_'+named]);
		thisObj.Clock_icon.removeClass(classname['mainbox07_'+named]);
		thisObj.CX_date.removeClass(classname['mainbox08_'+named]);
		thisObj.CX_leverage.removeClass(classname['mainbox09_'+named]);
		thisObj.Datadropbox.removeClass(classname['mainbox10_'+named]);
		thisObj.CX_leselect.removeClass(classname['mainbox11_'+named]);
		thisObj.Callputbox.removeClass(classname['callputbox_'+named]);
		thisObj.CX_call.removeClass(classname['callbox_'+named]);
		thisObj.CX_put.removeClass(classname['putbox_'+named]);
		thisObj.keybodview.removeClass(classname['key_bg_'+named]);
		thisObj.bottombox03.removeClass(classname['maintradeboxcell_'+named]);
		thisObj.No_datatext.removeClass(classname['maintradetext05_'+named]);
		thisObj.mainview.removeClass(classname['bottombg_'+named]);
		thisObj.btn_callset.removeClass(classname['btncall02_'+named]);
		thisObj.btn_putset.removeClass(classname['btnput02_'+named]);
	}
	else if(thisObj.getClassName() === 'TradeHistory')
	{
		//* TradeHistory.lay 거래내역 *//
		thisObj.Tradehdbox.removeClass(classname['Tradehd_'+named]);
		thisObj.Tradetoptitle.removeClass(classname['title01_'+named]);
		thisObj.Trade_close.removeClass(classname['Tradeclose_'+named]);
	}
	else if(thisObj.getClassName() === 'TradeListbox')
	{
		//* TradeListbox.lay 거래내역 리스트 *//
		thisObj.TradeListhdbox.removeClass(classname['Tradelist_'+named]);
		thisObj.Tradeleftbox.removeClass(classname['Tradelisthead_'+named]);
		thisObj.c_imgTrd.removeClass(classname['Tradelistheadicon_'+named]);
		thisObj.c_jomok.removeClass(classname['Tradetextdate01_'+named]);
		thisObj.Tradeleftbox02.removeClass(classname['Tradetextdate02_'+named]);
		thisObj.c_date.removeClass(classname['Tradetextdate03_'+named]);
		thisObj.c_time.removeClass(classname['Tradetextdate04_'+named]);
		thisObj.Tradbox_date.removeClass(classname['datenumber_'+named]);
		thisObj.c_pnl.removeClass(classname['datenumber02_'+named]);
		thisObj.c_imgchang.removeClass(classname['dateupdown_'+named]);
		thisObj.Tradearrow01.removeClass(classname['font01_'+named]);
		thisObj.Tradearrow02.removeClass(classname['font01_'+named]);
		thisObj.Tradetextline01.removeClass(classname['font02_'+named]);
		thisObj.Tradetextline02.removeClass(classname['font02_'+named]);
		thisObj.c_invastamt.removeClass(classname['font02_'+named]);
		thisObj.c_invastamt.removeClass(classname['font02_left_'+named]);
		thisObj.c_invastpnl.removeClass(classname['font02_'+named]);
		thisObj.c_invastpnl.removeClass(classname['font03_left_'+named]);
		thisObj.c_grid.removeClass(classname['trade_gird_'+named]);
	}
	else if(thisObj.getClassName() === 'AssetSelection')
	{
		//* AssetSelection.lay 종목선택 *//
		thisObj.infohdbox.removeClass(classname['stockinfo_'+named]);
		thisObj.infohd_title.removeClass(classname['title02_'+named]);
		thisObj.infohd_close.removeClass(classname['infohdclose_'+named]);
		thisObj.infotwobox.removeClass(classname['namebox_'+named]);
		thisObj.infotwoleftbox.removeClass(classname['nameboxleft_'+named]);
		thisObj.Symbol_Names.removeClass(classname['nameboxtwo01_'+named]);
		thisObj.infotworightbox.removeClass(classname['nameboxright'+named]);
		thisObj.Symbol_Codes.removeClass(classname['nameboxtwo02_'+named]);
		thisObj.c_showhideasset.removeClass(classname['infolistbox_'+named]);
	}
	else if(thisObj.getClassName() === 'Allstocklist')
	{
		//* Allstocklist.lay 종목선택리스트 *//
		thisObj.infodata_box02.removeClass(classname['Allstocklistbox_'+named]);
		thisObj.infodate_left.removeClass(classname['infolistbox02_'+named]);
		thisObj.c_img.removeClass(classname['infolisticon02_'+named]);
		thisObj.c_str.removeClass(classname['infolistdate02_'+named]);
		thisObj.infodate_right.removeClass(classname['infolistbox03_'+named]);
		thisObj.c_symbol.removeClass(classname['infolistdate03_'+named]);
	}
	else if(thisObj.getClassName() === 'CustomerSupport')
	{
		//* CustomerSupport.lay 고객정보 *//
		thisObj.c_specustomer.removeClass(classname['langbox_'+named]);
		thisObj.Userinfo_close.removeClass(classname['langclose_'+named]);
		thisObj.Userinfo_icons.removeClass(classname['langicon_'+named]);
		thisObj.Userinfobox_right.removeClass(classname['langboxrightzone'+named]);
		thisObj.c_email.removeClass(classname['langrightemail_'+named]);
		thisObj.c_phon.removeClass(classname['langrightphone_'+named]);
		thisObj.c_name.removeClass(classname['langrightname_'+named]);
		thisObj.c_nikname.removeClass(classname['langrightnick_'+named]);
		thisObj.Userinfobox_left.removeClass(classname['langboxleftzone'+named]);
		thisObj.Email_date02.removeClass(classname['langboxemail_'+named]);
		thisObj.Mobile_date02.removeClass(classname['langphone_'+named]);
		thisObj.Name_date02.removeClass(classname['langname_'+named]);
		thisObj.Nick_date02.removeClass(classname['langnick_'+named]);
		thisObj.Lang_optionbtn.removeClass(classname['langoption_'+named]);
		thisObj.lang_show.removeClass(classname['langshowbox_'+named]);
	}
	else if(thisObj.getClassName() === 'orderList')
	{
		//* orderList.lay 주문리스트 *//
		thisObj.OrderList01.removeClass(classname['list001_'+named]);
		thisObj.OrderList02.removeClass(classname['list002_'+named]);
		thisObj.Order_number.removeClass(classname['ordersize_'+named]);
		thisObj.Order_type.removeClass(classname['ordersize_'+named]);
		thisObj.Order_year.removeClass(classname['ordersize_'+named]);
		thisObj.Order_time.removeClass(classname['ordersize_'+named]);
		thisObj.invest_money.removeClass(classname['ordersize_'+named]);
		thisObj.invest_money.removeClass(classname['list001_last_'+named]);
		thisObj.c_invest_no.removeClass(classname['ordersize_'+named]);
		thisObj.c_symbol.removeClass(classname['ordersize_'+named]);
		thisObj.c_biz_date.removeClass(classname['ordersize_'+named]);
		thisObj.c_buy_time.removeClass(classname['ordersize_'+named]);
		thisObj.c_ord_prc.removeClass(classname['ordersize_'+named]);
		thisObj.c_ord_prc.removeClass(classname['list001_last_'+named]);
		thisObj.Order_leverage.removeClass(classname['ordersize_'+named]);
		thisObj.Division_value.removeClass(classname['ordersize_'+named]);
		thisObj.invest_money02.removeClass(classname['ordersize_'+named]);
		thisObj.Profit_Loss.removeClass(classname['ordersize_'+named]);
		thisObj.Order_sale.removeClass(classname['ordersize_'+named]);
		thisObj.c_leverage.removeClass(classname['ordersize_'+named]);
		thisObj.c_invest_kind.removeClass(classname['ordersize_'+named]);
		thisObj.c_invest_amt.removeClass(classname['ordersize_'+named]);
		thisObj.c_pnlinfo.removeClass(classname['ordersize_'+named]);
		//thisObj.c_infodata.removeClass(classname['ordersize02'+named]);
		thisObj.OrderList01.removeClass(classname['Orderlisttop_'+named]);

	}
	else if(thisObj.getClassName() === 'ChartSelectdrow')
	{
		//* ChartSelectdrow.lay 차트선택리스트 *//
		
		//* 차트버튼관련 *//
		
		thisObj.c_typeheadtxt.removeClass(classname['chatheadtxt01_'+named]);
		thisObj.c_typenamesle.removeClass(classname['chatheadtxt02_'+named]);
		thisObj.chaticonbox01.removeClass(classname['chaticonbox01_'+named]);
		thisObj.grapicon01.removeClass(classname['grapicon01_'+named]);
		thisObj.grapicon02.removeClass(classname['grapicon02_'+named]);
		thisObj.c_type00.removeClass(classname['chatbtnicon01_'+named]);
		thisObj.c_type02.removeClass(classname['chatbtnicon02_'+named]);
		thisObj.h_chatbox.removeClass(classname['chatboxhight_'+named]);
		thisObj.chatheadtime.removeClass(classname['chatheadtime_'+named]);
		thisObj.chattimes.removeClass(classname['chattimetxt_'+named]);
		thisObj.c_mintick.removeClass(classname['chatboxtype02_'+named]);
		thisObj.closetype02.removeClass(classname['closetype02_'+named]);
	}
	else if(thisObj.getClassName() === 'logoutPo')
	{
		//* logoutPo.lay 거래내역 리스트 *//
		thisObj.c_msg.removeClass(classname['popuptext_'+named]);
	}
};

// 컴포넌트 입력
JsCssResponsive.cssAddcomponent = function(thisObj, classname, named)
{	
	if(thisObj.getClassName() === 'TradeExecution')
	{
		//* TradeExecution.lay 거래화면 상단 *//
		thisObj.top.addClass(classname['Computerbg01_'+named]);
		thisObj.CX_trhistory.addClass(classname['Trade_'+named]);
		thisObj.thise.addClass(classname['won00_'+named]);
		thisObj.thise_money.addClass(classname['won01_'+named]);
		thisObj.CX_amount.addClass(classname['won02_'+named]);
		thisObj.Allcoin.addClass(classname['usercoin_'+named]);
		thisObj.CX_stmketimg.addClass(classname['usercoinimg_'+named]);
		thisObj.Cointextbox.addClass(classname['usercointext_'+named]);
		thisObj.CX_tickersymbol.addClass(classname['usercointext_center_'+named]);
		thisObj.Userinfobox.addClass(classname['userinfo_'+named]);
		thisObj.CX_usericon.addClass(classname['userico_'+named]);
		thisObj.CoinBtn_on.addClass(classname['usercoinbtn_'+named]);

		//* 센터 그래프 *//
		thisObj.chartview.addClass(classname['Computerbg03_'+named]);
		thisObj.CX_chartsel.addClass(classname['chatbtn01_'+named]);
		thisObj.CX_mintick.addClass(classname['chatbtn02_'+named]);
		thisObj.CX_timesel.addClass(classname['chatbtn03_'+named]);
			
		//* TradeExecution.lay 거래화면 하단 *//
		thisObj.bottom.addClass(classname['Computerbg02_'+named]);
		thisObj.c_showoption.addClass(classname['ShowOption_'+named]);
		thisObj.bottombox01.addClass(classname['maintradebox01_'+named]);
		thisObj.CX_aName.addClass(classname['mainbox01_'+named]);
		thisObj.bottom_money.addClass(classname['mainbox02_'+named]);
		thisObj.CX_price.addClass(classname['mainbox03_'+named]);
		thisObj.CX_plus.addClass(classname['mainbox04_'+named]);
		thisObj.CX_miance.addClass(classname['mainbox05_'+named]);
		thisObj.bottombox02.addClass(classname['maintradebox02_'+named]);
		thisObj.CX_duration.addClass(classname['mainbox06_'+named]);
		thisObj.Clock_icon.addClass(classname['mainbox07_'+named]);
		thisObj.CX_date.addClass(classname['mainbox08_'+named]);
		thisObj.CX_leverage.addClass(classname['mainbox09_'+named]);
		thisObj.Datadropbox.addClass(classname['mainbox10_'+named]);
		thisObj.CX_leselect.addClass(classname['mainbox11_'+named]);
		thisObj.Callputbox.addClass(classname['callputbox_'+named]);
		thisObj.CX_call.addClass(classname['callbox_'+named]);
		thisObj.CX_put.addClass(classname['putbox_'+named]);
		thisObj.keybodview.addClass(classname['key_bg_'+named]);
		thisObj.bottombox03.addClass(classname['maintradeboxcell_'+named]);
		thisObj.No_datatext.addClass(classname['maintradetext05_'+named]);
		thisObj.mainview.addClass(classname['bottombg_'+named]);
		thisObj.btn_callset.addClass(classname['btncall02_'+named]);
		thisObj.btn_putset.addClass(classname['btnput02_'+named]);
		
	}
	else if(thisObj.getClassName() === 'TradeHistory')
	{
		//* TradeHistory.lay 거래내역 *//
		thisObj.Tradehdbox.addClass(classname['Tradehd_'+named]);
		thisObj.Tradetoptitle.addClass(classname['title01_'+named]);
		thisObj.Trade_close.addClass(classname['Tradeclose_'+named]);
	}
	else if(thisObj.getClassName() === 'TradeListbox')
	{
		//* TradeListbox.lay 거래내역 리스트 *//
		thisObj.TradeListhdbox.addClass(classname['Tradelist_'+named]);
		thisObj.Tradeleftbox.addClass(classname['Tradelisthead_'+named]);
		thisObj.c_imgTrd.addClass(classname['Tradelistheadicon_'+named]);
		thisObj.c_jomok.addClass(classname['Tradetextdate01_'+named]);
		thisObj.Tradeleftbox02.addClass(classname['Tradetextdate02_'+named]);
		thisObj.c_date.addClass(classname['Tradetextdate03_'+named]);
		thisObj.c_time.addClass(classname['Tradetextdate04_'+named]);
		thisObj.Tradbox_date.addClass(classname['datenumber_'+named]);
		thisObj.c_pnl.addClass(classname['datenumber02_'+named]);
		thisObj.c_imgchang.addClass(classname['dateupdown_'+named]);
		thisObj.Tradearrow01.addClass(classname['font01_'+named]);
		thisObj.Tradearrow02.addClass(classname['font01_'+named]);
		thisObj.Tradetextline01.addClass(classname['font02_'+named]);
		thisObj.Tradetextline02.addClass(classname['font02_'+named]);
		thisObj.c_invastamt.addClass(classname['font02_'+named]);
		thisObj.c_invastamt.addClass(classname['font02_left_'+named]);
		thisObj.c_invastpnl.addClass(classname['font02_'+named]);
		thisObj.c_invastpnl.addClass(classname['font03_left_'+named]);
		thisObj.c_grid.addClass(classname['trade_gird_'+named]);
	}
	else if(thisObj.getClassName() === 'AssetSelection')
	{
		//* AssetSelection.lay 종목선택 *//
		thisObj.infohdbox.addClass(classname['stockinfo_'+named]);
		thisObj.infohd_title.addClass(classname['title02_'+named]);
		thisObj.infohd_close.addClass(classname['infohdclose_'+named]);
		thisObj.infotwobox.addClass(classname['namebox_'+named]);
		thisObj.infotwoleftbox.addClass(classname['nameboxleft_'+named]);
		thisObj.Symbol_Names.addClass(classname['nameboxtwo01_'+named]);
		thisObj.infotworightbox.addClass(classname['nameboxright_'+named]);
		thisObj.Symbol_Codes.addClass(classname['nameboxtwo02_'+named]);
		thisObj.c_showhideasset.addClass(classname['infolistbox_'+named]);
	}
	else if(thisObj.getClassName() === 'Allstocklist')
	{
		//* Allstocklist.lay 종목선택리스트 *//
		thisObj.infodata_box02.addClass(classname['Allstocklistbox_'+named]);
		thisObj.infodate_left.addClass(classname['infolistbox02_'+named]);
		thisObj.c_img.addClass(classname['infolisticon02_'+named]);
		thisObj.c_str.addClass(classname['infolistdate02_'+named]);
		thisObj.infodate_right.addClass(classname['infolistbox03_'+named]);
		thisObj.c_symbol.addClass(classname['infolistdate03_'+named]);
	}
	else if(thisObj.getClassName() === 'CustomerSupport')
	{
		//* CustomerSupport.lay 고객정보 *//	
		thisObj.c_specustomer.addClass(classname['langbox_'+named]);
		thisObj.Userinfo_close.addClass(classname['langclose_'+named]);
		thisObj.Userinfo_icons.addClass(classname['langicon_'+named]);
		thisObj.Userinfobox_right.addClass(classname['langboxrightzone_'+named]);
		thisObj.c_email.addClass(classname['langrightemail_'+named]);
		thisObj.c_phon.addClass(classname['langrightphone_'+named]);
		thisObj.c_name.addClass(classname['langrightname_'+named]);
		thisObj.c_nikname.addClass(classname['langrightnick_'+named]);
		thisObj.Userinfobox_left.addClass(classname['langboxleftzone_'+named]);
		thisObj.Email_date02.addClass(classname['langboxemail_'+named]);
		thisObj.Mobile_date02.addClass(classname['langphone_'+named]);
		thisObj.Name_date02.addClass(classname['langname_'+named]);
		thisObj.Nick_date02.addClass(classname['langnick_'+named]);
		thisObj.Lang_optionbtn.addClass(classname['langoption_'+named]);
		thisObj.lang_show.addClass(classname['langshowbox_'+named]);
	}
	else if(thisObj.getClassName() === 'orderList')
	{
		//* orderList.lay 주문리스트 *//
		thisObj.OrderList01.addClass(classname['list001_'+named]);
		thisObj.OrderList02.addClass(classname['list002_'+named]);
		thisObj.Order_number.addClass(classname['ordersize_'+named]);
		thisObj.Order_type.addClass(classname['ordersize_'+named]);
		thisObj.Order_year.addClass(classname['ordersize_'+named]);
		thisObj.Order_time.addClass(classname['ordersize_'+named]);
		thisObj.invest_money.addClass(classname['ordersize_'+named]);
		thisObj.invest_money.addClass(classname['list001_last_'+named]);
		thisObj.c_invest_no.addClass(classname['ordersize_'+named]);
		thisObj.c_symbol.addClass(classname['ordersize_'+named]);
		thisObj.c_biz_date.addClass(classname['ordersize_'+named]);
		thisObj.c_buy_time.addClass(classname['ordersize_'+named]);
		thisObj.c_ord_prc.addClass(classname['ordersize_'+named]);
		thisObj.c_ord_prc.addClass(classname['list001_last_'+named]);
		thisObj.Order_leverage.addClass(classname['ordersize_'+named]);
		thisObj.Division_value.addClass(classname['ordersize_'+named]);
		thisObj.invest_money02.addClass(classname['ordersize_'+named]);
		thisObj.Profit_Loss.addClass(classname['ordersize_'+named]);
		thisObj.Order_sale.addClass(classname['ordersize_'+named]);
		thisObj.c_leverage.addClass(classname['ordersize_'+named]);
		thisObj.c_invest_kind.addClass(classname['ordersize_'+named]);
		thisObj.c_invest_amt.addClass(classname['ordersize_'+named]);
		thisObj.c_pnlinfo.addClass(classname['ordersize_'+named]);
		//thisObj.c_infodata.addClass(classname['ordersize02_'+named]);
		thisObj.OrderList01.addClass(classname['Orderlisttop_'+named]);
		
	}
	else if(thisObj.getClassName() === 'ChartSelectdrow')
	{
		//* ChartSelectdrow.lay 차트선택리스트 *//
		
		//* 차트버튼관련 *//
		thisObj.c_typeheadtxt.addClass(classname['chatheadtxt01_'+named]);
		thisObj.c_typenamesle.addClass(classname['chatheadtxt02_'+named]);
		thisObj.chaticonbox01.addClass(classname['chaticonbox01_'+named]);
		thisObj.grapicon01.addClass(classname['grapicon01_'+named]);
		thisObj.grapicon02.addClass(classname['grapicon02_'+named]);
		thisObj.c_type00.addClass(classname['chatbtnicon01_'+named]);
		thisObj.c_type02.addClass(classname['chatbtnicon02_'+named]);
		thisObj.h_chatbox.addClass(classname['chatboxhight_'+named]);
		thisObj.chatheadtime.addClass(classname['chatheadtime_'+named]);
		thisObj.chattimes.addClass(classname['chattimetxt_'+named]);
		thisObj.c_mintick.addClass(classname['chatboxtype02_'+named]);
		thisObj.closetype02.addClass(classname['closetype02_'+named]);
		
	}
	else if(thisObj.getClassName() === 'logoutPo')
	{
		//* logoutPo.lay 거래내역 리스트 *//
		thisObj.c_msg.addClass(classname['popuptext_'+named]);
	}
};



