function IcandleMouse()
{
	// 변경값
	this.ROW_CNT = ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.dotDegree = [0, 1, 2, 3]; //상단 그래프 금액 구분선 Y좌표 배열
	
	this.TEXT_SIZE = '10px';						//폰트 사이즈
	this.FONT_FAMILY = 'SpoqaHanSansNeo-Regular'; 	// 폰트체
	
	this.BORDER_RADIUS = '10px'; // 라운드

	
	this.m_lineWidthM = 1;		// 마우스 너비 값
	
	this.BOXWIDTH = BOXWIDTH;	//네모 박스 너비
	this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
	this.AM_R_WIDTH = AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BAR_CNT = BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	
	this.m_downheight = DOWNHEIGHT; //상단 그래프 끝 Y좌표
	
	// 기본값 
	// 마우스 터치 x y 값 변수 중요 
	this.m_drawMovetouchoffX = null;
	this.m_drawMovetouchoffY = null;
	
	this.m_arcdrwetf = true;	// 깜박깜박
	

	
	//색상값
	this.colorObj = {
		LINEARC : 'green', 				// 라인끝에 원 중앙 색상
		LINEARCGR : 'transparent', 		// 라인끝에 원색상 그라데이션
		MOUSETEXT : '#000000',				//마우스 텍스트 색
		MOVELINE : '#587cbb',			//마우스 선 and 텍스트박스
		PRCTEXT : '#000',				//현재가 텍스트
	};
	
	// 위치값
	this.pos =
	{
        cavasW : 0,		//전체 캔버스 너비   필요
        cavasH : 0,		//전체 캔버스 높이   필요
        grpW : 0,		//상단,하단 그래프영역 너비
        grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
        dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
        amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
        amPad : 0,		//금액 오른쪽 정렬시 마진
        txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

        upGrpSY : 0,	//상단 그래프 시작 Y좌표
        upDtY : 0,		//상단 그래프 Date 영역 Y
        upGrpEY : 0,	//상단 그래프 끝 Y좌표
        upGrpH : 0,		//상단 그래프 그리는 영역 높이
        kbnY : 0,		//상단,하단 그래프 구분Y
        dwGrpSY : 0,	//하단 그래프 시작 Y좌표
        dwDtY : 0,		//하단 그래프 Date 영역 Y
        dwGrpEY : 0,	//하단 그래프 끝 Y좌표
        dwGrpH : 0,		//하단 그래프 그리는 영역 높이

        dw80Y : 0,		//하단 80퍼센트 높이
        dw20Y : 0,		//하단 20퍼센트 높이

        upRateH : 0,	//상단 높이 비율
        dwRateH : 0,	//하단 높이 비율

        barW : this.DEF_BAR_W, //봉차트 너비

        barTot : 0,		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    };
	
	this.m_height = 4;     // 높이 위치 조정 값 
	this.m_amYsvalue = 0; // 높이 간격 계산값
	
	
	
}


/*******************************************************
========================================================
	차트 데이터 그래프 초기화 함수
========================================================
*******************************************************/

// 그래프 초기화
IcandleMouse.prototype.canvasClear = function()
{
	 this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
};


/*******************************************************
========================================================
	차트 기본값입력
========================================================
*******************************************************/

// 다시 설정해야함
IcandleMouse.prototype.reCalcWidth = function(cnt) {
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;			//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);		//봉차트 너비
};


//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
IcandleMouse.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;									//캔버스 너비   필요
    this.pos.cavasH = elHeight;									//캔버스 높이   필요
	
	

    this.pos.grpEX = elWidth - this.AM_R_WIDTH;   				//상단,하단 오른쪽 금액영역 너비   100
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;			//상단,하단 왼쪽 금액영역 너비     0

    this.pos.amPad = elWidth - 5;								//금액 오른쪽 정렬시 마진

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];   //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]

    this.pos.upGrpSY = elHeight / this.ROW_CNT;			//상단 그래프 시작 Y좌표
    this.pos.txtY = (this.pos.upGrpSY / 2);				//텍스트 세로 중간 정렬을 위한 Y위치
	
	this.pos.upGrpEY = elHeight - this.m_downheight;		//상단 그래프 끝 Y좌표
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;			//상단 그래프 그리는 영역 높이
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;				//상단 그래프 Date 영역 Y
	
	this.m_amYsvalue = (this.pos.upGrpEY - this.pos.upGrpSY ) / this.m_height;
	this.pos.amYs = [this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[0]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[1]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[2]), this.pos.upGrpSY + (this.m_amYsvalue * this.dotDegree[3]), this.pos.upGrpEY];

    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수    //상단,하단 그래프 구분Y
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;		//하단 그래프 시작 Y좌표
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;		//하단 그래프 끝 Y좌표
    this.pos.dwDtY = this.pos.dwGrpEY  + this.pos.txtY;			//하단 그래프 Date 영역 Y
    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;		//하단 그래프 그리는 영역 높이
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;		//하단 80퍼센트 높이
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;		//하단 20퍼센트 높이

    //텍스트 사이즈 셋팅
    /*if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW * 0.03) + 'px';
    else this.TEXT_SIZE = (this.pos.cavasH * 0.02) + 'px';*/

    this.reCalcWidth();
	
    this.startLineX = this.pos.grpEX + this.pos.barW / 2;
};


/*******************************************************
========================================================
	차트 외부 기본값입력 
========================================================
*******************************************************/

// ctx 캔버스 값 넘기기
IcandleMouse.prototype.setCTX = function(ctx, canvas)
{
	this.canvas = canvas;
	this.ctx = ctx;
	this.setTouchEvent();
};

// 차트 변경값 변경
IcandleMouse.prototype.setChangewidhtvalue = function(Obj)
{
	this.AM_R_WIDTH = Obj.AMRWIDTH;	//상단,하단 오른쪽 금액영역 너비
	this.BOXWIDTH = Obj.BOXWIDTH;	//네모 박스 너비
	this.BAR_CNT = Obj.BARCNT; 		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
	this.ROW_CNT = Obj.ROWCNT;		//금액 로우 간격 나누기 계산용 변수
	this.m_downheight = Obj.DOWNHEIGHT; //상단 그래프 끝 Y좌표
	//this.m_xcount = Obj.MXCOUNT;  // 틱기준 자르는기준
	
};


/*******************************************************
========================================================
	차트 외부 데이터 입력값 함수
========================================================
*******************************************************/

//그래프의 너비 및 높이를 업데이트
IcandleMouse.prototype.updatePosition = function(pWidth, pHeight) {
    this.calcPosition(pWidth, pHeight);
	//this.updateGraph();
};


/*******************************************************
========================================================
	차트 캔버스 그리는 함수
========================================================
*******************************************************/

//그래프 무조건 이걸로 호출 업데이트
IcandleMouse.prototype.updateGraph = function() {
	this.draw();
	
};

//차트 진짜 그리기 함수 모음
IcandleMouse.prototype.draw = function() 
{
    //백그라운드 클리어
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
    //텍스트 기본 셋팅
    this.ctx.font = this.TEXT_SIZE + " '" + this.FONT_FAMILY + "'";
	
    this.ctx.textBaseline = 'middle';
	
	this.drawMovetouch(this.m_drawMovetouchoffX, this.m_drawMovetouchoffY);
	
	this.ctx.borderRadius = this.BORDER_RADIUS;
};


/*******************************************************
========================================================
	차트 캔버스 그리는 보조 함수
========================================================
*******************************************************/

//마우스 선택 그리기
IcandleMouse.prototype.drawMovetouch = function(offsetX1, offsetY1) 
{
	if (!offsetX1 || !offsetY1) return;

    // 텍스트 박스 크기 설정
    const boxWidth = 70;
    const boxHeight = 25;
    const radius = 10;

    // x축 시간 및 y축 가격 구분선 그리기
    this.ctx.beginPath();
    this.ctx.lineWidth = this.m_lineWidthM;
    this.ctx.strokeStyle = this.colorObj.MOVELINE;

    // y축 구분선 (시간)
    const yLineStartX = 0;
    const yLineEndX = this.pos.cavasW - boxWidth - 5; // 텍스트 박스 크기에 맞게 선의 끝 위치를 조정
    this.ctx.moveTo(yLineStartX, offsetY1);
    this.ctx.lineTo(yLineEndX, offsetY1);
    this.ctx.stroke();

    // x축 구분선 (가격)
    const xLineStartY = 0;
    const xLineEndY = this.pos.cavasH - boxHeight - 5; // 텍스트 박스 크기에 맞게 선의 끝 위치를 조정
    this.ctx.beginPath();
    this.ctx.moveTo(offsetX1, xLineStartY);
    this.ctx.lineTo(offsetX1, xLineEndY);
    this.ctx.stroke();
    this.ctx.closePath();

    // x축에서 시간을 찾는 로직
    const xwlen = offsetX1 - this.pos.barTot;
    const xtime = theApp.m_timeX.reduce(function(closest, x) {
        if (xwlen < x.x && x.x < offsetX1) {
            if (!closest || (Math.abs(offsetX1 - closest.x) > Math.abs(offsetX1 - x.x))) {
                return x;
            }
        }
        return closest;
    }, null);

    // y축에서 가격을 찾는 로직
    const yhlen = offsetY1 - theApp.m_baryot / 5;
    const yprice = theApp.m_priceY.reduce(function(closest, y) {
        if (yhlen < y.y && y.y < offsetY1) {
            if (!closest || (Math.abs(offsetY1 - closest.y) > Math.abs(offsetY1 - y.y))) {
                return y;
            }
        }
        return closest;
    }, null);

    // 기존 텍스트 박스 지우기
    const prevX = this.pos.cavasW - boxWidth - 5;
    const prevY = offsetY1 - boxHeight / 2;
    this.ctx.clearRect(prevX, prevY, boxWidth, boxHeight);

    // 텍스트 박스 그리기
    if (yprice || xtime) {
        const priceValue = yprice ? yprice.v : null;
        const timeValue = xtime ? xtime.t : null;

        // 둥근 모서리를 가진 텍스트 박스 그리기
        const boxX = this.pos.cavasW - boxWidth - 5;
        const boxY = offsetY1 - boxHeight / 2;

        this.ctx.beginPath();
        this.ctx.moveTo(boxX + radius, boxY);
        this.ctx.lineTo(boxX + boxWidth - radius, boxY);
        this.ctx.quadraticCurveTo(boxX + boxWidth, boxY, boxX + boxWidth, boxY + radius);
        this.ctx.lineTo(boxX + boxWidth, boxY + boxHeight - radius);
        this.ctx.quadraticCurveTo(boxX + boxWidth, boxY + boxHeight, boxX + boxWidth - radius, boxY + boxHeight);
        this.ctx.lineTo(boxX + radius, boxY + boxHeight);
        this.ctx.quadraticCurveTo(boxX, boxY + boxHeight, boxX, boxY + boxHeight - radius);
        this.ctx.lineTo(boxX, boxY + radius);
        this.ctx.quadraticCurveTo(boxX, boxY, boxX + radius, boxY);
        this.ctx.closePath();

        // 텍스트 박스 색상 채우기
        this.ctx.fillStyle = '#587cbb';
        this.ctx.fill();

        // 텍스트 출력
        this.ctx.fillStyle = '#000000';  // 텍스트 색상
        this.ctx.font = '10px SpoqaHanSansNeo-Regular';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(priceValue, boxX + boxWidth / 2, boxY + boxHeight / 2);

        // 추가: 하단 시간 텍스트 박스
        const timeBoxX = offsetX1 - boxWidth / 2;
        const timeBoxY = this.pos.cavasH - boxHeight - 5;
        this.ctx.clearRect(timeBoxX, timeBoxY, boxWidth, boxHeight);
        
        // 둥근 모서리 텍스트 박스 (시간)
        this.ctx.beginPath();
        this.ctx.moveTo(timeBoxX + radius, timeBoxY);
        this.ctx.lineTo(timeBoxX + boxWidth - radius, timeBoxY);
        this.ctx.quadraticCurveTo(timeBoxX + boxWidth, timeBoxY, timeBoxX + boxWidth, timeBoxY + radius);
        this.ctx.lineTo(timeBoxX + boxWidth, timeBoxY + boxHeight - radius);
        this.ctx.quadraticCurveTo(timeBoxX + boxWidth, timeBoxY + boxHeight, timeBoxX + boxWidth - radius, timeBoxY + boxHeight);
        this.ctx.lineTo(timeBoxX + radius, timeBoxY + boxHeight);
        this.ctx.quadraticCurveTo(timeBoxX, timeBoxY + boxHeight, timeBoxX, timeBoxY + boxHeight - radius);
        this.ctx.lineTo(timeBoxX, timeBoxY + radius);
        this.ctx.quadraticCurveTo(timeBoxX, timeBoxY, timeBoxX + radius, timeBoxY);
        this.ctx.closePath();

        this.ctx.fillStyle = '#587cbb';
        this.ctx.fill();

        // 시간 텍스트 출력
        this.ctx.fillStyle = '#000000';
        this.ctx.fillText(timeValue, timeBoxX + boxWidth / 2, timeBoxY + boxHeight / 2);
    }

};







//막대사탕 텍스트 그리기
IcandleMouse.prototype.drawTextlineonly = function(ycolor, xcolor, y, x, texty, textx) 
{
	if(texty)
	{
		this.ctx.strokeStyle = ycolor;
		this.ctx.beginPath();
		this.ctx.lineWidth = this.BOXWIDTH;//this.pos.upGrpSY;
		this.ctx.moveTo(this.pos.grpEX + 1, y);
		this.ctx.lineTo(this.pos.cavasW, y);
		this.ctx.stroke();
		this.ctx.closePath();
		this.ctx.textAlign = 'right';
		this.ctx.fillStyle = this.colorObj.MOUSETEXT; //this.colorObj.TEXT;
		this.ctx.fillText(texty, this.pos.amPad, y);
	}

	if(textx)
	{
		this.ctx.strokeStyle = xcolor;
		this.ctx.beginPath();
		this.ctx.lineWidth = this.BOXWIDTH;//this.pos.upGrpSY;
		this.ctx.moveTo(x - 40 , this.pos.dwDtY);
		this.ctx.lineTo(x + 40, this.pos.dwDtY);
		this.ctx.stroke();
		this.ctx.closePath();
		this.ctx.textAlign = 'center';
		this.ctx.fillStyle = this.colorObj.MOUSETEXT;
		this.ctx.fillText(textx, x, this.pos.dwDtY);
	}
};


/*******************************************************
========================================================
	차트 이벤트 
========================================================
*******************************************************/

//터치이벤트 셋팅
IcandleMouse.prototype.setTouchEvent = function()
{
	var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
		offsetX1,
		offsetY1;
	theApp.isDown = false;
	
    AEvent.bindEvent(this.canvas, AEvent.ACTION_DOWN, function(e) {
		theApp.Icandlechart.setdownTouchEvent(e);
    });

    AEvent.bindEvent(this.canvas, AEvent.ACTION_MOVE, function(e) 
	{
		theApp.Icandlechart.setmoveTouchEvent(e);
		
		//e.preventDefault();
		e.stopPropagation();
		
		touch1 = e.targetTouches[0];
		touch2 = e.targetTouches[1];

		pageX1 = touch1.pageX;
		pageY1 = touch1.pageY;
		
		if(touch1.offsetX || touch1.offsetY)
		{
			offsetX1 = touch1.offsetX;
			offsetY1 = touch1.offsetY;
		}
		else
		{
			offsetX1 = touch1.clientX - thisObj.canvas.offsetParent.offsetLeft;
			offsetY1 = touch1.clientY - thisObj.canvas.offsetParent.offsetTop;
		}
		
		thisObj.m_drawMovetouchoffX = offsetX1;
		thisObj.m_drawMovetouchoffY = offsetY1;
		
		thisObj.draw();
		
    });

    AEvent.bindEvent(this.canvas, AEvent.ACTION_UP, function(e) {
		theApp.Icandlechart.setupTouchEvent(e);
    });
	
	// 마우스가 캔버스를 벗어났을 때 처리
	AEvent.bindEvent(this.canvas, AEvent.ACTION_LEAVE, function(e) {
		thisObj.m_drawMovetouchoffX = null;
		thisObj.m_drawMovetouchoffY = null;
		thisObj.draw();
    });
};



