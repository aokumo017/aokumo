function LangeChangGun()
{

	//TODO:edit here

}

LangeChangGun.cssRemovecomponent = function(thisObj, lang)
{
	if(lang == 'ko')
	{
		if(thisObj.getClassName() === 'TradeExecution')
		{	
			//* TradeExecution.lay 거래화면(한글)*//
			thisObj.CX_trhistory.setText('거래내역');
			thisObj.CX_aName.setText('금액');
			thisObj.CX_duration.setText('만료');
			thisObj.CX_leverage.setText('레버리지');
			thisObj.CX_call.setText('콜');
			thisObj.CX_put.setText('풋');
		} 
		else if(thisObj.getClassName() === 'TradeHistory')
		{	
			//* TradeHistory.lay 거래내역(한글)*//
			thisObj.Tradetoptitle.setText('거래내역');
		}
		else if(thisObj.getClassName() === 'TradeListbox')
		{	
			//* TradeListbox.lay 거래내역 리스트(한글) *//
			thisObj.Tradetextline01.setText('투자');
			thisObj.Tradetextline02.setText('순 이익/손실');
			thisObj.c_grid.setCellText(0, 0, '시작가격');
			thisObj.c_grid.setCellText(0, 2, '종료가격');
			thisObj.c_grid.setCellText(1, 0, '주문일자');
			thisObj.c_grid.setCellText(1, 2, '종료일자');
			thisObj.c_grid.setCellText(2, 0, '주문시간');
			thisObj.c_grid.setCellText(2, 2, '종료시간');
			thisObj.c_grid.setCellText(3, 0, '수수료');
			thisObj.c_grid.setCellText(3, 2, '레버/구분');
			
		}
		else if(thisObj.getClassName() === 'AssetSelection')
		{
			//* AssetSelection.lay 종목선택(한글) *//
			thisObj.infohd_title.setText('종목정보');
		}
		else if(thisObj.getClassName() === 'Allstocklist')
		{
			//* Allstocklist.lay 종목선택리스트(한글) *//
			thisObj.c_str.setText('비트코인');
		}
		else if(thisObj.getClassName() === 'CustomerSupport')
		{
			//* CustomerSupport.lay 고객정보(한글) *//
			thisObj.Lang_optionbtn.setText('언어설정');
			thisObj.LangChanging.setText('언어설정변경');
		}
		else if(thisObj.getClassName() === 'orderList')
		{
			//* orderList.lay 주문리스트(한글) *//
			thisObj.Order_number.setText('주문번호');
			thisObj.Order_type.setText('거래종목');
			thisObj.Order_year.setText('주문일자');
			thisObj.Order_time.setText('주문시간');
			thisObj.invest_money.setText('투자가격');
			thisObj.Order_leverage.setText('레버리지');
			thisObj.Division_value.setText('구분값');
			thisObj.invest_money02.setText('투자금액');
			thisObj.Profit_Loss.setText('이익손실');
			thisObj.Order_sale.setText('판매');
			thisObj.c_infodata.setText('판매'); //* 버튼판매한글 *//
		}
	}
	else if(lang == 'en')
	{
		if(thisObj.getClassName() === 'TradeExecution')
		{
			//* TradeExecution.lay 거래화면(영어)*//
			thisObj.CX_trhistory.setText('Transaction history');
			thisObj.CX_aName.setText('amount');
			thisObj.CX_duration.setText('expiration');
			thisObj.CX_leverage.setText('leverage');
			thisObj.CX_call.setText('call');
			thisObj.CX_put.setText('put');
		}
		else if(thisObj.getClassName() === 'TradeHistory')
		{
			//* TradeHistory.lay 거래내역(영어) *//
			thisObj.Tradetoptitle.setText('Transaction history');
		}
		else if(thisObj.getClassName() === 'TradeListbox')
		{	
			//* TradeListbox.lay 거래내역 리스트(영어) *//
			thisObj.Tradetextline01.setText('Invest');
			thisObj.Tradetextline02.setText('Net profit/loss');
			thisObj.c_grid.setCellText(0, 0, 'Starting price');
			thisObj.c_grid.setCellText(0, 2, 'End price');
			thisObj.c_grid.setCellText(1, 0, 'Order date');
			thisObj.c_grid.setCellText(1, 2, 'End date');
			thisObj.c_grid.setCellText(2, 0, 'Order time');
			thisObj.c_grid.setCellText(2, 2, 'End time');
			thisObj.c_grid.setCellText(3, 0, 'Charge');
			thisObj.c_grid.setCellText(3, 2, 'Lever/Division');
		}
		else if(thisObj.getClassName() === 'AssetSelection')
		{
			//* AssetSelection.lay 종목선택(영어) *//
			thisObj.infohd_title.setText('Stock information');	
		}
		else if(thisObj.getClassName() === 'Allstocklist')
		{
			//* Allstocklist.lay 종목선택리스트(영어) *//
			thisObj.c_str.setText('Bitcoin');
		}
		else if(thisObj.getClassName() === 'CustomerSupport')
		{
			//* CustomerSupport.lay 고객정보(영어) *//
			thisObj.Lang_optionbtn.setText('Language settings');
			thisObj.LangChanging.setText('changing language');
		}
		else if(thisObj.getClassName() === 'orderList')
		{
			//* orderList.lay 주문리스트(영어) *//
			thisObj.Order_number.setText('Order Number');
			thisObj.Order_type.setText('Trading items');
			thisObj.Order_year.setText('Order date');
			thisObj.Order_time.setText('Order time');
			thisObj.invest_money.setText('Investment price');
			thisObj.Order_leverage.setText('Leverage');
			thisObj.Division_value.setText('Separation value');
			thisObj.invest_money02.setText('Investment amount');
			thisObj.Profit_Loss.setText('Profit loss');
			thisObj.Order_sale.setText('Sale');
			thisObj.c_infodata.setText('Sale'); //* 버튼판매영어 *//
		}
	}
};

