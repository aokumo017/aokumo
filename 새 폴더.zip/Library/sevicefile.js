// url 
var TUrl = '/user/info';
var Curl = '/user/quote';
var Ourl = '/user/order';
var STurl = '/user/master';
// 사운드
var s_sound = 'Assets/sound/chegul.wav';
// 환경값
var AMRWIDTH = 80;		//상단,하단 오른쪽 금액영역 너비
var BOXWIDTH = 25;		//네모 박스 너비
var BARCNT = 60;		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
var ROWCNT = 20;		//금액 로우 간격 나누기 계산용 변수
var DOWNHEIGHT = 40;	//상단 그래프 끝 Y좌표
var	MXCOUNT = 20;		// 틱기준 자르는기준

// 국가
var GLANGCHANEV = 'EXESFKR';

// 마켓
var MARKETG = ["NYMEX", "CME", "COMEX"];
var SOSUDECIMALGE = 4; 

//테스트 1 운영 2
var OPERATE_U = 1;
var TESTLOG = 0;