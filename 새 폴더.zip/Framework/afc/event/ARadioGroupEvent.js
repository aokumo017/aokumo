
/**
 * @author asoocool
 */

function ARadioGroupEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(ARadioGroupEvent, AEvent);



//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------


