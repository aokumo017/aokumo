
/**
 * @author asoocool
 */

function ACanvasEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(ACanvasEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------