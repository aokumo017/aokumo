
/**
 * @author asoocool
 */

function AGridLayoutEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(AGridLayoutEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------