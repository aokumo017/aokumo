
/**
 * @author asoocool
 */

function ASplitViewEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(ASplitViewEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------