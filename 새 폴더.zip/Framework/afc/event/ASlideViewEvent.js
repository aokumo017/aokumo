
/**
 * @author asoocool
 */
afc.loadScript("Framework/afc/event/AViewEvent.js");

function ASlideViewEvent(acomp)
{
	AViewEvent.call(this, acomp);
	
}
afc.extendsClass(ASlideViewEvent, AViewEvent);

