
/**
 * @author asoocool
 */

function AFlexViewEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(AFlexViewEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------