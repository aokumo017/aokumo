
/**
 * @author asoocool
 */

function AFlexLayoutEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(AFlexLayoutEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------