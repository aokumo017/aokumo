
/**
 * @author asoocool
 */

function AProgressEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(AProgressEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------