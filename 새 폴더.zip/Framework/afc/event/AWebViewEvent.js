
/**
 * @author asoocool
 */

function AWebViewEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(AWebViewEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------












