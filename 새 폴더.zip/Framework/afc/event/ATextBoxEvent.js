
/**
 * @author asoocool
 */

function ATextBoxEvent(acomp)
{
	AEvent.call(this, acomp);
	
}
afc.extendsClass(ATextBoxEvent, AEvent);




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------