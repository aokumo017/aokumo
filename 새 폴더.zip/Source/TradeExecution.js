afc.loadScript("Source/support/RealtimeF.cls");
afc.loadScript("Source/support/TransactionF.cls");
afc.loadScript("Source/support/UtilityF.cls");
afc.loadScript("Source/support/TestutilF.cls");

// @init 초기화 함수
// @button 버튼 이벤트 부분
// @callback 콜백 호출 데이터 부분
// @real 실시간 관련 함수
// @chart 차트 관련 함수 모음
// @keybord 키보드 관련 함수 모음
// @balane	잔고 관련 함수 모음

function TradeExecution()
{
	AView.call(this);
	// 잔고내역 보였다 안보였다 
	this.usePosition = false;
	// 가격 기준가 
	this.m_pricevalue = 10000;
	// 차트 그림 표준
	this.m_chartdrowType = 1;
	// 차트 css 이전
	this.m_icon = 'graptype_01';
	// 고객 정보 
	this.m_usersetting = null;
	// 소수점
	this.m_Decimal = 2;
	// 잔고 정보
	this.m_Jangolist = [];
	// 체결 마지막 정보
	this.m_balancTimeobj = {};
	// 계산기 열때 이벤트 태우지않기
	this.m_countopicty = true;
	//show option 상태
	this.m_showoptiongun = true;
	
	// 잔고 키보드 위치값 변경 변수
	this.p_MstartY = '0px';		// 메인 시작 위치
	this.p_MendY = null;		// 메인 이동할 위치
	
	this.p_OstartY = '0px';		// 잔고 시작 위치
	this.p_OendY = null;		// 잔고 이동할 위치
	
	this.p_KstartY = '0px';		// 잔고 시작 위치
	this.p_KendY = null;		// 잔고 이동할 위치
	
	this.h_Oheight = 200;		// 잔고화면 높이값 지정
	this.h_Kheight = 200;		// 키보드 화면 높이값 지정
	
	this.d_duration = 500;		// 애니메이션 효과 딜레이시간
	
	this.s_countcheck = 200;	// 시세 체결틱 가져오는 갯수
	
	this.bongchart_type = {
		"sec" : {'time' :  'sec', 'second' : 1000},
		"min.1" : {'time' :  'min.1', 'second' : 60000},
		"min.5" : {'time' :  'min.5', 'second' : 300000},
		"min.10" : {'time' :  'min.10', 'second' : 600000},
	};   // 차트 타입 선택
	this.bcN_index = 'sec';		// 타입 위치값
	
	//중요  실시간셋 종목
	this.b_symbollist = null;  	// 처음 넣을때 
	//현재 이미지 클래스
	this.m_symbolimgCl = null;
	
	// 중요 가로 인지 세로인지 구분값
	this.m_rotationwh = true;	// true 세로 false 가로
	
	// 중요 차트 세로 일때 변수 값
	this.m_portraitchart = {
		AMRWIDTH : 80,		//상단,하단 오른쪽 금액영역 너비
		BOXWIDTH : 25,	//네모 박스 너비
		BARCNT : 70,		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
		ROWCNT : 20,		//금액 로우 간격 나누기 계산용 변수
		DOWNHEIGHT : 40,	//상단 그래프 끝 Y좌표
		MXCOUNT : 15,		// 틱기준 자르는기준
		BAR_TERM : 1.5		//봉차트간 간격
	};
	
	// 중요 차트 가로 일때 변수 값
	this.m_landscapechart = {
		AMRWIDTH : 100,		//상단,하단 오른쪽 금액영역 너비
		BOXWIDTH : 25,	//네모 박스 너비
		BARCNT : 140,		// 조회 했을때의 최초 데이터 길이값   초기 몇개만그릴건지 정하는 숫자
		ROWCNT : 20,		//금액 로우 간격 나누기 계산용 변수
		DOWNHEIGHT : 40,	//상단 그래프 끝 Y좌표
		MXCOUNT : 15,		// 틱기준 자르는기준
		BAR_TERM : 1.5		//봉차트간 간격
	};
	
	// 중요 최초 가로인지 세로인지
	theApp.g_portraitonland = true;
	
	// 중요 클래스 입히기
	theApp.n_cssclassdata = null;
	theApp.n_addcssclassname = '';
	theApp.n_removecssclassname = '';
	
	// 중요 이전 직전 가격
	theApp.g_pricepre = 0;
	
	this.m_checkqertw = false; // 종목 변경시 실시간 데이터의 충돌 방지값
	
	if(OPERATE_U == 1)
	{
		this.realTestdataType = tick_sec;
		this.realTestTypetick = tick_sec;
	}

}
afc.extendsClass(TradeExecution, AView);


/*******************************************************
========================================================
@init 초기화 함수
========================================================
*******************************************************/

TradeExecution.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	RealtimeF.setThisinitfun(this);
	TransactionF.setThisinitfun(this);
	UtilityF.setThisinitfun(this);
	
	// 고객정보조회  => 잔고정보 조회 후 여기 안에서 실시간 셋
	if(OPERATE_U == 2) this.userinfoDATA();
};

TradeExecution.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	if(TESTLOG == 1) console.log(RealtimeF);
	if(TESTLOG == 1) console.log(this);
	var thisObj = this;
	this.CX_chartsel.addClass('graptype_01');
	this.CX_timesel.addClass('graptype_06');

	CanVasWidth.setCanVasinitfun(this);
	CanVasWidth.setBacklinesecmintype(this.bcN_index); // 차트 분틱에따라 값을 넣어줘야함
	
	if(OPERATE_U == 1) this.userinfoDATA();
	
	// 최초 한번 탐 
	var orientapos  = {};
	if(afc.isMobile)
	{
		if (window.matchMedia("(orientation: portrait)").matches) {
			if(TESTLOG == 1) console.log("모바일 세로 Current orientation is portrait");
			orientapos.matches = true;
			theApp.g_portraitonland = true;
			this.mediAresizeCanvas(orientapos);
		} else if (window.matchMedia("(orientation: landscape)").matches) {
			if(TESTLOG == 1) console.log("모바일 가로Current orientation is landscape");
			orientapos.matches = false;
			theApp.g_portraitonland = false;
			this.mediAresizeCanvas(orientapos);
		}
	}
	else
	{
		if (window.matchMedia("(orientation: portrait)").matches) {
			if(TESTLOG == 1) console.log("PC 세로 Current orientation is portrait");
			theApp.g_portraitonland = true;
			this.resizeCanvas();
		} else if (window.matchMedia("(orientation: landscape)").matches) {
			if(TESTLOG == 1) console.log("PC 가로 Current orientation is landscape");
			theApp.g_portraitonland = false;
			this.resizeCanvas();
		}
	}
};

TradeExecution.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
	for(let i = 0; i < theApp.leverage.length; i++)
	{
		this.CX_leselect.addItem( theApp.leverage[i], theApp.leverage[i], theApp.leverage[i] );
	}
	this.CX_leselect.selectItem(theApp.defultindex);
};

TradeExecution.prototype.resizeCanvas = function()
{
	var thisObj = this;
	UtilityF.getcheckAnimationState();
	CanVasWidth.onChartClearof();
	this.onOrientationWidthChange();	// 열려있는창  다 닫기
	// 세로일때
	if(this.tRadeMain.getWidth() < 640)
	{
		theApp.g_portraitonland = true;
		if(thisObj.m_Jangolist.length != 0)
		{
			thisObj.No_traddata.hide();
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.getElement().style.top  = '0px';
			thisObj.trdlis01.show();

			thisObj.toDjangolistview(thisObj.m_Jangolist);
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		theApp.n_addcssclassname = 'ph';
		if(theApp.n_cssclassdata == null) 
		{
			theApp.n_cssclassdata = 'PCH_Class';
			theApp.n_removecssclassname = 'ph';
			JsCssResponsive.cssAddcomponent(this, cssClassname['PCH_Class'], theApp.n_addcssclassname);
		}
		else
		{
			JsCssResponsive.cssRemovecomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_removecssclassname);
			JsCssResponsive.cssAddcomponent(this, cssClassname['PCH_Class'], theApp.n_addcssclassname);
			theApp.n_cssclassdata = 'PCH_Class';
			theApp.n_removecssclassname = 'ph';
		}
		CanVasWidth.setCanVasValuefun(this.m_portraitchart);
		this.m_rotationwh = true;
		JsCssResponsive.JsWhCssfunportrait(this);
	}
	else
	{
		theApp.g_portraitonland = false;
		if(thisObj.m_Jangolist.length != 0)
		{
			thisObj.No_traddata.hide();
			thisObj.trd_tilte.show();
			thisObj.trdlis01.getElement().style.top  = '20px';
			thisObj.trdlis01.show();
			
			thisObj.toDjangolistview(thisObj.m_Jangolist);
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		theApp.n_addcssclassname = 'pw';
		if(theApp.n_cssclassdata == null) 
		{
			theApp.n_cssclassdata = 'PCW_Class';
			theApp.n_removecssclassname = 'pw';
			JsCssResponsive.cssAddcomponent(this, cssClassname['PCW_Class'], theApp.n_addcssclassname);
		}
		else
		{
			JsCssResponsive.cssRemovecomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_removecssclassname);
			JsCssResponsive.cssAddcomponent(this, cssClassname['PCW_Class'], theApp.n_addcssclassname);
			theApp.n_cssclassdata = 'PCW_Class';
			theApp.n_removecssclassname = 'pw';
		}
		CanVasWidth.setCanVasValuefun(this.m_landscapechart);
		this.m_rotationwh = false;
		JsCssResponsive.JsWhCssfunlandscape(this);
	}
	CanVasWidth.portraitCanWhCssfun(this);
	CanVasWidth.onChartWidthChange(this);
	setTimeout(function()
	{
		CanVasWidth.instartdraw();
	}, 1000);
};

TradeExecution.prototype.mediAresizeCanvas = function(mq)
{
	var thisObj = this;
	UtilityF.getcheckAnimationState();
	CanVasWidth.onChartClearof();
	this.onOrientationWidthChange();	// 열려있는창  다 닫기
	// 세로일때
	if (mq.matches) 
	{
		theApp.g_portraitonland = true;
		if(thisObj.m_Jangolist.length != 0)
		{
			thisObj.No_traddata.hide();
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.getElement().style.top  = '0px';
			thisObj.trdlis01.show();

			thisObj.toDjangolistview(thisObj.m_Jangolist);
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		theApp.n_addcssclassname = 'mh';
		if(theApp.n_cssclassdata == null) 
		{
			theApp.n_cssclassdata = 'MH_Class';
			theApp.n_removecssclassname = 'mh';
			JsCssResponsive.cssAddcomponent(this, cssClassname['MH_Class'], theApp.n_addcssclassname);
		}
		else
		{
			JsCssResponsive.cssRemovecomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_removecssclassname);
			JsCssResponsive.cssAddcomponent(this, cssClassname['MH_Class'], theApp.n_addcssclassname);
			theApp.n_cssclassdata = 'MH_Class';
			theApp.n_removecssclassname = 'mh';
		}
		CanVasWidth.setCanVasValuefun(this.m_portraitchart);
		this.m_rotationwh = true;
		JsCssResponsive.JsWhCssfunportrait(this);
	}
	else
	{
		theApp.g_portraitonland = false;
		if(thisObj.m_Jangolist.length != 0)
		{	
			//console.log('여기타지 가로로로');
			thisObj.No_traddata.hide();
			thisObj.trd_tilte.show();
			thisObj.trdlis01.getElement().style.top  = '20px';
			thisObj.trdlis01.show();
			
			thisObj.toDjangolistview(thisObj.m_Jangolist);
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		theApp.n_addcssclassname = 'mw';
		if(theApp.n_cssclassdata == null) 
		{
			theApp.n_cssclassdata = 'MW_Class';
			theApp.n_removecssclassname = 'mw';
			JsCssResponsive.cssAddcomponent(this, cssClassname['MW_Class'], theApp.n_addcssclassname);
		}
		else
		{
			JsCssResponsive.cssRemovecomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_removecssclassname);
			JsCssResponsive.cssAddcomponent(this, cssClassname['MW_Class'], theApp.n_addcssclassname);
			theApp.n_cssclassdata = 'MW_Class';
			theApp.n_removecssclassname = 'mw';
		}
		CanVasWidth.setCanVasValuefun(this.m_landscapechart);
		this.m_rotationwh = false;
		JsCssResponsive.JsWhCssfunlandscape(this);
	}
	CanVasWidth.portraitCanWhCssfun(this);
	CanVasWidth.onChartWidthChange(this);
	setTimeout(function()
	{
		CanVasWidth.instartdraw();
	}, 1000);
};

// 로테이션 할때 열려있는 창 다 닫기
TradeExecution.prototype.onOrientationWidthChange = function()
{
	if(this.window099)
	{
		if(this.window099.isValid() != null)
		{
			this.window099.getContainer().close(99, null);
		}
	}
	
	if(this.openpositionsview.isShow()) this.onCloseClick();
	
	if(this.keybodview.isShow()) this.onClosekeyClick();
};


/*******************************************************
========================================================
@button 버튼 이벤트 부분
========================================================
*******************************************************/

// 잔고내역
TradeExecution.prototype.onPositionClick = function(comp, info, e)
{
	if(!this.m_showoptiongun)
	{
		this.onCloseClick();
		return;
	}
	
	var thisObj = this;
	var v_heighgo = 0;
	if(this.m_rotationwh)
	{
		this.p_MendY = '-' + this.h_Oheight + 'px';
		v_heighgo = this.bottom.getHeight() + this.h_Oheight;
		this.p_OendY  = '-' + v_heighgo + 'px';
	}
	else
	{
		this.p_MendY = '-' + this.h_Oheight + 'px';
		v_heighgo = this.h_Oheight + 100;
		this.p_OendY  = '-' + v_heighgo + 'px';
	}
	
	this.m_showoptiongun = false;
	//comp.enable( false );
	
	this.mainview.getElement().animate(
	[// 키 프레임 정의: 시작 위치
    	{ transform: `translateY(${thisObj.p_MstartY})` },
    	// 키 프레임 정의: 종료 위치
    	{ transform: `translateY(${thisObj.p_MendY})` }
	], {
		// 애니메이션 옵션
    	duration: thisObj.d_duration,  // 1초 동안 진행
		fill: 'forwards'
	});
	
	this.openpositionsview.show();
	this.openpositionsview.getElement().style.height = v_heighgo + 'px';
	this.openpositionsview.getElement().style.top = this.mainview.getHeight() + 'px';
	
	this.openpositionsview.getElement().animate([
		//{ opacity: 0 },
		//{ opacity: 1 }
		{ transform: `translateY(${thisObj.p_OstartY})` },
    	// 키 프레임 정의: 종료 위치
    	{ transform: `translateY(${thisObj.p_OendY })` }
	], {
		duration: thisObj.d_duration,  // 1초 동안 진행
		fill: 'forwards'
	});
	
	this.orderjangolistview(this.m_Jangolist);
};

// 거래내역
TradeExecution.prototype.onTradeHisClick = function(comp, info, e)
{
	var thisObj = this;
	var lay = 'Source/TradeHistory.lay';
	var spe_left = 0, spe_top = 0, spe_height = '', spe_width = '', spe_topvalue = 0, spe_leftvalue = 0, spe_rightvalue = 0, spe_bottomvalue = 0;
	var spqhs_left = 0, spqhs_top = 0;
	if(this.m_rotationwh)
	{
		spqhs_left = 15;
		spqhs_top = this.top.getHeight() + 15;
		
		spe_left = '15px';
		spe_top = '15px';
		spe_leftvalue = 0;
		spe_bottomvalue = this.bottom.getHeight() + 20;
		spe_topvalue = this.top.getHeight() + 15;
		spe_height = `calc((100% - ${spe_topvalue}px) - ${spe_bottomvalue}px)`;
		spe_width = `calc((100% - ${spqhs_left}px) - 15px)`;
	
	}
	else
	{
		spqhs_left = 0;
		spqhs_top = 11;
		spe_leftvalue = this.top.getWidth() + 8;
		if(afc.isMobile)
		{
			spe_rightvalue = this.bottom.getWidth() * 1.5 + 8;
		}
		else
		{
			spe_rightvalue = this.bottom.getWidth() * 2.5 + 8;
		}
		
		spe_left =  spe_leftvalue + 'px';
		spe_top = '11px';
		spe_topvalue = 11;
		spe_height = `calc((100% - ${spe_topvalue}px) - 11px)`;
		spe_width = `calc((100% - ${spe_leftvalue}px) - ${spe_rightvalue}px)`;
	}

	PopupFun.whDialogpopup(this, lay, {gun : this.m_rotationwh, top : spe_top, left : spe_left, height : spe_height, width : spe_width, data : this.m_usersetting.respond}, spqhs_left, spqhs_top, '100%', '100%', function(result, data){
		//console.log(result);
		if(result == 99) return;
	});
};

// 고객정보
TradeExecution.prototype.onCustomsettipngClick = function(comp, info, e)
{
	var thisObj = this;
	var lay = 'Source/CustomerSupport.lay';
	var spe_left = 0, spe_top = 0, spe_height = '', spe_width = '', spe_topvalue = 0, spe_leftvalue = 0, spe_rightvalue = 0, spe_bottomvalue = 0;
	var spqhs_left = 0, spqhs_top = 0;
	if(this.m_rotationwh)
	{
		spqhs_left = 9;
		spqhs_top = this.top.getHeight() + 8;
		
		spe_left = '15px';
		spe_top = '15px';
		spe_leftvalue = 0;
		spe_bottomvalue = this.bottom.getHeight() + 20;
		spe_topvalue = this.top.getHeight() + 15;
		spe_height = `calc((100% - ${spe_topvalue}px) - ${spe_bottomvalue}px)`;
		spe_width = `calc((100% - ${spqhs_left}px) - 9px)`;
	
	}
	else
	{
		spqhs_left = 0;
		spqhs_top = 11;
		spe_leftvalue = this.top.getWidth() + 8;
		spe_rightvalue = this.bottom.getWidth() + 8;
		
		spe_left =  spe_leftvalue + 'px';
		spe_top = '11px';
		spe_topvalue = 11;
		spe_height = `calc((100% - ${spe_topvalue}px) - 11px)`;
		spe_width = `calc((100% - ${spe_leftvalue + 276}px) - ${spe_rightvalue}px)`;
	}

	PopupFun.whDialogpopup(this, lay, {gun : this.m_rotationwh, top : spe_top, left : spe_left, height : spe_height, width : spe_width, data : this.m_usersetting.respond}, spqhs_left, spqhs_top, '100%', '100%', function(result, data){
		//console.log(result);
		if(result == 99) return;
	});
};

// 종목선택
TradeExecution.prototype.onAssetSelectClick = function(comp, info, e)
{
	var thisObj = this;
	var lay = 'Source/AssetSelection.lay';
	var spe_left = 0, spe_top = 0, spe_height = '', spe_width = '', spe_topvalue = 0, spe_leftvalue = 0, spe_rightvalue = 0, spe_bottomvalue = 0;
	var spqhs_left = 0, spqhs_top = 0;
	if(this.m_rotationwh)
	{
		spqhs_left = 15;
		spqhs_top = this.top.getHeight() + 15;
		
		spe_left = '15px';
		spe_top = '15px';
		spe_leftvalue = 0;
		spe_bottomvalue = this.bottom.getHeight() + 20;
		spe_topvalue = this.top.getHeight() + 15;
		spe_height = `calc((100% - ${spe_topvalue}px) - ${spe_bottomvalue}px)`;
		spe_width = `calc((100% - ${spqhs_left}px) - 15px)`;
	
	}
	else
	{
		spqhs_left = 0;
		spqhs_top = 11;
		spe_leftvalue = this.top.getWidth() + 8;
		if(afc.isMobile)
		{
			spe_rightvalue = this.bottom.getWidth() * 1.5 + 8;
		}
		else
		{
			spe_rightvalue = this.bottom.getWidth() * 1 + 8;
		}
		
		spe_left =  spe_leftvalue + 'px';
		spe_top = '11px';
		spe_topvalue = 11;
		spe_height = `calc((100% - ${spe_topvalue}px) - 11px)`;
		spe_width = `calc((100% - ${spe_leftvalue}px) - ${spe_rightvalue}px)`;
	}

	PopupFun.whDialogpopup(this, lay, {gun : this.m_rotationwh, top : spe_top, left : spe_left, height : spe_height, width : spe_width}, spqhs_left, spqhs_top, '100%', '100%', function(result, data){
		//console.log(result);
		if(result == 99) return;
		if(result == 1) thisObj.sYmBolTrChang(data);
	});
};

//차트 그리는거선택
TradeExecution.prototype.onChartdrowsel = function(comp, info, e)
{
	this.ChartdrowType(1);
};

//차트 시간선택
TradeExecution.prototype.onTimedrowsel = function(comp, info, e)
{
	this.ChartdrowType(2);
};

//차트 분틱 시간선택
TradeExecution.prototype.onTimeMindrowsel = function(comp, info, e)
{
	this.ChartdrowType(3);
};

// 포커스 방지
TradeExecution.prototype.onCX_priceFocus = function(comp, info, e)
{
	if(/Mobi|Android/i.test(navigator.userAgent)) {
        // 모바일 기기에서는 포커스를 해제
        event.target.blur();
    }
};

// 숫자만 입력 가능하게 (사용안함)
/*function TradeExecution*onCX_priceChange(comp, info, e)
{
	comp.setText(info.replace(/[^0-9]/g, ''));
};*/

// 금액이 10000원 이하이면 다시 10000으로  (사용안함)
/*function TradeExecution*onCX_priceBlur(comp, info, e)
{
	let vpricedk = Number(comp.getText());
	if(vpricedk < 10000) comp.setText(10000);
};*/

// 금액 입력시 창 뜨게 
TradeExecution.prototype.onCX_priceActiondown = function(comp, info, e)
{
	var thisObj = this;
	
	//this.mainview.getElement().style.top = '-200px';
	this.p_MendY = '-' + this.h_Kheight + 'px';
	this.p_KendY = '-' + this.h_Kheight - 50 + 'px';
	
	comp.enable( false );
	this.c_showoption.enable( false );
	this.CX_plus.enable( false );
	this.CX_miance.enable( false );
	this.CX_call.enable( false );
	this.CX_put.enable( false );
	
	this.CX_price.setText('0');
	
	if(this.m_rotationwh)
	{
		this.mainview.getElement().animate(
		[	// 키 프레임 정의: 시작 위치
			{ transform: `translateY(${thisObj.p_MstartY})`},
			// 키 프레임 정의: 종료 위치
			{ transform: `translateY(${thisObj.p_MendY})`}
		], {
			// 애니메이션 옵션
			duration: thisObj.d_duration,  // 1초 동안 진행
			fill: 'forwards'
		});
		
		this.keybodview.show();
		this.e_closekey.enable( true );
		
		this.keybodview.getElement().style.right = null;
		this.keybodview.getElement().style.top = this.mainview.getHeight() + 'px';
		this.keybodview.getElement().style.left = '0px';
		this.keybodview.getElement().style.width = '100%';
		this.keybodview.getElement().style.height = '250px';

		this.keybodview.getElement().animate([
			//{ opacity: 0 },
			//{ opacity: 1 }
			{ transform: `translateY(${thisObj.p_KstartY})`},
			// 키 프레임 정의: 종료 위치
			{ transform: `translateY(${thisObj.p_KendY })`}
		], {
			duration: thisObj.d_duration,  // 1초 동안 진행
			fill: 'forwards'
		});
	}
	else
	{
		this.keybodview.show();
		this.e_closekey.enable( true );
		this.keybodview.getElement().style.left = null;
		this.keybodview.getElement().style.top = 16 + 'px';
		this.keybodview.getElement().style.right = this.bottom.getWidth() + 'px';
		this.keybodview.getElement().style.width = '500px';
		this.keybodview.getElement().style.height = '500px';
	}
	
	// 1초 후에 내용의 투명도 변경 시작
	setTimeout(() => {
		//thisObj.keybodview.getElement().style.opacity = 1;
		thisObj.m_countopicty = false;
	}, thisObj.d_duration);
};

// + - 함수
TradeExecution.prototype.onValueClick = function(comp, info, e)
{
	var valuepoint = 0;
	var containsComma = this.CX_price.getText().includes(',');
	if(containsComma) valuepoint  = Number(this.CX_price.getText().replace(/(,)/g, ""));
	else valuepoint  = Number(this.CX_price.getText());
	
	var userAmountcheck = Number(this.CX_amount.getText());
	
	if(comp.getComponentId() == 'CX_plus')
	{
		valuepoint += this.m_pricevalue;
		if(valuepoint > userAmountcheck) valuepoint = userAmountcheck;
	}
	else if(comp.getComponentId() == 'CX_miance')
	{
		if(valuepoint > this.m_pricevalue) valuepoint -= this.m_pricevalue;
	}
	
	if(valuepoint < this.m_pricevalue)
	{
		this.CX_price.setText(String(this.m_pricevalue));
	}
	else
	{
		this.CX_price.setText(String(valuepoint));
	}
};

// call 함수
TradeExecution.prototype.onCX_callClick = function(comp, info, e)
{
	var Cellvalue = 0;
	var CellcontainsComma = this.CX_price.getText().includes(',');
	if(CellcontainsComma) Cellvalue  = Number(this.CX_price.getText().replace(/(,)/g, ""));
	else Cellvalue  = Number(this.CX_price.getText());
	
	var Ordinfo = {
		kind :  'C',
		amt : Cellvalue,
		type : '2'
	};
	
	var thisObj = this;
	setTimeout(function()
	{
		thisObj.OrderinfoDATA(Ordinfo)
		.then(function(result){
			console.log('order call success');
		})
		.catch(function(e){
			console.log('error info : ', e);
		});
	}, 500);
};

// put 함수
TradeExecution.prototype.onCX_putClick = function(comp, info, e)
{
	var Putvalue = 0;
	var PutcontainsComma = this.CX_price.getText().includes(',');
	if(PutcontainsComma) Putvalue  = Number(this.CX_price.getText().replace(/(,)/g, ""));
	else Putvalue  = Number(this.CX_price.getText());
	
	var Ordinfo = {
		kind :  'P',
		amt : Putvalue,
		type : '2'
	};
	
	var thisObj = this;
	setTimeout(function()
	{
		thisObj.OrderinfoDATA(Ordinfo)
		.then(function(result){
			console.log('order put success');
		})
		.catch(function(e){
			console.log('error info : ', e);
		});
	}, 500);
};


/*******************************************************
========================================================
@callback 콜백 호출 데이터 부분
========================================================
*******************************************************/

// 주문정보
TradeExecution.prototype.OrderinfoDATA = function(ObjData)
{
	var thisObj = this;
	let orddata01 = {
		request : {
			'invest_kind' : ObjData.kind,
			'market' : thisObj.code.sym_market,
			'symbol' : thisObj.code.sym_symbol,
			'usr_uid' : thisObj.m_usersetting.respond.usr_uid,
			'invest_amt' : ObjData.amt,
			'invest_leverage' : Number(this.CX_leselect.getSelectedItemValue()),
			'invest_type' : ObjData.type
		}
	};
	
	return TransactionF.ordercsinfoinquiry(orddata01)
	.then(function(result){
		if(TESTLOG == 1) console.log('콜정보',result);
		if(result.respond && result.error.success == 'Y')
		{
			return true;
		}
		else
		{
			// 주문실패
			AToast.show(result.error.message);
			return null;
		}
	})
	.catch(function(e){
		// 주문실패
		return e;
	});
};

// 고객정보
TradeExecution.prototype.userinfoDATA = function()
{
	var thisObj = this;
	
	let data01 = {
		request : {
			'usr_uid' : theApp.useruid
		}
	};
	let data02 = {
		request : {
			'usr_uid' : ""
		}
	};
	let data03 = {
		request : {
			'market' : "",
			'symbol' : "",
			'count' : this.s_countcheck,
			'type'  : this.bongchart_type[this.bcN_index].time, // sec 아니면 '' 
		}
	};
	
	if(OPERATE_U == 1)
	{
		if(TESTLOG == 1) console.log('유저정보',user_info);
		thisObj.m_usersetting = user_info;

		if(TESTLOG == 1) console.log('지갑정보',wallet);
		thisObj.CX_amount.setText(wallet.respond.disp_balance);

		if(TESTLOG == 1) console.log('잔고정보',balnse);
		thisObj.code = UtilityF.getShortcdSymbolfind(balnse.respond[0].symbol);
		if(!thisObj.code) thisObj.code = UtilityF.getShortcdSymbol();
		thisObj.m_Jangolist = balnse.respond;
		if(thisObj.m_Jangolist.length != 0)
		{	
			thisObj.No_traddata.hide();
			if(theApp.g_portraitonland)
			{
				thisObj.trd_tilte.hide();
				thisObj.trdlis01.getElement().style.top  = '0px';
				thisObj.trdlis01.show();
				
				thisObj.toDjangolistview(thisObj.m_Jangolist);
			}
			else
			{
				thisObj.trd_tilte.show();
				thisObj.trdlis01.getElement().style.top  = '20px';
				thisObj.trdlis01.show();
				
				thisObj.toDjangolistview(thisObj.m_Jangolist);
			}
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		thisObj.m_Decimal = thisObj.code.sym_decimal; // 소수점 취하기
		theApp.Icandlechart.setDecimalValue(thisObj.m_Decimal);
		thisObj.m_symbolimgCl = thisObj.code;
		thisObj.CX_stmketimg.addClass(thisObj.m_symbolimgCl.class32);
		thisObj.CX_tickersymbol.setText(thisObj.code.sym_symbol);

		if(TESTLOG == 1) console.log('체결정보',this.realTestdataType);
		thisObj.m_balancTimeobj = this.realTestdataType[this.realTestdataType.length -1];
		thisObj.m_balancTimeobj.mt = this.realTestdataType[this.realTestdataType.length -1].t;
		theApp.g_pricepre = this.realTestdataType[this.realTestdataType.length -1].p;
		thisObj.m_qutoedata =  UtilityF.getSisayDataspile(this.realTestdataType);
		setTimeout(function()
		{
			theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
		}, 500);

		//theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
		// 잔고 정보 넣기
		if(thisObj.m_Jangolist.length != 0)
		{
			thisObj.m_Jangolist.forEach(function(Objjango){
				if(Objjango.invest_kind === 'C') 
				{
					if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.CellData(Objjango);
				}
				else
				{
					if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.PutData(Objjango);
				}
			});
		}
		// 리얼 호출 임시 만들어야함
		setTimeout(function()
				   {
			// 배열을 섞는다
			TestutilF.shuffleArray(thisObj.realTestTypetick);
			TestutilF.realdlatltest(thisObj);  // 리얼 시세 셋팅
		}, 500);
	}
	else
	{
		TransactionF.userinfoinquiry(data01)
		.then(function(result){
			if(TESTLOG == 1) console.log('유저정보',result);
			thisObj.m_usersetting = result;
			data02.request.usr_uid = result.respond.usr_uid;
			return TransactionF.walletinfoinquiry(data02);
		})
		.then(function(result){
			if(TESTLOG == 1) console.log('지갑정보',result);
			thisObj.CX_amount.setText(result.respond.disp_balance);
			return TransactionF.balanceinfoinquiry(data02);
		})
		.then(function(result){
			if(TESTLOG == 1) console.log('잔고정보',result);
			if(result.respond)
			{
				if(result.respond.length != 0)
				{
					// 잔고 가 존재함
					thisObj.code = UtilityF.getShortcdSymbolfind(result.respond[0].symbol);
					if(!thisObj.code) thisObj.code = UtilityF.getShortcdSymbol();
					thisObj.m_Jangolist = result.respond;
				}
				else
				{
					// 잔고 미존재
					thisObj.code = UtilityF.getShortcdSymbol();
					thisObj.m_Jangolist = [];
				}
			}
			else
			{
				// 잔고 미존재
				thisObj.code = UtilityF.getShortcdSymbol();
				thisObj.m_Jangolist = [];
			}
			
			if(thisObj.m_Jangolist.length != 0)
			{
				thisObj.No_traddata.hide();
				if(theApp.g_portraitonland)
				{
					thisObj.trd_tilte.hide();
					thisObj.trdlis01.getElement().style.top  = '0px';
					thisObj.trdlis01.show();

					thisObj.toDjangolistview(thisObj.m_Jangolist);
				}
				else
				{
					thisObj.trd_tilte.show();
					thisObj.trdlis01.getElement().style.top  = '20px';
					thisObj.trdlis01.show();

					thisObj.toDjangolistview(thisObj.m_Jangolist);
				}
			}
			else
			{
				thisObj.trd_tilte.hide();
				thisObj.trdlis01.hide();
				thisObj.No_traddata.show();
			}
		
			thisObj.m_Decimal = thisObj.code.sym_decimal; // 소수점 취하기
			theApp.Icandlechart.setDecimalValue(thisObj.m_Decimal);
			// 종목 정보 데이터 조회후 실시간 가동
			data03.request.market = thisObj.code.sym_market;
			data03.request.symbol = thisObj.code.sym_symbol;
			thisObj.m_symbolimgCl  = thisObj.code;
			thisObj.CX_stmketimg.addClass(thisObj.m_symbolimgCl.class32);
			thisObj.CX_tickersymbol.setText(thisObj.code.sym_symbol);
			return TransactionF.Priceinfoinquiry(data03);
		})
		.then(function(result){
			// 시세 받고 처리 
			if(TESTLOG == 1) console.log('체결정보',result.respond);
			if(result.respond)
			{
				if(result.respond.length != 0)
				{
					thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
					thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
					theApp.g_pricepre = result.respond[result.respond.length -1].p;
					thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
					theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
				}
				else
				{
					thisObj.m_qutoedata = [];
					UtilityF.getcheckAnimationState();
					CanVasWidth.onChartClearof();
				}
			}
			else
			{
				// 체결틱 미존재
			}
			thisObj.b_symbollist = UtilityF.mergeArraysIntoC(thisObj.m_Jangolist, thisObj.code);
			if(TESTLOG == 1) console.log('리얼걸꺼 데이터 중요 초기일때 : ', thisObj.b_symbollist);
			RealtimeF.realtimeDATA('0', null, false);  // 리얼 시세 셋팅
		})
		.catch(function(e){
			console.log('error info : ', e);
		})
		.finally(function(){
			//console.log('start finally');
			thisObj.CX_call.enable( true );
			thisObj.CX_put.enable( true );
			if(thisObj.m_Jangolist.length != 0)
			{
				thisObj.m_Jangolist.forEach(function(Objjango){
					if(Objjango.invest_kind === 'C') 
					{
						Objjango.buy_date = ADataMask.Date.date.func(Objjango.buy_date, ':');
						Objjango.ord_time = ADataMask.Date.time.func(Objjango.ord_time, ':');
						if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.CellData(Objjango);
					}
					else
					{
						Objjango.buy_date = ADataMask.Date.date.func(Objjango.buy_date, ':');
						Objjango.ord_time = ADataMask.Date.time.func(Objjango.ord_time, ':');
						if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.PutData(Objjango);
					}
				});
			}
		});
	}
};

// 종목 선택 시 처리
TradeExecution.prototype.sYmBolTrChang = function(symchang)
{
	if(this.code.sym_symbol === symchang.sym_symbol) return;
	
	this.m_checkqertw = true;
	
	this.loading_bar.show();
	var thisObj = this;
	
	this.m_Decimal = symchang.sym_decimal; // 소수점 취하기
	theApp.Icandlechart.setDecimalValue(this.m_Decimal);
	
	var symbolchangimg = symchang;
	this.CX_stmketimg.removeClass(this.m_symbolimgCl.class32);
	this.CX_stmketimg.addClass(symbolchangimg.class32);
	this.CX_tickersymbol.setText(symchang.sym_symbol);
	this.m_symbolimgCl = symbolchangimg;
	
	// 잔고변경할때 해당 내용
	this.b_symbollist.forEach(item => {
		if(item.sym_market == thisObj.code.sym_market && item.sym_symbol == thisObj.code.sym_symbol)
		{
			item.yn_gun -= 1;
			if(item.yn_gun == 0) 
			{
				RealtimeF.realtimeDATA('2', item, false);  // 리얼 시세 셋팅
			}
		}
	});
	
	let sym_data = {
		request : {
			'market' : symchang.sym_market,
			'symbol' : symchang.sym_symbol,
			'count' : this.s_countcheck,
			'type'  : this.bongchart_type[this.bcN_index].time, // sec 아니면 '' 
		}
	};
	
	TransactionF.Priceinfoinquiry(sym_data)
	.then(function(result){
		// 시세 받고 처리 
		if(TESTLOG == 1) console.log('체결정보',result);
		if(result.respond)
		{
			if(result.respond.length != 0)
			{
				if(theApp.Icandlechart.animationState.active)
				{
					setTimeout(function()
					{
						CanVasWidth.onChartClearof();
						thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
						thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
						theApp.g_pricepre = result.respond[result.respond.length -1].p;
						thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
						theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
						thisObj.m_checkqertw  = false;
					}, 1000);
				}
				else
				{
					//UtilityF.getcheckAnimationState();
					CanVasWidth.onChartClearof();
					thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
					thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
					theApp.g_pricepre = result.respond[result.respond.length -1].p;
					thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
					theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
					thisObj.m_checkqertw  = false;
				}
			}
			else
			{
				if(theApp.Icandlechart.animationState.active)
				{
					setTimeout(function()
							   {
						CanVasWidth.onChartClearof();
						thisObj.m_qutoedata = [];
						theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
						thisObj.m_checkqertw  = false;
					}, 1000);
				}
				else
				{
					//UtilityF.getcheckAnimationState();
					CanVasWidth.onChartClearof();
					thisObj.m_qutoedata = [];
					theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
					thisObj.m_checkqertw  = false;
				}
			}
		}
		else
		{
			// 체결틱 미존재
		}
		thisObj.code = symchang;
		
		if(symchang.biz_holiday == 'B')
		{
			setTimeout(function()
			{
				RealtimeF.realtimeDATA('1', symchang, false);  // 리얼 시세 셋팅
				setTimeout(function()
				{
					if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
				}, 0);
			}, 500);
		}
		else
		{
			if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
		}
	})
	.catch(function(e){
		console.log('error info : ', e);
	})
	.finally(function(){
		console.log('finally info : ');
	});
};

// 분틱 시 처리
TradeExecution.prototype.minTickTrChang = function(type)
{
	this.m_checkqertw = true;
	this.loading_bar.show();
	var thisObj = this;
	if(OPERATE_U == 1)
	{
		TestutilF.getOutCleaninterval(this); // 실시간 클린 
		//UtilityF.getcheckAnimationState();
		CanVasWidth.onChartClearof();
		
		if(type == 'sec') this.realTestdataType = tick_sec;
		else if(type == 'min.1') this.realTestdataType = tick_1min;
		else if(type == 'min.5') this.realTestdataType = tick_5min;
		else if(type == 'min.10') this.realTestdataType = tick_10min;
		
		if(TESTLOG == 1) console.log('체결정보틱정보 ',this.realTestdataType);
		this.m_balancTimeobj = this.realTestdataType[this.realTestdataType.length -1];
		this.m_balancTimeobj.mt = this.realTestdataType[this.realTestdataType.length -1].t;
		theApp.g_pricepre = this.realTestdataType[this.realTestdataType.length -1].p;
		this.m_qutoedata =  UtilityF.getSisayDataspile(this.realTestdataType);
		
		setTimeout(function()
		{
			theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
		}, 500);
		
		this.resetjanGolistchart();
		
		// 리얼 호출 임시 만들어야함
		setTimeout(function()
				   {
			// 배열을 섞는다
			TestutilF.shuffleArray(thisObj.realTestTypetick);
			TestutilF.realdlatltest(thisObj);  // 리얼 시세 셋팅
			thisObj.loading_bar.hide();
		}, 1500);
	}
	else
	{
		// 분틱 변경할때 해당 내용
		this.b_symbollist.forEach(item => {
			if(item.sym_market == thisObj.code.sym_market && item.sym_symbol == thisObj.code.sym_symbol)
			{
				item.yn_gun -= 1;
				if(item.yn_gun == 0) 
				{
					RealtimeF.realtimeDATA('2', item, false);  // 리얼 시세 셋팅
				}
			}
		});
		
		let mintick_data = {
			request : {
				'market' : thisObj.code.sym_market,
				'symbol' : thisObj.code.sym_symbol,
				'count' : this.s_countcheck,
				'type'  : type, // sec 아니면 '' 
			}
		};
		
		this.resetjanGolistchart();

		TransactionF.Priceinfoinquiry(mintick_data)
		.then(function(result){
			// 시세 받고 처리 
			if(TESTLOG == 1) console.log('체결정보',result);
			if(result.respond)
			{
				if(result.respond.length != 0)
				{
					//UtilityF.getcheckAnimationState();
					if(theApp.Icandlechart.animationState.active)
					{
						setTimeout(function()
						{
							//console.log(theApp.Icandlechart.animationState.active);
							CanVasWidth.onChartClearof();
							thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
							thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
							theApp.g_pricepre = result.respond[result.respond.length -1].p;
							thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
							theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
							thisObj.m_checkqertw  = false;
						}, 1000);
					}
					else
					{
						CanVasWidth.onChartClearof();
						thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
						thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
						theApp.g_pricepre = result.respond[result.respond.length -1].p;
						thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
						theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
						thisObj.m_checkqertw  = false;
					}
				}
				else
				{
					if(theApp.Icandlechart.animationState.active)
					{
						setTimeout(function()
						{
							CanVasWidth.onChartClearof();
							thisObj.m_qutoedata = [];
							theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
							thisObj.m_checkqertw  = false;
						}, 1000);
					}
					else
					{
						//UtilityF.getcheckAnimationState();
						CanVasWidth.onChartClearof();
						thisObj.m_qutoedata = [];
						theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
						thisObj.m_checkqertw  = false;
					}
				}
			}
			else
			{
				// 체결틱 미존재
			}
			
			setTimeout(function()
			{
				RealtimeF.realtimeDATA('1', thisObj.code, false);  // 리얼 시세 셋팅
				setTimeout(function()
				{
					if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
				}, 0);
			}, 500);

		})
		.catch(function(e){
			console.log('error info : ', e);
		})
		.finally(function(){
			console.log('finally info : ');
		});
	}
};


/*******************************************************
========================================================
@real 실시간 관련 함수
========================================================
*******************************************************/

// 실시간 응답 데이터 
TradeExecution.prototype.onReceived = function(reldata)
{
	let obj = JSON.parse(reldata);
	//console.log('실시간 데이터', obj);
	
	if(obj.ord_status)
	{
		if(obj.ord_status == '1')
		{
			//console.log('매수 체결 실시간 데이터', obj);
			RealtimeF.buyOrderjango(obj);
		}
		else
		{
			//console.log('매도 실시간 데이터', obj);
			RealtimeF.onCleandataupdate(obj, obj.invest_kind);
		}
	}
	else
	{
		if(this.m_checkqertw) return;
		
		if(theApp.Icandlechart.animationState)
		{
			if(!theApp.Icandlechart.animationState.active)
			{
				if(this.loading_bar.isShow()) 
				{
					this.loading_bar.hide();
				}
				//console.log('실시간 시세 데이터 값 : ', new Date(obj.t).getSeconds());
				// 시세
				if(this.code.sym_symbol == obj.pair) 
				{
					//console.log('현재코드 데이터 : ', this.code.sym_symbol, '실시간코드 데이터 : ', obj.pair);
					RealtimeF.realtimeinquiry(obj);
				}
			}
		}
		
		// 잔고
		RealtimeF.insertrelData(obj);
	}
};

// 실시간 끊어질때 다시 셋
TradeExecution.prototype.ReceivSetA = function(reldata)
{
	this.loading_bar.show();
	var thisObj = this;
	this.b_symbollist.forEach(item => {
		if(item.sym_market == thisObj.code.sym_market && item.sym_symbol == thisObj.code.sym_symbol)
		{
			item.yn_gun -= 1;
			if(item.yn_gun == 0) 
			{
				//RealtimeF.realtimeDATA('2', item, false);  // 리얼 시세 셋팅
			}
		}
	});
	
	let data02 = {
		request : {
			'usr_uid' : thisObj.m_usersetting.respond.usr_uid
		}
	};
	
	let sym_data = {
		request : {
			'market' : this.code.sym_market,
			'symbol' : this.code.sym_symbol,
			'count' : this.s_countcheck,
			'type'  : this.bongchart_type[this.bcN_index].time, // sec 아니면 '' 
		}
	};
	
	TransactionF.balanceinfoinquiry(data02)
	.then(function(result){
		if(TESTLOG == 1) console.log('잔고정보',result);
		if(result.respond)
		{
			if(result.respond.length != 0)
			{
				thisObj.m_Jangolist = result.respond;
			}
			else
			{
				// 잔고 미존재
				thisObj.m_Jangolist = [];
			}
		}
		else
		{
			// 잔고 미존재
			thisObj.m_Jangolist = [];
		}

		if(thisObj.m_Jangolist.length != 0)
		{
			thisObj.No_traddata.hide();
			if(theApp.g_portraitonland)
			{
				thisObj.trd_tilte.hide();
				thisObj.trdlis01.getElement().style.top  = '0px';
				thisObj.trdlis01.show();

				thisObj.toDjangolistview(thisObj.m_Jangolist);
			}
			else
			{
				thisObj.trd_tilte.show();
				thisObj.trdlis01.getElement().style.top  = '20px';
				thisObj.trdlis01.show();

				thisObj.toDjangolistview(thisObj.m_Jangolist);
			}
		}
		else
		{
			thisObj.trd_tilte.hide();
			thisObj.trdlis01.hide();
			thisObj.No_traddata.show();
		}
		
		// 종목 정보 데이터 조회후 실시간 가동
		return TransactionF.Priceinfoinquiry(sym_data);
	})
	.then(function(result){
		// 시세 받고 처리 
		if(TESTLOG == 1) console.log('체결정보',result);
		if(result.respond)
		{
			if(result.respond.length != 0)
			{
				CanVasWidth.onChartClearof();
				thisObj.m_balancTimeobj = result.respond[result.respond.length -1];
				thisObj.m_balancTimeobj.mt = result.respond[result.respond.length -1].t;
				theApp.g_pricepre = result.respond[result.respond.length -1].p;
				thisObj.m_qutoedata =  UtilityF.getSisayDataspile(result.respond);
				theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
				thisObj.m_checkqertw  = false;
			}
			else
			{
				CanVasWidth.onChartClearof();
				thisObj.m_qutoedata = [];
				theApp.Icandlechart.setDataClear(thisObj.m_qutoedata );
				thisObj.m_checkqertw  = false;
			}
		}
		else
		{
			// 체결틱 미존재
		}
		
		if(thisObj.code.biz_holiday == 'B')
		{
			setTimeout(function()
			{
				RealtimeF.realtimeDATA('1', thisObj.code, true);  // 리얼 시세 셋팅
				setTimeout(function()
				{
					if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
				}, 0);
			}, 100);
		}
		else
		{
			if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
		}
	})
	.catch(function(e){
		console.log('error info : ', e);
	})
	.finally(function(){
		console.log('finally info : ');
	});
	
	//RealtimeF.realtimeDATA('1', this.code, true);
	
	//theApp.qm.extWebsocketSend({ type : 'A', key  :  this.code.sym_market + '.' + this.code.sym_symbol });
};


/*******************************************************
========================================================
@chart 차트 관련 함수 모음
========================================================
*******************************************************/

//차트 그리는거선택
TradeExecution.prototype.ChartdrowType = function(type)
{
	var thisObj = this;
	var lay = 'Source/ChartSelectdrow.lay';
	var ct_left = 0, ct_top = 0, w_width = 0, h_height = 0;
	if(afc.isMobile)
	{
		if(this.m_rotationwh)
		{
			if(type == 1)
			{
				ct_left = this.CX_chartsel.getWidth() + 20;
				ct_top = this.chartview.getHeight() - this.CX_chartsel.getHeight() - 130;
				w_width = '65%';
				h_height = this.CX_chartsel.getHeight() + 130;
			}
			else if(type == 3)
			{
				ct_left = this.CX_chartsel.getWidth() + 20;
				ct_top = this.chartview.getHeight() - this.CX_chartsel.getHeight() - 130;
				w_width = '41%';
				h_height = this.CX_chartsel.getHeight() + 130;
			}
		}
		else
		{
			if(type == 1)
			{
				ct_left = '23.3%' ;
				ct_top = '45%';
				w_width = '37%';
				h_height = '45%';
			}
			else if(type == 3)
			{
				ct_left = '23.3%';
				ct_top = '30%';
				w_width = '20%';
				h_height = '61%';
			}
		}
	}
	else
	{
		if(this.m_rotationwh)
		{
			if(type == 1)
			{
				ct_left = this.CX_chartsel.getWidth() + 20;
				ct_top = this.chartview.getHeight()  - 160;
				w_width = 320;
				h_height = 200;
			}
			else if(type == 3)
			{
				ct_left = this.CX_chartsel.getWidth() + 20;
				ct_top = this.chartview.getHeight()  - 160;
				w_width = 160;
				h_height = 200;
			}
		}
		else
		{
			if(type == 1)
			{
				ct_left = 300;
				ct_top = this.chartview.getHeight() - 170 - this.CX_chartsel.getHeight() - 20;
				w_width = 320;
				h_height = 200;
			}
			else if(type == 3)
			{
				ct_left = 300;
				ct_top = this.chartview.getHeight() - 170 - this.CX_chartsel.getHeight() - 20;
				w_width = 160;
				h_height = 200;
			}
		}
	}

	PopupFun.whDialogpopup(this, lay, {type : type}, ct_left, ct_top, w_width, h_height, function(result, data){
		if(TESTLOG == 1) console.log(result);
		if(result == 99) return;
		
		if(result == 1)
		{
			if(thisObj.m_chartdrowType === data.type) return;
			
			thisObj.CX_chartsel.removeClass(thisObj.m_icon);
			thisObj.CX_chartsel.addClass(data.icon);
			thisObj.m_icon = data.icon;
			thisObj.m_chartdrowType = data.type;
			if(thisObj.m_chartdrowType == 0 || thisObj.m_chartdrowType == 1)
			{
				thisObj.CX_mintick.enable(false);
				thisObj.bcN_index = 'sec';
				CanVasWidth.setBacklinesecmintype(thisObj.bcN_index); // 차트 분틱에따라 값을 넣어줘야함
				theApp.Icandlechart.setChartType(thisObj.m_chartdrowType);
				thisObj.minTickTrChang(thisObj.bcN_index);
			}
			else
			{
				thisObj.CX_mintick.enable(true);
				if(thisObj.bcN_index === 'sec') 
				{
					thisObj.bcN_index = 'min.1';
					thisObj.CX_mintick.setText('1분');
				}
				CanVasWidth.setBacklinesecmintype(thisObj.bcN_index); // 차트 분틱에따라 값을 넣어줘야함
				theApp.Icandlechart.setChartType(thisObj.m_chartdrowType);
				thisObj.minTickTrChang(thisObj.bcN_index);
			}
		}
		else if(result == 22) 
		{
			thisObj.CX_mintick.setText(data.split('.')[1] + '분');
			if(data === thisObj.bcN_index) return;
			UtilityF.setTickSelectfun(data);
			CanVasWidth.setBacklinesecmintype(thisObj.bcN_index); // 차트 분틱에따라 값을 넣어줘야함
			thisObj.minTickTrChang(thisObj.bcN_index);
		}
	});
};


/*******************************************************
========================================================
@keybord 키보드 관련 함수 모음
========================================================
*******************************************************/

// 숨기기
TradeExecution.prototype.onClosekeyClick = function(comp, info, e)
{
	this.e_closekey.enable( false );
	var thisObj = this;
	let vpricedk  = this.CX_price.getText() || 0;
	let vamount = Number(this.CX_amount.getText());
	//this.keybodview.getElement().style.opacity = 0;
	
	if(vpricedk < 10000) this.CX_price.setText('10000');
	else if(vamount < vpricedk) this.CX_price.setText(String(vamount));
	else this.CX_price.setText(vpricedk);
	
	if(this.m_rotationwh)
	{
		this.mainview.getElement().animate(
			[	// 키 프레임 정의: 시작 위치
				{ transform: `translateY(${thisObj.p_MendY})`},
				// 키 프레임 정의: 종료 위치
				{ transform: `translateY(${thisObj.p_MstartY})`}
			], {
				// 애니메이션 옵션
				duration: thisObj.d_duration,  // 1초 동안 진행
				fill: 'forwards'}
		);
		
		this.keybodview.getElement().animate(
			[
				{ transform: `translateY(${thisObj.p_KendY})`},
				// 키 프레임 정의: 종료 위치
				{ transform: `translateY(${thisObj.p_KstartY })`}
			], {
				duration: thisObj.d_duration,  // 1초 동안 진행
				fill: 'forwards'}
		);
		
		// 1초 후에 내용의 투명도 변경 시작
		setTimeout(() => {
			thisObj.CX_price.enable( true );
			thisObj.c_showoption.enable( true );
			thisObj.CX_plus.enable( true );
			thisObj.CX_miance.enable( true );
			thisObj.CX_call.enable( true );
			thisObj.CX_put.enable( true );
			thisObj.m_countopicty = true;
			thisObj.keybodview.hide();
		}, thisObj.d_duration);
	}
	else
	{
		this.CX_price.enable( true );
		this.c_showoption.enable( true );
		this.CX_plus.enable( true );
		this.CX_miance.enable( true );
		this.CX_call.enable( true );
		this.CX_put.enable( true );
		this.m_countopicty = true;
		this.keybodview.hide();
	}
};

// 숫자넣기
TradeExecution.prototype.onPinButtonClick = function(comp, info, e)
{
	if(this.m_countopicty) return;
	
	var displayvaluepluse = this.CX_price.getText();
	displayvaluepluse += comp.getText();
	this.CX_price.setText(displayvaluepluse);
	
	var ischaraZero = UtilityF.isFirstCharacterZero(this.CX_price.getText());
	if(ischaraZero) 
	{
		this.CX_price.setText('');
		this.CX_price.setText(comp.getText());
		return;
	}
};

// 숫자 지우기버튼선택
TradeExecution.prototype.onPinDelectButton = function(comp, info, e)
{
	var displayvaluedelete = this.CX_price.getText();
	displayvaluedelete = displayvaluedelete.slice(0, -1);
	this.CX_price.setText(displayvaluedelete);
};


/*******************************************************
========================================================
@balane	 잔고 관련 함수 모음
========================================================
*******************************************************/

// 잔고 숨기기
TradeExecution.prototype.onCloseClick = function(comp, info, e)
{
	var thisObj = this;
	
	this.mainview.getElement().animate(
	[
		// 키 프레임 정의: 시작 위치
    	{ transform: `translateY(${thisObj.p_MendY})`},
    	// 키 프레임 정의: 종료 위치
    	{ transform: `translateY(${thisObj.p_MstartY})`}
	], {
		// 애니메이션 옵션
    	duration: thisObj.d_duration,  // 1초 동안 진행
		fill: 'forwards'
	});
	
	this.openpositionsview.getElement().animate(
	[
		//{ opacity: 1 },
		//{ opacity: 0 }
		{ transform: `translateY(${thisObj.p_OendY})`},
    	// 키 프레임 정의: 종료 위치
    	{ transform: `translateY(${thisObj.p_OstartY})`}
	], {
		duration: thisObj.d_duration,  // 1초 동안 진행
		fill: 'forwards'
	});
	
	// 1초 후에 내용의 투명도 변경 시작
	setTimeout(() => {
		//thisObj.c_showoption.enable( true );
		thisObj.m_showoptiongun = true;
		thisObj.openpositionsview.hide();
	}, thisObj.d_duration);
};

// 리스트 뷰 입력
TradeExecution.prototype.orderjangolistview = function(jangolistdata)
{
	this.stocklist002.removeAllItems();
	this.stocklist002.addItem('Source/orderList.lay', jangolistdata);
};

// 청산 주문
TradeExecution.prototype.cleanOrderinfoDATA = function(data)
{
	var thisObj = this;
	var valuebizdata = null;
	var bizdataComma = data.biz_date.includes(':');
	if(bizdataComma) valuebizdata = data.biz_date.replace(/:/g, '');
	else valuebizdata = data.biz_date;
	
	var Ordinfo = {
		request : {
			market              : data.market,
			symbol              : data.symbol,
			usr_uid             : data.usr_uid,
			invest_no           : data.invest_no, // 매수된 invest_no
			biz_date			: valuebizdata,
    	}
	};
	if(TESTLOG == 1) console.log('청산주문인풋 : ',Ordinfo);
	TransactionF.orderClearinfoinquiry(Ordinfo)
	.then(function(result){
		if(result.respond)
		{
			// 성공
		}
		else
		{
			// 주문실패
			AToast.show(result.error.message);
		}
	})
	.catch(function(e){
		// 주문실패
		console.log('error info : ', e);
	});
};

// 자동청산
TradeExecution.prototype.cleanAutoOrderinfoDATA = function(Audata)
{
	var thisObj = this;
	var autovaluebizdata = null;
	var autobizdataComma = Audata.biz_date.includes(':');
	if(autobizdataComma) autovaluebizdata = Audata.biz_date.replace(/:/g, '');
	else autovaluebizdata = Audata.biz_date;
	
	var Ordinfo = {
		request : {
			biz_date    : autovaluebizdata, // 매수 주문의 날짜
			usr_uid     : Audata.usr_uid, // '7548b784b5b8bccd12c31b4ba0360fa2',
			market      : Audata.market, // 'CRYPTO',
			symbol      : Audata.symbol, // 'BTC-USD',
			invest_no   : Audata.invest_no, // '', // 매수된 invest_no
			clear_prc   : Audata.clear_prc,  // 사용자 청산 가격
    	}
	};
	if(TESTLOG == 1) console.log('자동청산주문인풋 : ',Ordinfo);
	TransactionF.orderClearAutoinfoinquiry(Ordinfo)
	.then(function(result){
		if(result.respond)
		{
			// 성공
		}
		else
		{
			// 주문실패
			AToast.show(result.error.message);
		}
	})
	.catch(function(e){
		// 주문실패
		console.log('error info : ', e);
	});
};

// 화면 잔고 표시
TradeExecution.prototype.toDjangolistview = function(listdata)
{
	this.Tdlist00.removeAllItems();
	this.Tdlist00.addItem('Source/TradeList.lay', listdata);
};

// 주문시 화면 잔고 표시
TradeExecution.prototype.toDjangoOrderlistview = function(listdata)
{
	this.Tdlist00.addItem('Source/TradeList.lay', listdata, true);
};


/*******************************************************
========================================================
@jango  잔고 다시 매핑
========================================================
*******************************************************/

// 잔고 차트에 다시 입력
TradeExecution.prototype.resetjanGolistchart = function()
{
	var thisObj = this;
	// 중요 콜 데이터
	theApp.m_CellDataArr = {};
	
	// 중요 풋 데이터
	theApp.m_PutDataArr = {};
	
	
	// 잔고 정보 넣기
	if(this.m_Jangolist.length != 0)
	{
		this.m_Jangolist.forEach(function(Objjango){
			if(Objjango.invest_kind === 'C') 
			{
				if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.CellData(Objjango);
			}
			else
			{
				if(thisObj.code.sym_symbol === Objjango.symbol) theApp.Icandlepos.PutData(Objjango);
			}
		});
	}
};


