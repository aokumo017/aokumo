function TradeHistory()
{
	AView.call(this);
}
afc.extendsClass(TradeHistory, AView);

TradeHistory.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

TradeHistory.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.loading_bar.show();
	this.l_listData = [];
	this.data = [];
    this.itemsPerPage = 50;
    this.currentPage = 0;
	// 마지막값 있으면 true
	this.lastPage_tf = false;
	this.lastEnd_b = true;
	
	this.m_tradehis = this.getContainer().getData();
	
	if(!this.m_tradehis.gun) this.c_speselect.getElement().style.left = this.m_tradehis.left;
	this.c_speselect.getElement().style.width = this.m_tradehis.width;
	this.c_speselect.getElement().style.height = this.m_tradehis.height;
	if(OPERATE_U == 1)
	{
		this.data = order_his;
		this.l_listData = this.getPaginatedData();
		if(TESTLOG == 1) console.log('본 데이터', this.data);
		if(TESTLOG == 1) console.log(this.l_listData );
		this.listviewcell(this.l_listData);
	}
	else this.tradeinfoDATA('');
};

TradeHistory.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

// list view cell
TradeHistory.prototype.listviewcell = function(listdata)
{
	this.Tradelist01.addItem('Source/TradeListbox.lay', listdata);
	this.c_showhidetrade.show();
	if(this.loading_bar.isShow()) this.loading_bar.hide();
};

//닫기
TradeHistory.prototype.onCloseClick = function(comp, info, e)
{
	this.getContainer().close();	
};

// 거래내역 호출
TradeHistory.prototype.tradeinfoDATA = function(nextkey)
{
	var thisObj = this;
	var v_nextkey = nextkey;
	let tradedata01 = {
		request : {
			'usr_uid' : this.m_tradehis.data.usr_uid,
			'next_key' : v_nextkey
		}
	};
	
	this.tradeinfoinquiry(tradedata01)
	.then(function(result){
		if(TESTLOG == 1) console.log('체결내역 : ',result);
		if(result.respond.length != 0)
		{
			thisObj.data =[];
			thisObj.data = result.respond;
			//thisObj.l_listData = thisObj.getPaginatedData();
			thisObj.listviewcell(thisObj.data);
		}
		else
		{
			if(thisObj.loading_bar.isShow()) thisObj.loading_bar.hide();
			thisObj.lastEnd_b = false;
			AToast.show('data does not exist.');
		}
	})
	.catch(function(e){
		// 주문실패
		console.log('error info : ', e);
	});
};

// 거래내역조회
TradeHistory.prototype.tradeinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(TUrl+'/clearing', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 스크롤 마지막인지 
TradeHistory.prototype.onC_showhidetradeScrollbottom = function(comp, info, e)
{
	if(this.data[this.data.length - 1].next_key && this.lastEnd_b)
	{
		this.tradeinfoDATA(this.data[this.data.length - 1].next_key);
	}
	else
	{
		
	}
	/*if(this.lastPage_tf) return;
	
	this.l_listData = [];
	 if ((this.currentPage + 1) * this.itemsPerPage < this.data.length) {
      this.currentPage++;
    }
    this.l_listData = this.getPaginatedData();
	this.listviewcell(this.l_listData);*/
};

TradeHistory.prototype.getPaginatedData = function() {
	const startIndex = this.currentPage * this.itemsPerPage;
	let endIndex = startIndex + this.itemsPerPage;
	
	// 데이터 길이를 넘지 않도록 조정
	if (endIndex > this.data.length) {
		endIndex = this.data.length;
		this.lastPage_tf = true;
	}
	
	return this.data.slice(startIndex, endIndex);
};

