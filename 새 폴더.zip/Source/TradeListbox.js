function TradeListbox()
{
	AView.call(this);
}
afc.extendsClass(TradeListbox, AView);

TradeListbox.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

TradeListbox.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.c_imgchang.addClass('ico_setup01');  
	this.c_showlisttrade.hide();
};

TradeListbox.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

TradeListbox.prototype.setData = function(listData)
{
	let co_pnltoal = 0;
	let co_pnl = Number(listData.invest_pnl);
	this.m_mydata = listData;
	this.m_mydata.symdesc = UtilityF.getShortcdSymbolfind(listData.symbol);
	if(!this.m_mydata.symdesc)
	{
		this.m_mydata.symdesc = UtilityF.getTwoShortcdSymbolfind(listData.symbol);
		if(!this.m_mydata.symdesc) this.m_mydata.symdesc = theApp.g_DefultMster;
	}
	this.c_imgTrd.addClass(this.m_mydata.symdesc.class46);
	this.c_jomok.setText(this.m_mydata.symdesc.sym_desc);
	this.c_date.setText(listData.buy_date);
	this.c_time.setText(listData.sell_time);
	//this.c_pnl.setText(theApp.getMsterDecimalValue(listData.market, listData.symbol, listData.invest_pnl));
	
	co_pnltoal = co_pnl - listData.disp_charge - listData.pfee_pnl;
	this.c_pnl.setText(co_pnltoal);
	
	let kind = null; 
	this.c_invastamt.setText(listData.invest_amt);
	//this.c_invastpnl.setText(theApp.getMsterDecimalValue(listData.market, listData.symbol, listData.invest_pnl));
	this.c_invastpnl.setText(co_pnl);
	
	if(listData.invest_kind == 'C') kind = 'Call';
	else kind = 'Put';
	
	this.c_grid.setCellText(0, 1, theApp.getMsterDecimalValue(listData.market, listData.symbol, listData.buy_prc));
	this.c_grid.setCellText(0, 3, theApp.getMsterDecimalValue(listData.market, listData.symbol, listData.sell_prc));
	
	this.c_grid.setCellText(1, 1, ADataMask.Date.date.func(listData.buy_date, '/'));
	this.c_grid.setCellText(1, 3, ADataMask.Date.date.func(listData.sell_date, '/'));
	
	this.c_grid.setCellText(2, 1, ADataMask.Date.time.func(listData.buy_time, ':'));
	this.c_grid.setCellText(2, 3, ADataMask.Date.time.func(listData.sell_time, ':'));
	
	this.c_grid.setCellText(3, 1, listData.pfee_pnl + '/' + listData.disp_charge);
	this.c_grid.setCellText(3, 3, listData.invest_leverage + '/' +kind);
};

TradeListbox.prototype.onAView1Click03 = function(comp, info, e)
{
	if(this.c_showlisttrade.isShow())
	{
		this.c_imgchang.removeClass('ico_setdown01');
		this.c_imgchang.addClass('ico_setup01');
		this.c_showlisttrade.hide();
	}
	else
	{
		this.c_imgchang.removeClass('ico_setup01');
		this.c_imgchang.addClass('ico_setdown01');
		this.c_showlisttrade.show();
	}
};




