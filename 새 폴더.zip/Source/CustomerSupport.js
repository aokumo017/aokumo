function CustomerSupport()
{
	AView.call(this);
}
afc.extendsClass(CustomerSupport, AView);


CustomerSupport.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

CustomerSupport.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.m_userlange = this.getContainer().getData();
	
	if(!this.m_userlange.gun){
		this.c_specustomer.getElement().style.left = this.m_userlange.left;
		//this.c_specustomer.getElement().style.height = this.m_userlange.height;
	}   
	this.c_specustomer.getElement().style.width = this.m_userlange.width;
	
	this.c_email.setText(this.m_userlange.data.usr_email);
	this.c_phon.setText(this.m_userlange.data.usr_phon);
	this.c_name.setText(this.m_userlange.data.usr_nick);
	this.c_nikname.setText(this.m_userlange.data.usr_nickme);
	let langs = ['1'];
	this.Langlist01.addItem('Source/LangList.lay', langs);
};

CustomerSupport.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

// 나가기
CustomerSupport.prototype.onCloseClick = function(comp, info, e)
{
	this.getContainer().close();
};

CustomerSupport.prototype.onAButton1Click005 = function(comp, info, e)
{
	if(this.lang_show.isShow())
	{
		this.lang_show.hide();
	}
	else
	{
		this.lang_show.show();
	}
};

// 언어값취하기
CustomerSupport.prototype.setlangeChang = function(langdata)
{
	if(TESTLOG == 1) console.log('당신이 선택한언어',langdata);
};