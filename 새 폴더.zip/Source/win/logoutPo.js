function logoutPo()
{
	AView.call(this);
}
afc.extendsClass(logoutPo, AView);


logoutPo.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	console.log()
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

logoutPo.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.c_msg.setText(this.getContainer().getData().data);

};

logoutPo.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};
