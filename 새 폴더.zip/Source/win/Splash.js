
/**
Constructor
Do not call Function in Constructor.
*/
function Splash()
{
	AView.call(this);

	//TODO:edit here

}
afc.extendsClass(Splash, AView);


Splash.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);

	//TODO:edit here

};

Splash.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);

	//TODO:edit here

};

Splash.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);

	//TODO:edit here

};
