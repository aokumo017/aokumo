// ajax url 게임사 요청
HttpioRq.prototype.GameAjaxSend = function(url, data, callback)
{
	// 20240820
	data = data || {};
	data.request = data.request || {};
	data.request.time = new Date().getTime();

	data.hash = CryptoJS.SHA256(data.request.time + '.' + theApp.ekey).toString(CryptoJS.enc.Hex);
	// console.log("data:", data, theApp.esid, theApp.ekey);

	$.ajax({
		type:'POST',
		dataType: "text",
		headers: { 'x-session-id' : theApp.esid, },
		url: url,
		data: JSON.stringify(data),
		success: function(data) 
		{
			if(callback) callback({ result: "success", message: data });
		},
		error: function (error)
		{
			if(callback) callback({ result: false, message: error.statusText });
		}
	});
};

HttpioRq.prototype.Setvibration = function()
{
	theApp.ekey = theApp.g_vibration.login_key;
	theApp.esid = theApp.g_vibration.login_sid;
};