function TransactionF()
{
}


// 초기화
TransactionF.setThisinitfun = function(evtListener)
{
	this.thisObj = evtListener;
	if(TESTLOG == 1) console.log('실시간 리얼타임 : ', this.thisObj);
};

// 고객정보조회
TransactionF.userinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(TUrl+'/customer', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 고객지갑조회
TransactionF.walletinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(TUrl+'/acc', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 잔고정보조회
TransactionF.balanceinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(TUrl+'/balance', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 종목 시세 현재까지 조회
TransactionF.Priceinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(Curl+'/price', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 주문 콜 풋
TransactionF.ordercsinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(Ourl+'/buy', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 청산 콜 풋
TransactionF.orderClearinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(Ourl+'/sell', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};

// 자동 청산 콜 풋
TransactionF.orderClearAutoinfoinquiry = function(indata)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(Ourl+'/set.clear', indata, function(data){
			result = JSON.parse(data.message);
			let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
			if(codenum >= 0) 
			{
				resolve(result);
			}
			else
			{
				theApp.g_errorcheckon = false;
				theApp.tRlogoutMsg(result.error.message);
				//AToast.show(result.error.message);
				theApp.qm.Stopsocket();	
			}
		});
	});
};