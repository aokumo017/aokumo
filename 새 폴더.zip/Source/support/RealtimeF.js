function RealtimeF()
{
}


// 초기화
RealtimeF.setThisinitfun = function(evtListener)
{
	this.thisObj = evtListener;
	if(TESTLOG == 1) console.log('실시간 리얼타임 : ', this.thisObj);
};


// 실시간 셋
RealtimeF.realtimeDATA = function(gun, stcode, recall)
{
	var dataset = null;
	var reldataset = null;
	var isfound = false;
	var isRelcheck = false;
	var recallmove = false;
	
	if(gun == '0')
	{
		this.thisObj.b_symbollist.forEach(item => {
			if(item.yn_gun > 0)	dataset = { type : 'A', key  :  item.sym_market + '.' + item.sym_symbol };
			else dataset = { type : 'D', key  :  item.sym_market + '.' + item.sym_symbol };
			theApp.qm.extWebsocketSend(dataset);
		});
	}
	else if(gun == '1')
	{
		/*theApp.Icandleback.canvasClear();
		theApp.Icandlechart.canvasClear();
		theApp.Icandlebong.canvasClear();
		theApp.Icandlepos.canvasClear();
		theApp.Icandlearc.canvasClear();
		theApp.Icandlemouse.canvasClear();*/
		
		isfound = this.thisObj.b_symbollist.some(item => {
            if (item.sym_market === stcode.sym_market && item.sym_symbol === stcode.sym_symbol) {
				if(item.yn_gun == 0) isRelcheck = true;
                item.yn_gun += 1; // 조건에 맞는 요소가 있으면 yn_gun을 증가
                return true; // 조건에 맞으면 true 반환
            }
            return false; // 조건에 맞지 않으면 계속 검사
        });
		
		if (!isfound) {
			// 조건에 맞는 항목이 없으면 새 항목을 추가
			reldataset  = { sym_market: stcode.sym_market, sym_symbol: stcode.sym_symbol, yn_gun: 1 };
			this.thisObj.b_symbollist.push(reldataset);
			dataset = { type : 'A', key  :  stcode.sym_market + '.' + stcode.sym_symbol };
			theApp.qm.extWebsocketSend(dataset);
		}
		
		if(isRelcheck)
		{
			dataset = { type : 'A', key  :  stcode.sym_market + '.' + stcode.sym_symbol };
			theApp.qm.extWebsocketSend(dataset);
		}
		
		if(recall)
		{
			if(!isRelcheck)
			{
				this.thisObj.b_symbollist.forEach(item => {
					if(item.yn_gun != 0)
					{
						dataset = { type : 'A', key  :  item.sym_market + '.' + item.sym_symbol };
						theApp.qm.extWebsocketSend(dataset);
					}
				});
			}
		}
	}
	else if(gun == '3')
	{
		isfound = this.thisObj.b_symbollist.some(item => {
            if (item.sym_market === stcode.market && item.sym_symbol === stcode.symbol) {
                item.yn_gun += 1; // 조건에 맞는 요소가 있으면 yn_gun을 증가
                return true; // 조건에 맞으면 true 반환
            }
            return false; // 조건에 맞지 않으면 계속 검사
        });
	}
	else
	{
		dataset = { type : 'D', key  :  stcode.sym_market + '.' + stcode.sym_symbol };
		theApp.qm.extWebsocketSend(dataset);
	}
	if(TESTLOG == 1) console.log('현재 리얼 데이터 셋 정보 : ', this.thisObj.b_symbollist);
};

// 매수 아웃풋일때
RealtimeF.buyOrderjango = function(buyData)
{
	var Objdata = {};
	var o_item = [];
	if(buyData.disp_balance !== null) this.thisObj.CX_amount.setText(buyData.disp_balance);
	
	Objdata.biz_date = buyData.biz_date; // ADataMask.Date.date.func(buyData.trd_date, ':'); // 20240530
	Objdata.buy_date = ADataMask.Date.date.func(buyData.trd_date, ':');
	Objdata.buy_time = buyData.trd_time;
	Objdata.invest_amt = buyData.invest_amt;
	Objdata.invest_kind = buyData.invest_kind;
	Objdata.invest_leverage = buyData.invest_leverage;
	Objdata.market = buyData.market;
	Objdata.symbol = buyData.symbol;
	Objdata.usr_id = buyData.usr_id;
	Objdata.usr_uid = this.thisObj.m_usersetting.respond.usr_uid;
	Objdata.mmb_code = this.thisObj.m_usersetting.respond.mmb_code;
	Objdata.loss_prc = buyData.loss_prc;
	Objdata.clear_prc = buyData.clear_prc;
	Objdata.invest_no = buyData.invest_no;
	Objdata.invest_fee = buyData.invest_fee;
	Objdata.ord_prc = buyData.ord_prc;
	Objdata.disp_charge = buyData.disp_charge;
	Objdata.ord_time = ADataMask.Date.time.func(buyData.ord_time, ':');
	
		
	//this.thisObj.m_Jangolist.push(Objdata);
	this.thisObj.m_Jangolist.unshift(Objdata);
	o_item.push(Objdata);
	
	if(this.thisObj.m_Jangolist.length != 0)
	{
		this.thisObj.No_traddata.hide();
		if(theApp.g_portraitonland)
		{
			this.thisObj.trd_tilte.hide();
			this.thisObj.trdlis01.getElement().style.top  = '0px';
			this.thisObj.trdlis01.show();

			this.thisObj.toDjangoOrderlistview(o_item);
		}
		else
		{
			this.thisObj.trd_tilte.show();
			if(afc.isMobile)
			{
				this.thisObj.trdlis01.getElement().style.top  = '20px';
			}
			else
			{
				this.thisObj.trdlis01.getElement().style.top  = '20px';
			}
			this.thisObj.trdlis01.show();

			this.thisObj.toDjangoOrderlistview(o_item);
		}
	}
	else
	{
		this.thisObj.trd_tilte.hide();
		this.thisObj.trdlis01.hide();
		this.thisObj.No_traddata.show();
	}
	
	RealtimeF.realtimeDATA('3', Objdata, false);
	
	if(Objdata.invest_kind == 'C')
	{
		//console.log('cell 주문 : ', Objdata);
		theApp.AudioControl.loadAndPlay(s_sound);
		if(Objdata != null) theApp.Icandlepos.CellData(Objdata);
		AToast.show('Call Order Executed.');
	}
	else
	{
		//console.log('put 주문 : ', Objdata);
		theApp.AudioControl.loadAndPlay(s_sound);
		if(Objdata != null) theApp.Icandlepos.PutData(Objdata);
		AToast.show('Put Order Executed.');
	}
};

// 청산 아웃풋 일때 처리
RealtimeF.onCleandataupdate = function(cleanObj, kind)
{
	theApp.AudioControl.loadAndPlay(s_sound);
	let index01 = this.thisObj.m_Jangolist.findIndex(item => item.invest_no === cleanObj.buy_no);
	this.thisObj.m_Jangolist.splice(index01, 1);
	
	// 청산 일때 해당 내용
	this.thisObj.b_symbollist.forEach(item => {
		if(item.sym_market == cleanObj.market && item.sym_symbol == cleanObj.symbol)
		{
			item.yn_gun -= 1;
			if(item.yn_gun == 0) RealtimeF.realtimeDATA('2', item, false);  // 리얼 시세 셋팅
		}
	});
	if(TESTLOG == 1) console.log('리얼걸꺼 데이터 중요 청산시 : ', this.thisObj.b_symbollist);
	
	if(cleanObj.disp_balance !== null) this.thisObj.CX_amount.setText(cleanObj.disp_balance);
	
	if(kind === 'C') theApp.Icandlepos.CellDataBye(cleanObj);
	else theApp.Icandlepos.PutDataBye(cleanObj);
	
	if(cleanObj.invest_method == 'L')
	{
		if(this.thisObj.stocklist002.getItem(index01))
		{
			this.thisObj.stocklist002.removeItemByIndexAA( index01 );
		}
		
		if(this.thisObj.Tdlist00.getItem(index01))
		{
			this.thisObj.Tdlist00.removeItemByIndexAA( index01 );
		}
	}
	else
	{
		if(this.thisObj.stocklist002.getItem(index01))
		{
			this.thisObj.stocklist002.removeItemByIndex( index01 );
		}
		
		if(this.thisObj.Tdlist00.getItem(index01))
		{
			this.thisObj.Tdlist00.removeItemByIndex( index01 );
		}
	}
	
	if(this.thisObj.m_Jangolist.length != 0)
	{
		// 들필요가없음
	}
	else
	{
		this.thisObj.trd_tilte.hide();
		this.thisObj.trdlis01.hide();
		this.thisObj.No_traddata.show();
	}
	
	AToast.show('Liquidation Executed.');
};

// 실시간 시세 데이터 넣기
RealtimeF.realtimeinquiry = function(inreldata)
{
	var obj = {};
	var pre_mintime = this.thisObj.m_balancTimeobj.mt;
	var uporinsert = UtilityF.compareTimes(this.thisObj.m_balancTimeobj, inreldata);
	
	obj = UtilityF.getRealdataspile(uporinsert, inreldata, this.thisObj.m_balancTimeobj);
	
	if(uporinsert) 
	{
		theApp.Icandlechart.updateRealData(obj);
	}
	else
	{
		pre_mintime = inreldata.t;
		theApp.Icandlechart.addRealData(obj);
	}
	
	this.thisObj.m_balancTimeobj = inreldata;
	this.thisObj.m_balancTimeobj.po = obj.sigprice;
	this.thisObj.m_balancTimeobj.ph = obj.gogaprice;
	this.thisObj.m_balancTimeobj.pl = obj.jongprice;
	this.thisObj.m_balancTimeobj.mt = pre_mintime;
	theApp.g_pricepre = inreldata.p;
};

// 실시간 잔고 데이터 넣기
RealtimeF.insertrelData = function(reldata)
{
	//var thisObj = this.thisObj;
	/*var listitem = this.thisObj.stocklist002.findItem(function(data){
		return (data.symbol === thisObj.pop_positdata.jangodata[0].symbol);
	});*/
	//console.log('데이터 갯수 리스트 : ',this.thisObj.stocklist002.getItems());
	if(this.thisObj.stocklist002.getItems().length != 0)
	{
		this.thisObj.stocklist002.getItems().each(function(index, itemlist){
			
			itemlist.view.relDatalistset(reldata);
		});
	}
	
	if(this.thisObj.Tdlist00.getItems().length != 0)
	{
		this.thisObj.Tdlist00.getItems().each(function(index, itemlist){
			
			itemlist.view.relDatalistset(reldata);
		});
	}
};