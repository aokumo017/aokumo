function TestutilF()
{
}

//  Fisher-Yates shuffle 알고리즘을 사용하여 배열을 섞는 함수
TestutilF.shuffleArray = function(array)
{
	for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
};

//  실시간조회 임시테스트 
TestutilF.realdlatltest = function(thisObj)
{
	var Objdata = null;
	let uporinserttest, timestapmptest, ticktimestapmpa, snTime, tkTime, obj, pre_mintime;
	thisObj.chkInterval = setInterval(function(){
		Objdata = TestutilF.getRandomObject(thisObj.realTestTypetick);
		if(Objdata == null) clearInterval(thisObj.chkInterval);
		pre_mintime = thisObj.m_balancTimeobj.mt;
		uporinserttest = UtilityF.compareTimes(thisObj.m_balancTimeobj, Objdata);
		if(uporinserttest == null) clearInterval(thisObj.chkInterval);
		
		obj = UtilityF.getRealdataspile(uporinserttest, Objdata, thisObj.m_balancTimeobj);
		
		if(uporinserttest) 
		{
			theApp.Icandlechart.updateRealData(obj);
		}
		else
		{
			pre_mintime = Objdata.t;
			theApp.Icandlechart.addRealData(obj);
		}

		thisObj.m_balancTimeobj = Objdata;
		thisObj.m_balancTimeobj.mt = pre_mintime;
		theApp.g_pricepre = Objdata.p;
	}, 1000);
};

//  실시간 죽이기
TestutilF.getOutCleaninterval = function(thisObj)
{
	if(TESTLOG == 1) console.log(' 클린 안타냐 ? ', this.chkInterval);
	clearInterval(thisObj.chkInterval);
};

//  랜덤으로 데이터를 하나씩 뽑는 함수
TestutilF.getRandomObject = function(objectsArray)
{
	if (objectsArray.length === 0) {
        console.log("No more objects to draw.");
        return null;
    }
    return objectsArray.pop(); // 배열의 마지막 요소를 꺼내고 반환
};