function UtilityF()
{

}


// 초기화
UtilityF.setThisinitfun = function(evtListener)
{
	this.thisObj = evtListener;
	if(TESTLOG == 1) console.log('실시간 리얼타임 : ', this.thisObj);
	theApp.util_mintick = [
		[5,10,15,20,25,30,35,40,45,50,55,60],
		[10,20,30,40,50,60]
	];
};

// 중요 데이터 양식에 맞게 합치기
UtilityF.mergeArraysIntoC = function(A, B)
{
	//const C = [];
	// 중복 제거 및 yn_gun 업데이트 로직을 위한 Map 초기화
    const uniqueMap = new Map();
	
	if (A.length !== 0) {
		A.forEach(item => {
			if (uniqueMap.has(item.symbol)) {
				let existingItem = uniqueMap.get(item.symbol);
				existingItem.yn_gun += 1;
				uniqueMap.set(item.symbol, existingItem);
			} else {
				uniqueMap.set(item.symbol, { sym_market: item.market, sym_symbol: item.symbol, yn_gun: 1 });
			}
		});
	}
	if(B != null)
	{
		if (uniqueMap.has(B.sym_symbol)) {
			let existingItem = uniqueMap.get(B.sym_symbol);
			existingItem.yn_gun += 1;
			uniqueMap.set(B.sym_symbol, existingItem);
		} 
		else {
			uniqueMap.set(B.sym_symbol, { sym_market: B.sym_market, sym_symbol: B.sym_symbol, yn_gun: 1 });
		}
	}
	
	// Map의 값들을 배열로 변환하여 반환
	return Array.from(uniqueMap.values());
};

// 시간 차이
UtilityF.compareTimes = function(originalTime, balanceTime, gun)
{
	var thisUtill = theApp;
	var v_Previoustime = null;
	var v_Currenttime =  null;
	
	if(originalTime == null) return null;
	if(balanceTime == null) return null;
	
	const diff = Math.abs(balanceTime.t - originalTime.mt);
	
	// 1분, 5분, 10분을 밀리초로 변환
	const oneMinute = 1 * 60 * 1000;
	const fiveMinutes = 5 * 60 * 1000;
	const tenMinutes = 10 * 60 * 1000;
	
	let previousDate = null, currentDate = null;
	
	if(theApp.g_userLanguage === GLANGCHANEV)
	{
		previousDate = new Date(originalTime.mt);
    	currentDate = new Date(balanceTime.t);
	}
	else
	{
		previousDate = UtilityF.convertTimestampToKST(originalTime.mt);
    	currentDate = UtilityF.convertTimestampToKST(balanceTime.t);
	}
	
	const previousMinutes = previousDate.getMinutes();
    const currentMinutes = currentDate.getMinutes();
	
	if(TESTLOG == 3) console.log('지금 들어오는 타입은 ? : ', this.thisObj.bongchart_type[this.thisObj.bcN_index].time);
	// 시간 간격 비교 함수
    function isSameMinuteInterval(interval) {
		let Pre_value = 0, cur_valie = 0;
		let pre_timecheck = Math.floor(previousMinutes / interval);
		let cur_timecheck = Math.floor(currentMinutes / interval);
		
		if(interval == 1)
		{
			return Math.floor(previousMinutes / interval) === Math.floor(currentMinutes / interval);
		}
		else if(interval == 5)
		{
			if(TESTLOG == 1) console.log(thisUtill.util_mintick);
			Pre_value = thisUtill.util_mintick[0][pre_timecheck - 1] || 0;
			cur_valie = thisUtill.util_mintick[0][cur_timecheck - 1] || 0;
		}
		else if(interval == 10)
		{
			Pre_value = thisUtill.util_mintick[1][pre_timecheck - 1] || 0;
			cur_valie = thisUtill.util_mintick[1][cur_timecheck - 1] || 0;
		}
		
		if(Pre_value < cur_valie)
		{
			return false;
		}
		else if(cur_valie == 0 && Pre_value != 0)
		{
			return false;
		}
		else
		{
			return true;
		}
    }
	
	if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'sec')
	{
		if(theApp.g_userLanguage === GLANGCHANEV)
		{
			v_Previoustime = new Date(originalTime.t);
			v_Currenttime =  new Date(balanceTime.t);
		}
		else
		{
			v_Previoustime = UtilityF.convertTimestampToKST(originalTime.t);
			v_Currenttime =  UtilityF.convertTimestampToKST(balanceTime.t);
		}
		
		if (v_Previoustime.getSeconds().toString().padStart(2, '0') ==  v_Currenttime.getSeconds().toString().padStart(2, '0')) {
			//console.log("1초 이내입니다.");
			return true;
		} 
		else {
			//console.log("1초 이상입니다.");
			return false;
		}
	}
	else if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'min.1')
	{
		if (isSameMinuteInterval(1)) {
			//console.log("1분 이내");
			return true;
		} else {
			//console.log("1분 이상");
			return false;
		}
	}
	else if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'min.5')
	{
		if (isSameMinuteInterval(5)) {
			//console.log("5분 이내");
			return true;
		} else {
			//console.log("5분 이상");
			return false;
		}
	}
	else if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'min.10')
	{
		if (isSameMinuteInterval(10)) {
			//console.log("10분 이내");
			return true;
		} else {
			//console.log("10분 이상");
			return false;
		}
	}
};

// 사용유무 종목 취하기
UtilityF.getShortcdSymbol = function()
{
	var usr_used = 'Y';
	return theApp.MsterSymbol.find(function(s){
		return s.sym_used === usr_used;
	});
};

// 종목가져오기
UtilityF.getShortcdSymbolfind = function(scode)
{
	return theApp.MsterSymbol.find(function(s){
		return s.sym_symbol === scode;
	});
};

// 2자리로 가져오기 종목가져오기
UtilityF.getTwoShortcdSymbolfind = function(scode)
{
	return theApp.MsterSymbol.find(function(s){
		return s.sym_symbol.substring(0, 2) === scode.substring(0, 2);
	});
};

// 값에 의한 소수점 자리수 가져오기
UtilityF.getCountDecimalPlaces = function(value)
{
	if(!isFinite(value))
	{
		return 0;
	}
	let text = value.toString();
	
	if(text.indexOf('.') !== 1)
	{
		return text.split('.')[1].length;
	}
	return 0;
};

// 데이터 정제
UtilityF.getSisayDataspile = function(arr)
{
	var puridata = [], Objdata = null;
	/*arr.sort(function(a, b){
		return b.t - a.t;
	});*/
	arr.forEach(function(value){
		Objdata = {};
		Objdata = UtilityF.getSiDateTime(value);
		puridata.push(Objdata);
	});
	return puridata;
};

// 체결 데이터 정제
UtilityF.getSiDateTime = function(indata)
{
	let timestapmpa = indata.t;
	let ticktimestapmpa = indata.pt;
	
	let snTime = null, tkTime = null;
	
	if(theApp.g_userLanguage === GLANGCHANEV)
	{
		snTime = new Date(timestapmpa);
		tkTime = new Date(ticktimestapmpa);
	}
	else
	{
		snTime = UtilityF.convertTimestampToKST(timestapmpa);
		tkTime = UtilityF.convertTimestampToKST(ticktimestapmpa);
	}
	
	//snTime.setHours(snTime.getHours() + 9);
	
	// 날짜 YYYYMMDD 형식으로 포맷
	let secDate = snTime.getFullYear().toString() + ':' +
		(snTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		snTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let secTime = snTime.getHours().toString().padStart(2, '0') + ':' +
		snTime.getMinutes().toString().padStart(2, '0') + ':' +
		snTime.getSeconds().toString().padStart(2, '0');
		
	// 날짜 YYYYMMDD 형식으로 포맷
	let tickDate = tkTime.getFullYear().toString() + ':' +
		(tkTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		tkTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let tickTime = tkTime.getHours().toString().padStart(2, '0') + ':' +
		tkTime.getMinutes().toString().padStart(2, '0') + ':' +
		tkTime.getSeconds().toString().padStart(2, '0');

	let price = indata.p;
	let sigprice = indata.po;
	let gogaprice = indata.ph;
	let jongprice = indata.pl;
	let market = indata.ev;
	let symbol = indata.pair;
	
	return { market, symbol, secDate, secTime, tickDate, tickTime, price, sigprice, gogaprice, jongprice};
};

// 자동청산 퍼센트
UtilityF.getPercentAutofun = function(percent, price)
{
	let percentage = percent / 100;
	let finalPrice = price + (price * percentage);
    return finalPrice;
};

// 숫자 제로인지 체크
UtilityF.isFirstCharacterZero = function(str)
{
	return /^0/.test(str);
};

// 정규식을 사용하여 초 부분을 "00"으로 바꾸기
UtilityF.replaceSecondsWithZero = function(timeString)
{
    return timeString.replace(/:\d{2}$/, ':00');
};

// 정규표현식을 사용하여 분 부분을 찾아서 00으로 바꿉니다.
UtilityF.replaceMinutes = function(timeString)
{
    return timeString.replace(/:(\d{2}):/, ':00:');
};

// 분틱선택함수
UtilityF.setTickSelectfun = function(tickvalue)
{
	this.thisObj.bcN_index = tickvalue;
};

// 분틱 원 색상 함수
UtilityF.getcompareNumbersfun = function(num1, num2)
{
	let result = num1 - num2;

    if (result > 0) {
        return "#ff4e4e"; // Positive: Red
    } else if (result < 0) {
        return "#57a1d0"; // Negative: Blue
    } else {
        return "#e4e5ec"; // Equal: Black
    }
};

// 분틱 투 색상 함수
UtilityF.getcompareNumberstwofun = function(num1, num2)
{
	let result = num1 - num2;

    if (result > 0) {
        return "#ff4c34"; // Positive: Red
    } else if (result < 0) {
        return "#2cac40"; // Negative: Blue
    } else {
        return "#e4e5ec"; // Equal: Black
    }
};

// 분틱 둥근 사각형 그리기 함수 정의
UtilityF.setdrawRoundedRectfun = function(ctx, x, y, width, height, radius)
{
	ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.arc(x + width - radius, y + radius, radius, 1.5 * Math.PI, 0, false);
    ctx.lineTo(x + width, y + height - radius);
    ctx.arc(x + width - radius, y + height - radius, radius, 0, 0.5 * Math.PI, false);
    ctx.lineTo(x + radius, y + height);
    ctx.arc(x + radius, y + height - radius, radius, 0.5 * Math.PI, Math.PI, false);
    ctx.lineTo(x, y + radius);
    ctx.arc(x + radius, y + radius, radius, Math.PI, 1.5 * Math.PI, false);
    ctx.closePath();
};

// 애니메이션이 돌아가고있는지 체크
UtilityF.getcheckAnimationState = function()
{
	let u_count = 0;
	while (true) {
		if (u_count > 1000) {
			break;
		}
		u_count++;
	}
};

// 실시간 데이터 정제
UtilityF.getRealdataspile = function(gun, realdata, predata)
{
	let ObjrealData = {};
	
	if(gun) // 업데이트
	{
		if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'sec')
		{
			ObjrealData = UtilityF.setSecdataCleaning(realdata);
		}
		else
		{
			ObjrealData = UtilityF.setupOnemindataCleaning(realdata, predata);
		}
	}
	else // 추가 
	{
		if(this.thisObj.bongchart_type[this.thisObj.bcN_index].time == 'sec')
		{
			ObjrealData = UtilityF.setSecdataCleaning(realdata);
		}
		else
		{
			ObjrealData = UtilityF.setinsertOnemindataCleaning(realdata, predata);
		}
	}
	return ObjrealData;
};

// 실시간 데이터 1초
UtilityF.setSecdataCleaning = function(inreldata)
{
	let timestapmp = inreldata.t;
	let ticktimestapmpa = Math.floor(inreldata.t / (60 * 1000)) * (60 * 1000);  //  inreldata.pt;
	
	let snTime = null, tkTime = null;
	
	if(theApp.g_userLanguage === GLANGCHANEV)
	{
		snTime = new Date(timestapmp);
		tkTime = new Date(ticktimestapmpa);
	}
	else
	{
		snTime = UtilityF.convertTimestampToKST(timestapmp);
		tkTime = UtilityF.convertTimestampToKST(ticktimestapmpa);
	}
	
	//snTime.setHours(snTime.getHours() + 9);
	
	// 날짜 YYYYMMDD 형식으로 포맷
	let secDate = snTime.getFullYear().toString() + ':' +
		(snTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		snTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let secTime = snTime.getHours().toString().padStart(2, '0') + ':' +
		snTime.getMinutes().toString().padStart(2, '0') + ':' +
		snTime.getSeconds().toString().padStart(2, '0');
		
	// 날짜 YYYYMMDD 형식으로 포맷
	let tickDate = tkTime.getFullYear().toString() + ':' +
		(tkTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		tkTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let tickTime = tkTime.getHours().toString().padStart(2, '0') + ':' +
		tkTime.getMinutes().toString().padStart(2, '0') + ':' +
		tkTime.getSeconds().toString().padStart(2, '0');
		
	let objsec = {};
	objsec.market = inreldata.ev;
	objsec.symbol = inreldata.pair;
	objsec.secDate = secDate;
	objsec.secTime = secTime;
	objsec.tickDate = tickDate;
	objsec.tickTime = tickTime;
	objsec.price = inreldata.p;
	objsec.sigprice = inreldata.p; 
	objsec.gogaprice = inreldata.p;
	objsec.jongprice = inreldata.p;
	
	return objsec;	
};

// 실시간 데이터 분 시간 틱 추가
UtilityF.setinsertOnemindataCleaning = function(inreldata, inpredata)
{
	let timestapmp = inreldata.t;
	let ticktimestapmpa = Math.floor(inreldata.t / (60 * 1000)) * (60 * 1000);  //  inreldata.pt;

	let snTime = null, tkTime = null;
	
	if(theApp.g_userLanguage === GLANGCHANEV)
	{
		snTime = new Date(timestapmp);
		tkTime = new Date(ticktimestapmpa);
	}
	else
	{
		snTime = UtilityF.convertTimestampToKST(timestapmp);
		tkTime = UtilityF.convertTimestampToKST(ticktimestapmpa);
	}

	//snTime.setHours(snTime.getHours() + 9);

	// 날짜 YYYYMMDD 형식으로 포맷
	let secDate = snTime.getFullYear().toString() + ':' +
		(snTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		snTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let secTime = snTime.getHours().toString().padStart(2, '0') + ':' +
		snTime.getMinutes().toString().padStart(2, '0') + ':' +
		snTime.getSeconds().toString().padStart(2, '0');

	// 날짜 YYYYMMDD 형식으로 포맷
	let tickDate = tkTime.getFullYear().toString() + ':' +
		(tkTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		tkTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let tickTime = tkTime.getHours().toString().padStart(2, '0') + ':' +
		tkTime.getMinutes().toString().padStart(2, '0') + ':' +
		tkTime.getSeconds().toString().padStart(2, '0');
	
	let objinmin = {};
	objinmin.market = inreldata.ev;
	objinmin.symbol = inreldata.pair;
	objinmin.secDate = secDate;
	objinmin.secTime = secTime;
	objinmin.tickDate = tickDate;
	objinmin.tickTime = tickTime;
	objinmin.price = inreldata.p;
	objinmin.sigprice = inreldata.p; 
	objinmin.gogaprice = inreldata.p;
	objinmin.jongprice = inreldata.p;
	
	return objinmin;	
};

// 실시간 데이터 분 시간 틱 업데이트
UtilityF.setupOnemindataCleaning = function(inreldata, inpredata)
{
	let timestapmp = inreldata.t;
	let ticktimestapmpa = 0, precheck_value = 0;
	if(this.thisObj.bcN_index == 'sec' || this.thisObj.bcN_index == 'min.1') ticktimestapmpa = Math.floor(inreldata.t / (60 * 1000)) * (60 * 1000);  //  inreldata.pt;
	else ticktimestapmpa = Math.floor(inpredata.mt / (60 * 1000)) * (60 * 1000);  //  inreldata.pt;   
	
	let snTime = null, tkTime = null;
	
	if(theApp.g_userLanguage === GLANGCHANEV)
	{
		snTime = new Date(timestapmp);
		tkTime = new Date(ticktimestapmpa);
	}
	else
	{
		snTime = UtilityF.convertTimestampToKST(timestapmp);
		tkTime = UtilityF.convertTimestampToKST(ticktimestapmpa);
	}
	
	const previousMin_check = tkTime.getMinutes();
	
	let pretick_timecheck = 0;
	if(this.thisObj.bcN_index == 'min.5')
	{
		pretick_timecheck = Math.floor(previousMin_check / 5);
		precheck_value = theApp.util_mintick[0][pretick_timecheck - 1] || 0;
		if(precheck_value == 0)
		{
			tkTime.setMinutes(0);
		}
		else
		{
			tkTime.setMinutes(precheck_value);
		}
	}
	else if(this.thisObj.bcN_index == 'min.10')
	{
		pretick_timecheck = Math.floor(previousMin_check / 10);
		precheck_value = theApp.util_mintick[1][pretick_timecheck - 1] || 0;
		if(precheck_value == 0)
		{
			tkTime.setMinutes(0);
		}
		else
		{
			tkTime.setMinutes(precheck_value);
		}
	}
	
	if(TESTLOG == 3) console.log('시간체크',tkTime);
	//snTime.setHours(snTime.getHours() + 9);

	// 날짜 YYYYMMDD 형식으로 포맷
	let secDate = snTime.getFullYear().toString() + ':' +
		(snTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		snTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let secTime = snTime.getHours().toString().padStart(2, '0') + ':' +
		snTime.getMinutes().toString().padStart(2, '0') + ':' +
		snTime.getSeconds().toString().padStart(2, '0');

	// 날짜 YYYYMMDD 형식으로 포맷
	let tickDate = tkTime.getFullYear().toString() + ':' +
		(tkTime.getMonth() + 1).toString().padStart(2, '0') + ':' +
		tkTime.getDate().toString().padStart(2, '0');

	// 시간 HHMMSS 형식으로 포맷
	let tickTime = tkTime.getHours().toString().padStart(2, '0') + ':' +
		tkTime.getMinutes().toString().padStart(2, '0') + ':' +
		tkTime.getSeconds().toString().padStart(2, '0');
	
	let objupmin = {};
	objupmin.market = inreldata.ev;
	objupmin.symbol = inreldata.pair;
	objupmin.secDate = secDate;
	objupmin.secTime = secTime;
	objupmin.tickDate = tickDate;
	objupmin.tickTime = tickTime;
	objupmin.price = inreldata.p;
	objupmin.sigprice = inpredata.po; 
	objupmin.gogaprice = Math.max(inpredata.ph, inreldata.p); // inreldata.ph;
	objupmin.jongprice = Math.min(inpredata.pl, inreldata.p); // inreldata.pl;
	
	return objupmin;	
};

// GMT time KST chang
UtilityF.convertTimestampToKST = function(timestamp)
{
	// 타임스탬프를 Date 객체로 변환 (UTC 시간)
    const dateUTC = new Date();

    // GMT 시간 문자열로 변환
    /*const gmtTimeString = dateUTC.toGMTString();
    if(TESTLOG == 1) console.log("GMT 시간: ", gmtTimeString);*/
	const utc = timestamp + (dateUTC.getTimezoneOffset() * 60000);

    // 한국 시간으로 변환 (UTC+9)
    const offset = 9 * 60 * 60 * 1000; // 9시간을 밀리초로 변환
    const dateKST = new Date(utc + offset);

    // 한국 시간 문자열로 변환
   /* const kstTimeString = dateKST.toISOString().replace('T', ' ').split('.')[0];
    if(TESTLOG == 1) console.log("한국 시간: ", kstTimeString);*/

    // 결과 반환
    return dateKST;
};
