function AssetSelection()
{
	AView.call(this);
}
afc.extendsClass(AssetSelection, AView);

AssetSelection.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

AssetSelection.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.loading_bar.show();
	var thisObj = this;
	this.m_Data = this.getContainer().getData();
	
	if(!this.m_Data.gun) this.c_speselect.getElement().style.left = this.m_Data.left;
	this.c_speselect.getElement().style.width = this.m_Data.width;
	this.c_speselect.getElement().style.height = this.m_Data.height;
	setTimeout(function()
	{
		thisObj.listviewcell();
	}, 100);
};

AssetSelection.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

// list view cell
AssetSelection.prototype.listviewcell = function(listdata)
{
	this.all_menu00.addItem('Source/Allstocklist.lay', theApp.MsterSymbol);
	this.c_showhideasset.show();
	this.loading_bar.hide();
};

// 나가기
AssetSelection.prototype.onCloseClick = function(comp, info, e)
{
	this.getContainer().close(0, null);
};

// 종목선택
AssetSelection.prototype.selectSymbolClick = function(symboldata)
{
	this.getContainer().close(1, symboldata);
};