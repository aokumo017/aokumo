function ChartSelectdrow()
{
	AView.call(this);
}
afc.extendsClass(ChartSelectdrow, AView);


ChartSelectdrow.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

ChartSelectdrow.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	this.m_type = this.getContainer().getData();
	this.drowSelectType(this.m_type.type);
};

// type 별 화면 호출
ChartSelectdrow.prototype.drowSelectType = function(type)
{
	if(type == 1)
	{
		this.c_chart.show();
		if(theApp.b_buttoncomp) this.onChangSelectClick(theApp.b_buttoncomp);
	}
	else if(type == 2)
	{
		this.c_timesel.show();
	}
	else
	{
		this.c_mintick.show();
	}
};

ChartSelectdrow.prototype.onDrowChartvalue = function(comp, info, e)
{
	var data = {};
	
	if(comp.getAttr('class').split(' ')[1] == 'chattype01')
	{
		data.icon ='graptype_01';
		data.iconover = 'ico_chat01_over';
		data.type = 0;
		
		this.getContainer().close(1, data);
	}
	else if(comp.getAttr('class').split(' ')[1] == 'chattype02')
	{
		data.icon ='graptype_02';
		data.iconover = 'ico_chat02_over';
		data.type = 1;
		
		this.getContainer().close(1, data);
	}
	else if(comp.getAttr('class').split(' ')[1] == 'chattype03')
	{
		data.icon ='graptype_03';
		data.iconover = 'ico_chat04_over';
		data.type = 2;
		
		this.getContainer().close(1, data);
	}
	else if(comp.getAttr('class').split(' ')[1] == 'chattype04')
	{
		data.icon ='graptype_04';
		data.iconover = 'ico_chat03_over';
		data.type = 3;
		
		this.getContainer().close(1, data);
	}
};

ChartSelectdrow.prototype.onClosebuttonClick = function(comp, info, e)
{
	this.getContainer().close(99, null);
};

// 시간선택
ChartSelectdrow.prototype.mintickTimeSelectClick = function(comp, info, e)
{
	if('sec' == comp.getComponentId()) this.getContainer().close(22, 'sec');
	else
	{
		if('1' == comp.getComponentId()) this.getContainer().close(22, 'min.' + comp.getComponentId());
		else if('5' == comp.getComponentId()) this.getContainer().close(22, 'min.' + comp.getComponentId());
		else if('10' == comp.getComponentId()) this.getContainer().close(22, 'min.' + comp.getComponentId());
	}
};

// 차트 선택
ChartSelectdrow.prototype.onChangSelectClick = function(comp, info, e)
{

	if(comp.getComponentId() == 'c_type00')
	{
		if(this.c_linetype01.getAttr('class').split(' ')[1] == 'chattype01') return;
		else
		{
			this.c_linetype01.removeClass(this.c_linetype01.getAttr('class').split(' ')[1]);
			this.c_linetype02.removeClass(this.c_linetype02.getAttr('class').split(' ')[1]);
			
			this.c_linetype01.addClass('chattype01');
			this.c_linetype02.addClass('chattype02');
		}
	}
	else if(comp.getComponentId() == 'c_type02')
	{
		if(this.c_linetype01.getAttr('class').split(' ')[1] == 'chattype03') return;
		else
		{
			this.c_linetype01.removeClass(this.c_linetype01.getAttr('class').split(' ')[1]);
			this.c_linetype02.removeClass(this.c_linetype02.getAttr('class').split(' ')[1]);
			
			this.c_linetype01.addClass('chattype03');
			this.c_linetype02.addClass('chattype04');
		}
	}
	
	theApp.b_buttoncomp = comp;
};
