function LangList()
{
	AView.call(this);
}
afc.extendsClass(LangList, AView);

LangList.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
};

LangList.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
};

LangList.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

LangList.prototype.onLangClick = function(comp, info, e)
{
	this.owner.parent.parent.parent.setlangeChang(comp.getFirstChild().getComponentId());
	this.owner.parent.hide();
};
