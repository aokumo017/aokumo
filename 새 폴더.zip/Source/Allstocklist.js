function Allstocklist()
{
	AView.call(this);
}
afc.extendsClass(Allstocklist, AView);

Allstocklist.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

Allstocklist.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
};

Allstocklist.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

Allstocklist.prototype.setData = function(listData)
{
	let symbolimgSle = UtilityF.getShortcdSymbolfind(listData.sym_symbol);
	if(!symbolimgSle) symbolimgSle = theApp.g_DefultMster;
	
	this.mydata = listData;
	this.c_img.addClass(symbolimgSle.class32);
	this.c_str.setText(listData.sym_desc);
	this.c_symbol.setText(listData.sym_symbol);
};

// 선택시
Allstocklist.prototype.onAView1Click = function(comp, info, e)
{
	this.owner.getRootView().selectSymbolClick(this.mydata);
};
