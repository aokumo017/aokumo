afc.loadScript("Source/support/TSandeksielsa.cls");

function ClientConnectSpectrumApp()
{
	AApplication.call(this);
	this.hashMap = {};
	this.producthashMap = {};
	this.curReconnectNum = 0;
	this.reconnectCount = 5;
	this.g_errorcheckon = true;
	
	this.g_DefultMster = {};
}
afc.extendsClass(ClientConnectSpectrumApp, AApplication);


ClientConnectSpectrumApp.prototype.onReady = function()
{
	AApplication.prototype.onReady.call(this);
	//$('<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">').appendTo('head');
	$('<meta name="referrer" content="origin" />').appendTo('head');
	//KeyboardManager.resizeWebview = !afc.isSystemWebview;
	
	/*this.splashWindow = new AWindow('');
	this.splashWindow.openFull('Source/win/Splash.lay');*/
	//var g_g_userLanguage = navigator.language || navigator.userLanguage;
	//theApp.g_userLanguage = g_g_userLanguage.slice(0, 2);
	//console.log(theApp.g_userLanguage );
	
	
	// 시간대와 국가 코드 매핑 객체
	const timeZoneToCountry = {
		"Europe/London": "GB",
		"America/New_York": "US",
		"Asia/Seoul": "KR",
		"Europe/Paris": "FR",
		"Asia/Tokyo": "JP",
		"Australia/Sydney": "AU",
		"America/Los_Angeles": "US",
		// 필요한 만큼 추가 가능
	};

	// 현재 브라우저의 시간대 정보를 가져옴
	let timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
	theApp.g_userLanguage = timeZoneToCountry[timeZone] || 'Unknown';

	//console.log("Time Zone:", timeZone);
	//console.log("Country Code:", theApp.g_userLanguage);
	
	if(OPERATE_U == 2)
	{
		var locationURL = {
			 href : location.href,
			 enhanced : true,
		};
		
		$.post('/client/login', JSON.stringify(locationURL), function(data) {
			if(TESTLOG == 1) console.log(data);
			if(data)
			{
				theApp.useruid = data.respond.usr_uid;
				theApp.userid = data.respond.usr_id;
				theApp.siURL = data.respond.wurl;
				theApp.leverage = data.respond.leverage;
				theApp.g_vibration = data.respond;
				new HttpioRq().Setvibration();
				if(data.respond.ldefault) theApp.defultindex = theApp.leverage.indexOf(data.respond.ldefault);
				else theApp.defultindex = 0;
				theApp.GmStart();
			}
			else
			{
				alert("Not found data");
			}
		});
		
		window.addEventListener("beforeunload", function() {
			if(TESTLOG == 1) console.log('beforeunload logout');
			theApp.qm.GameAjaxSend('/client/logout');
		});

		window.addEventListener("unload", function() {
			if(TESTLOG == 1) console.log('unload logout');
			theApp.qm.GameAjaxSend('/client/logout');
		});
		
		window.addEventListener("visibilitychange", function(e) {
			if (e.target.visibilityState === 'hidden') {
                //console.log(' 사용자가 홈버튼눌러서 페이지를 떠났음');
            } else if (e.target.visibilityState === 'visible') {
				//console.log('홈 버튼을 눌렀다가 다시 돌아오셨습니다.');
				//theApp.qm.Stopsocket();
			}
		});
	}
	
    //window.addEventListener('orientationchange', this.onOrientationChange);  // 이거 이벤트가 안탐
	if(TESTLOG == 1) console.log('기기 는 ? : ', afc.isMobile);
	if(afc.isMobile)
	{
		// 미디어 쿼리 설정
		const mediaQueryList = window.matchMedia("(orientation: portrait)");
		// 미디어 쿼리 변화 감지
		mediaQueryList.addEventListener('change', theApp.debounce(function() {
			theApp.getMainContainer().view.mediAresizeCanvas(mediaQueryList);
		},100));
		
		if (window.matchMedia("(orientation: portrait)").matches) {
			theApp.n_cssclassdata = 'MH_Class';
			theApp.n_addcssclassname = 'mh';
		} else if (window.matchMedia("(orientation: landscape)").matches) {
			theApp.n_cssclassdata = 'MW_Class';
			theApp.n_addcssclassname = 'mw';
		}
	}
	else
	{
		window.addEventListener("resize", theApp.debounce(function() {
			theApp.getMainContainer().view.resizeCanvas();
		},100));
		
		if (window.matchMedia("(orientation: portrait)").matches) {
			theApp.n_cssclassdata = 'PCH_Class';
			theApp.n_addcssclassname = 'ph';
		} else if (window.matchMedia("(orientation: landscape)").matches) {
			theApp.n_cssclassdata = 'PCW_Class';
			theApp.n_addcssclassname = 'pw';
		}
	}
	
	document.querySelectorAll('input, textarea').forEach(element => {
		element.addEventListener('focus', (event) => {
			const scrollPosition = window.pageYOffset; // 현재 스크롤 위치 저장
			window.scrollTo(0, scrollPosition); // 스크롤 위치 고정
		});

		element.addEventListener('blur', (event) => {
			// 필요한 경우 추가 로직 처리
		});
	});
	
	if(OPERATE_U == 1) theApp.GmStart();
};

ClientConnectSpectrumApp.prototype.unitTest = function(unitUrl)
{
	this.onReady();
	AApplication.prototype.unitTest.call(this, unitUrl);
};
// 여기서 부터 시작
ClientConnectSpectrumApp.prototype.GmStart = function()
{
	if(OPERATE_U == 2) this.connectServer();
	//this.setsymbolimgin();
	this.librayNew();
};

// 서버와 통신
ClientConnectSpectrumApp.prototype.connectServer = function()
{
	this.qm = new HttpioRq();
	this.qm.extWebsocketConnection(theApp.siURL, null);
};

// 실시간 서버와 통신
ClientConnectSpectrumApp.prototype.reconnectServer = function()
{
	this.qm.socket = null;
	this.qm.extWebsocketConnection(theApp.siURL, 'recon');
};

// 웹소켓 연결 후 셋
ClientConnectSpectrumApp.prototype.userSetA = function()
{
	//유저 실시간 셋
	theApp.qm.extWebsocketSend({ type : 'A', key  :  'ORDER' + '.' + theApp.useruid });
};

ClientConnectSpectrumApp.prototype.MainPage = function()
{
	//if(this.splashWindow.isValid()) this.splashWindow.close();
	
	// 종목 정보 조회 후  화면 호출
	this.setMainContainer(new APage('main'));
	this.mainContainer.open('Source/TradeExecution.lay');
};

ClientConnectSpectrumApp.prototype.librayNew = function()
{
	this.Icandleback = new Icandleback();
	this.Icandlechart = new Icandlechart();
	this.Icandlebong = new Icandlebong();
	this.Icandlepos = new Icandlepos();
	this.Icandlearc = new IcandleArc();
	this.Icandlemouse = new IcandleMouse();
	this.AudioControl = new AudioControlM();
	
	var thisObj = this;
	var data = {}, MasterKeys = [], ieq = 0, is_decimalgetf = false;
	if(OPERATE_U == 2)
	{
		// 종목정보 조회
		this.listinfo(data)
		.then(function(result){
			if(TESTLOG == 1) console.log('마스터', result);
			if(result.respond)
			{
				theApp.MsterSymbol = result.respond.list;
				theApp.MsterSymbol.forEach(item => {
					item.class32 = item.image32;
					item.class46 = item.image46;
					const key = `${item.sym_market}-${item.sym_symbol}`;
					is_decimalgetf = thisObj.containsValue(MARKETG, item.sym_market);
					if(is_decimalgetf)
					{
						const keyp = item.sym_symbol.slice(0, 2);
						thisObj.producthashMap[keyp] = item;
					}
					thisObj.hashMap[key] = item;
				});
				MasterKeys = Object.keys(theApp.MsterSymbol[0]);
				
				for(ieq = 0; ieq < MasterKeys.length; ieq++)
				{
					theApp.g_DefultMster[MasterKeys[ieq]] = 'DF0';
				}
				theApp.MainPage();
			}
		})
		.catch(function(){
			console.log('Master Lookup Error');
		});
	}
	else
	{
		theApp.MsterSymbol = master.respond.list;
		theApp.MsterSymbol.forEach(item => {
			item.class32 = item.image32;
			item.class46 = item.image46;
			const key = `${item.sym_market}-${item.sym_symbol}`;
			is_decimalgetf = thisObj.containsValue(MARKETG, item.sym_market);
			if(is_decimalgetf)
			{
				const keyp = item.sym_symbol.slice(0, 2);
				thisObj.producthashMap[keyp] = item;
			}
			thisObj.hashMap[key] = item;
		});
		MasterKeys = Object.keys(theApp.MsterSymbol[0]);
				
		for(ieq = 0; ieq < MasterKeys.length; ieq++)
		{
			theApp.g_DefultMster[MasterKeys[ieq]] = 'DF0';
		}
		theApp.MainPage();
	}
};

// 종목정보 취득
ClientConnectSpectrumApp.prototype.listinfo = function(indata, callbak)
{
	return new Promise(function(resolve, reject) {
		theApp.qm.GameAjaxSend(STurl+'/list', indata, function(data){
			if(data.result != 'success') reject(data);
			else {
				result = JSON.parse(data.message);
				let codenum = isNaN(Number(result.error.code)) ? 0 : Number(result.error.code);
				if(codenum >= 0) 
				{
					resolve(result);
				}
				else
				{
					theApp.g_errorcheckon = false;
					theApp.tRlogoutMsg(result.error.message);
					//AToast.show(result.error.message);
					theApp.qm.Stopsocket();	
				}
			}
		});
	});
};

// 실시간 데이터 받기
ClientConnectSpectrumApp.prototype.onReceived = function(reldata)
{
	this.getMainContainer().view.onReceived(reldata);
	// not if(this.getMainContainer().view.win01.view)	this.getMainContainer().view.win01.view.onReceived(reldata);
};

// 다시 셋
ClientConnectSpectrumApp.prototype.reconSet = function()
{
	//console.log('언제 호출되는거냐 ? ' , this.getMainContainer());
	this.userSetA();
	if(this.getMainContainer().view) this.getMainContainer().view.ReceivSetA();
};

// 종목 이미지 생성
ClientConnectSpectrumApp.prototype.setsymbolimgin = function()
{
	var thisObj  = this;

	$.ajax(
	{
		async:false, url: 'Assets/ini/imgList.ini', dataType: 'json',
		success: function(result)
		{
			thisObj.symbolImgList = result.imgInfo.children;
			if(TESTLOG == 1) console.log('심볼이미지 클래스 : ', thisObj.symbolImgList);
		},
		error: function()
		{
			alert('imglist load fail!');
		}
	});
};

// 종목이미지가져오기
ClientConnectSpectrumApp.prototype.getSelectsymbolimgfind = function(symbol)
{
	return this.symbolImgList.find(function(s){
		return s.symbol === symbol;
	}); 
};

// 화면 가로 세로 함수
ClientConnectSpectrumApp.prototype.onOrientationChange = function(e)
{
	//theApp.isPortrait = screen.orientation.angle == 0? true : false;
	
	var cntr = this.getMainContainer();
	var activeView;
	if(cntr)
	{
		activeView = cntr.getView();
		if(activeView && activeView.onOrientationChange) 
		{
			activeView.onOrientationChange();
		}
	}
};

// 디바이스 픽셀 비율 렌더링 최적화
ClientConnectSpectrumApp.prototype.debounce = function(func, wait, immediate)
{
    var timeout;
    return function() {
        var context = this, args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};

// 소수점 함수  종목코드가 없을시 품목코드로 찾는거 추가해야함
ClientConnectSpectrumApp.prototype.getMsterDecimalValue = function(sym_market, sym_symbol, value)
{
	const key = `${sym_market}-${sym_symbol}`;
	const keypt = sym_symbol.slice(0, 2);
	
	var is_checkdecimalge = this.containsValue(MARKETG, sym_market);
	var decimalge = 0;
	if(is_checkdecimalge)
	{
		if(this.producthashMap[keypt])
		{
			decimalge = this.producthashMap[keypt].sym_decimal;
		}
		else
		{
			decimalge = SOSUDECIMALGE;
		}
	}
	else
	{
		if(this.hashMap[key])
		{
			decimalge = this.hashMap[key].sym_decimal;
		}
		else
		{
			decimalge = SOSUDECIMALGE;
		}
	}
	
	if(decimalge != undefined)
	{
		value = ADataMask.Number.decimalAdjust.func(value, ['floor', decimalge*-1]).toFixed(decimalge);
	}
	return ADataMask.Number.money.func(value);
};

// 마켓이 유무
ClientConnectSpectrumApp.prototype.containsValue = function(array, value)
{
	return array.includes(value);
};

// 로그아웃
ClientConnectSpectrumApp.prototype.tRlogoutMsg = function(msg)
{
	var lay = 'Source/win/logoutPo.lay';
	var wparcnt = '', hparcnt = '';
	if(afc.isMobile)
	{
		if (window.matchMedia("(orientation: portrait)").matches) {
			wparcnt = '60%';
			hparcnt = '30%';
		} else if (window.matchMedia("(orientation: landscape)").matches) {
			wparcnt = '50%';
			hparcnt = '50%';
		}
	}
	else
	{
		wparcnt = '50%';
		hparcnt = '30%';
	}
	
	PopupFun.whDialogpopupCenter(lay, {data : msg}, 0, 0, wparcnt, hparcnt, function(result, data){
		//console.log(result);
		if(result == 99) return;
	});
};
var theApp = null;

AApplication.start = function()
{
    afc.scriptReady(function()
    {
        if(window._version) _version.setFileVersion();
	    theApp = new ClientConnectSpectrumApp();
	    theApp.isLoadTheme = false;
        if(PROJECT_OPTION.unitUrl) theApp.unitTest(PROJECT_OPTION.unitUrl);
        else theApp.onReady();
    });
};

if(!AApplication.manualStart)
{
    $(document).ready(function()
    {
        AApplication.start();
    });
}
else if(AApplication.manualStart == 2)
{
    AApplication.start();
}

