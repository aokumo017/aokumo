function Automaticpopup()
{
	AView.call(this);
}
afc.extendsClass(Automaticpopup, AView);


Automaticpopup.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
};

Automaticpopup.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
	let le_val = 10;
	this.c_selectetcprant.removeAll();
	
	this.c_selectetcprant.addItem('-----', 0, 0);
	for(var i = 0; i < 5; i++)
	{
		
		this.c_selectetcprant.addItem(le_val + '%', i+1, le_val);
		le_val += 10;
	}
};

Automaticpopup.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};


// 판매
Automaticpopup.prototype.onAButton1Click = function(comp, info, e)
{
	this.getContainer().close(1, null);	
};

// 자동판매
Automaticpopup.prototype.onAButton2Click = function(comp, info, e)
{
	this.getContainer().close(2, this.c_selectetcprant.getSelectedItemData() );	
};
