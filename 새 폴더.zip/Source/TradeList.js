function TradeList()
{
	AView.call(this);
}
afc.extendsClass(TradeList, AView);


TradeList.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
};

TradeList.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
};

TradeList.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};


TradeList.prototype.setData = function(listData)
{
	var invest_pnlinfo = 0;
	invest_pnlinfo = this.getNumPnlValue(listData, listData);
	this.mydata = listData;
	this.c_infodata01.tmpData = listData;
	this.c_infodata02.tmpData = listData;
	
	if(theApp.g_portraitonland)
	{
		this.bottomlist02.hide();
		this.bottomlist01.show();
		this.p_invastamt.setText(listData.invest_amt);
		this.p_pnlinfo.setText(invest_pnlinfo);
		if(listData.invest_kind == 'P')
		{
			this.c_infodata01.addClass('btn_putbox');
		}
		else
		{
			this.c_infodata01.addClass('btn_cellbox');
		}
	}
	else
	{
		this.bottomlist02.show();
		this.bottomlist01.hide();
		this.l_invastamt.setText(listData.invest_amt);
		this.l_pnlinfo.setText(invest_pnlinfo);
		if(listData.invest_kind == 'P')
		{
			this.c_infodata02.addClass('btn_putbox');
		}
		else
		{
			this.c_infodata02.addClass('btn_cellbox');
		}
	}
};

// 실시간 들어오는데이터
TradeList.prototype.relDatalistset = function(obj)
{
	if(this.mydata.symbol == obj.pair)
	{
		var objaa = {
			ord_prc : obj.p
		};
		var invest_pnlrel = 0, rgbve = null;
		invest_pnlrel = this.getNumPnlValue(this.mydata, objaa);
		rgbve = this.getrgbvalue(invest_pnlrel);
		
		if(theApp.g_portraitonland)
		{	
			this.p_pnlinfo.get$ele().css('color', rgbve);
			this.p_pnlinfo.setText(invest_pnlrel);
		}
		else
		{
			this.l_pnlinfo.get$ele().css('color', rgbve);
			this.l_pnlinfo.setText(invest_pnlrel);
		}
	}
};

// 색상
TradeList.prototype.getrgbvalue = function(value)
{
	if(value < 0) return '#0070ff';
	else if(value == 0) return '#ffffff';
	else return '#ff0000';
};

// 값계산
TradeList.prototype.getNumPnlValue = function(buypnl, sellpnl)
{
	var invest_pnl = 0;
	
	if( buypnl.invest_kind == 'C' ) {
		// 콜 = (매도가-매수가)/매수가*투자금액*레버리지
		invest_pnl = (sellpnl.ord_prc - buypnl.ord_prc) / buypnl.ord_prc * buypnl.invest_amt * buypnl.invest_leverage;
	}
	else if( buypnl.invest_kind == 'P' ) {
		// 풋 = (매수가-매도가)/매도가*투자금액*레버리지
		invest_pnl = (buypnl.ord_prc - sellpnl.ord_prc) / sellpnl.ord_prc * buypnl.invest_amt * buypnl.invest_leverage;
	}
	
	 // 양수면 버림(floor), 음수면 올림(ceil)
	if( invest_pnl < 0 ) {
		invest_pnl = Math.ceil(invest_pnl);
	} else {
		invest_pnl = Math.floor(invest_pnl);
	}
	
	//invest_pnl -= buypnl.disp_charge;  // 차지금액 나중으로
 	return invest_pnl;
};

// 청산
TradeList.prototype.onC_infodata01Click = function(comp, info, e)
{

	let MsterOrder = UtilityF.getShortcdSymbolfind(comp.tmpData.symbol);
	if(!MsterOrder)
	{
		AToast.show('There is no master information.');
	}
	else
	{
		this.owner.getRootView().cleanOrderinfoDATA(comp.tmpData);
	}

};
