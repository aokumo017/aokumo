function orderList()
{
	AView.call(this);
}
afc.extendsClass(orderList, AView);

orderList.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	JsCssResponsive.cssAddcomponent(this, cssClassname[theApp.n_cssclassdata], theApp.n_addcssclassname);
};

orderList.prototype.onInitDone = function()
{
	AView.prototype.onInitDone.call(this);
};

orderList.prototype.onActiveDone = function(isFirst)
{
	AView.prototype.onActiveDone.call(this, isFirst);
};

orderList.prototype.setData = function(listData)
{
	var invest_pnlinfo = 0;
	invest_pnlinfo = this.getNumPnlValue(listData, listData);
	let perant_ew = (listData.invest_no % 1000000);
	this.mydata = listData;
	this.c_invest_no.setText(perant_ew);
	this.c_symbol.setText(listData.symbol);
	this.c_biz_date.setText(listData.buy_date.replace(/:/g, '/'));
	this.c_buy_time.setText(listData.buy_time);
	this.c_ord_prc.setText(theApp.getMsterDecimalValue(listData.market, listData.symbol, listData.ord_prc));
	this.c_leverage.setText(listData.invest_leverage);
	this.c_invest_kind.setText(listData.invest_kind);
	this.c_invest_amt.setText(listData.invest_amt);
	this.c_pnlinfo.setText(invest_pnlinfo);
	this.c_infodata.tmpData = listData;
	
	if(listData.invest_kind == 'P')
	{
		if(afc.isMobile)
		{
			if(theApp.g_portraitonland)
			{
				this.c_infodata.addClass('ordersize03_mh');
			}
			else
			{
				this.c_infodata.addClass('ordersize03_mw');
			}
		}
		else
		{
			if(theApp.g_portraitonland)
			{
				this.c_infodata.addClass('ordersize03_ph');
			}
			else
			{
				this.c_infodata.addClass('ordersize03_pw');
			}
		}
	}
	else
	{
		if(afc.isMobile)
		{
			if(theApp.g_portraitonland)
			{
				this.c_infodata.addClass('ordersize02_mh');
			}
			else
			{
				this.c_infodata.addClass('ordersize02_mw');
			}
		}
		else
		{
			if(theApp.g_portraitonland)
			{
				this.c_infodata.addClass('ordersize02_ph');
			}
			else
			{
				this.c_infodata.addClass('ordersize02_pw');
			}
		}
	}
};

// 실시간 들어오는데이터
orderList.prototype.relDatalistset = function(obj)
{
	if(this.mydata.symbol == obj.pair)
	{
		var objaa = {
			ord_prc : obj.p
		};
		var invest_pnlrel = 0, rgbve = null;
		invest_pnlrel = this.getNumPnlValue(this.mydata, objaa);
		rgbve = this.getrgbvalue(invest_pnlrel);
		this.c_pnlinfo.get$ele().css('color', rgbve);
		this.c_pnlinfo.setText(invest_pnlrel);
	}
};

// 값계산
orderList.prototype.getNumPnlValue = function(buypnl, sellpnl)
{
	var invest_pnl = 0;
	
	if( buypnl.invest_kind == 'C' ) {
		// 콜 = (매도가-매수가)/매수가*투자금액*레버리지
		invest_pnl = (sellpnl.ord_prc - buypnl.ord_prc) / buypnl.ord_prc * buypnl.invest_amt * buypnl.invest_leverage;
	}
	else if( buypnl.invest_kind == 'P' ) {
		// 풋 = (매수가-매도가)/매도가*투자금액*레버리지
		invest_pnl = (buypnl.ord_prc - sellpnl.ord_prc) / sellpnl.ord_prc * buypnl.invest_amt * buypnl.invest_leverage;
	}
	
	 // 양수면 버림(floor), 음수면 올림(ceil)
	if( invest_pnl < 0 ) {
		invest_pnl = Math.ceil(invest_pnl);
	} else {
		invest_pnl = Math.floor(invest_pnl);
	}
	
	//invest_pnl -= buypnl.disp_charge;  // 차지금액 나중으로
 	return invest_pnl;
};

// 색상
orderList.prototype.getrgbvalue = function(value)
{
	if(value < 0) return '#0070ff';
	else if(value == 0) return '#ffffff';
	else return '#ff0000';
};

//청산
orderList.prototype.onC_infodataClick = function(comp, info, e)
{
	let MsterOrder = UtilityF.getShortcdSymbolfind(comp.tmpData.symbol);
	if(!MsterOrder)
	{
		AToast.show('There is no master information.');
	}
	else
	{
		this.owner.getRootView().cleanOrderinfoDATA(comp.tmpData);
	}
	
	/*var thisObj = this;
	var lay = 'Source/Automaticpopup.lay';
	var ct_left = 0, ct_top = 0;
	if(this.m_rotationwh)
	{
		ct_left = 45;
		ct_top = 300 - 30;
	}
	else
	{
		ct_left = 45; //this.top.getWidth() + 45;
		ct_top =   300 - 30;
	}

	PopupFun.whDialogpopup(this, lay, {}, ct_left, ct_top, 300, 200, function(result, data){
		if(TESTLOG == 1) console.log(result);
		if(result == 99) return;
		
		if(result == 1)
		{
			thisObj.owner.getRootView().cleanOrderinfoDATA(comp.tmpData);
		}
		else if(result == 2) 
		{
			if(TESTLOG == 1) console.log(thisObj.mydata );
			console.log(data);
			thisObj.mydata.clear_prc = UtilityF.getPercentAutofun(data, Number(thisObj.mydata.ord_prc));
			console.log(thisObj.mydata );
			thisObj.owner.getRootView().cleanAutoOrderinfoDATA(comp.tmpData);
		}
	});*/
};
